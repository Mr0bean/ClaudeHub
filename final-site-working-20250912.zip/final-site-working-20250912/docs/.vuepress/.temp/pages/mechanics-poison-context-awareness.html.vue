<template><div><h1 id="poison-md-claudelog" tabindex="-1"><a class="header-anchor" href="#poison-md-claudelog"><span>Poison.md | ClaudeLog</span></a></h1>
<p>In my experience, it's remarkably easy to self sabotage through poisoning my agent's context. There are countless ways I could accidentally contaminate my Claude Code sessions and create dangerous unintended associations that persist throughout a session.</p>
<h3 id="how-i-learned-this​" tabindex="-1"><a class="header-anchor" href="#how-i-learned-this​"><span>How I Learned This<a href="#how-i-learned-this" title="Direct link to How I Learned This">​</a></span></a></h3>
<p>I discovered this the hard way when something as simple as telling Claude to update code and then requesting deployment unknowingly poisoned my future update requests. Claude began associating every code update with immediate deployment, even when I was just experimenting or working on incomplete features. This taught me that every action pairing in my context creates potential training patterns that can work against me later.</p>
<hr>
<hr>
<h3 id="how-i-think-about-context-contamination​" tabindex="-1"><a class="header-anchor" href="#how-i-think-about-context-contamination​"><span>How I Think About Context Contamination<a href="#how-i-think-about-context-contamination" title="Direct link to How I Think About Context Contamination">​</a></span></a></h3>
<p>Each piece of information I add to my context or series of actions I perform can potentially combine to create unintended behavior patterns. I've learned to stay vigilant about which combinations of context might be misinterpreted by Claude, actively scanning for dangerous associations before they take root. This is especially important when tasking it with agentic tasks that go on for extended periods of time.</p>
<h3 id="common-poison-patterns​" tabindex="-1"><a class="header-anchor" href="#common-poison-patterns​"><span>Common Poison Patterns<a href="#common-poison-patterns" title="Direct link to Common Poison Patterns">​</a></span></a></h3>
<p><strong>Context Bleeding</strong> - Without explicit markers indicating where one task ends and another begins, Claude may carry forward expectations, settings, or approaches from previous tasks into new ones, creating unexpected behavior and inconsistent results</p>
<ul>
<li><strong>Unclear boundaries</strong> - Task transitions without clear separation markers</li>
<li><strong>Implicit assumptions</strong> - Hidden expectations about coding style, deployment preferences, or workflow patterns that conflict when switching between different project types or requirements</li>
</ul>
<p><strong>Instruction Contamination</strong> - Too many instruction types competing for attention and priority, creating decision paralysis</p>
<ul>
<li><strong>Overloaded context</strong> - Multiple conflicting instruction sets active simultaneously</li>
<li><strong>Contradictory guidance</strong> - Having instructions that tell Claude to <code v-pre>always test before deploying</code> alongside emergency hotfix procedures that require <code v-pre>immediate deployment without full testing</code> creates decision paralysis where Claude can't determine which guidance takes precedence</li>
<li><strong>Temporal confusion</strong> - Earlier session instructions contaminating current task execution with outdated context</li>
</ul>
<hr>
<hr>
<h3 id="prevention-and-antidotes​" tabindex="-1"><a class="header-anchor" href="#prevention-and-antidotes​"><span>Prevention and Antidotes<a href="#prevention-and-antidotes" title="Direct link to Prevention and Antidotes">​</a></span></a></h3>
<p>I've developed strategies both to prevent context poisoning and to remedy it when it occurs. For prevention, I use markdown formatting extensively in my <code v-pre>Claude.md</code> files to prevent instructions from bleeding into each other, and I've learned to be deliberately explicit in all my communications with Claude. When I suspect my context has already been poisoned, I have antidotes: the <code v-pre>/clear</code> command or starting a fresh session can immediately reset contaminated behavioral patterns.</p>
<ul>
<li><strong>Separate contexts</strong> - I use different sessions for different types of work to avoid cross-contamination</li>
<li><strong>Context reset</strong> - When I detect poisoned patterns, I use <code v-pre>/clear</code> or start a new session to eliminate contamination</li>
<li><strong>Clear boundaries</strong> - I explicitly announce when I'm switching between task types</li>
<li><strong>Markdown structure</strong> - I use proper formatting to create clean instruction separation</li>
<li><strong>Explicit communication</strong> - I state my assumptions and expectations clearly rather than relying on implicit understanding</li>
<li><strong>Regular context review</strong> - I periodically assess what behavioral associations I might have accidentally created</li>
</ul>
<h3 id="the-discipline-of-context-hygiene​" tabindex="-1"><a class="header-anchor" href="#the-discipline-of-context-hygiene​"><span>The Discipline of Context Hygiene<a href="#the-discipline-of-context-hygiene" title="Direct link to The Discipline of Context Hygiene">​</a></span></a></h3>
<p>Poison context awareness has become foundational to how I approach Claude Code. Just as I wouldn't write sloppy code and expect clean results, I can't maintain sloppy context and expect consistent AI collaboration.</p>
<p>Context awareness can make a significant difference. Unpredictable behavior, inconsistent results, and mysterious failures may often stem from contaminated context patterns that are easy to create unknowingly.</p>
<h5 id="context-vigilance" tabindex="-1"><a class="header-anchor" href="#context-vigilance"><span>Context Vigilance</span></a></h5>
<p>Context poisoning is the silent assassin of AI collaboration. Every carelessly paired action creates invisible behavioral patterns that persist throughout your session. Maintaining context hygiene is as critical as code hygiene, both prevent future disasters through present discipline.</p>
<img src="/img/discovery/010_scary_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink>|<RouteLink to="/mechanics/dynamic-memory/">Dynamic Memory</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#how-i-learned-this">How I Learned This</a></li>
<li><a href="#how-i-think-about-context-contamination">How I Think About Context Contamination</a></li>
<li><a href="#common-poison-patterns">Common Poison Patterns</a></li>
<li><a href="#prevention-and-antidotes">Prevention and Antidotes</a></li>
<li><a href="#the-discipline-of-context-hygiene">The Discipline of Context Hygiene</a></li>
</ul>
</div></template>


