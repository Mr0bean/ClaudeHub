<template><div><h1 id="browser-tools-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#browser-tools-mcp-claudelog"><span>Browser Tools MCP | ClaudeLog</span></a></h1>
<p><strong>Comprehensive browser automation and monitoring toolkit providing real-time web debugging, performance analysis, and automated testing through MCP integration.</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/AgentDeskAI" target="_blank" rel="noopener noreferrer">AgentDeskAI</a>  |  <a href="https://github.com/AgentDeskAI/browser-tools-mcp" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  6.3k Stars|468 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Browser Tools MCP provides a comprehensive suite for browser automation and monitoring through Model Context Protocol integration. It enables real-time browser log monitoring, automated performance analysis, and seamless IDE integration for web development workflows. The server combines browser automation capabilities with detailed debugging tools for enhanced development productivity.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Real-Time Browser Monitoring</strong> - Monitor console logs, network requests, and errors directly from IDE</li>
<li><strong>Comprehensive Audit Suite</strong> - SEO, performance, accessibility analysis via Lighthouse integration</li>
<li><strong>Chrome Extension Integration</strong> - Browser extension for seamless data collection and auto-paste functionality</li>
<li><strong>WCAG Compliance Checking</strong> - Automated accessibility testing and compliance reporting</li>
<li><strong>Cursor Integration</strong> - Primarily designed for Cursor with auto-paste functionality</li>
<li><strong>Automated Testing</strong> - Puppeteer-based automation for end-to-end testing scenarios</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Node.js 14 or higher</li>
<li>Chrome browser for extension functionality</li>
<li>MCP-compatible IDE (Cursor recommended, VS Code, Claude Desktop)</li>
</ul>
<p><strong>Chrome Extension Setup</strong></p>
<ol>
<li>Download the extension ZIP from: <a href="https://github.com/AgentDeskAI/browser-tools-mcp/releases/download/v1.2.0/BrowserTools-1.2.0-extension.zip" target="_blank" rel="noopener noreferrer">https://github.com/AgentDeskAI/browser-tools-mcp/releases/download/v1.2.0/BrowserTools-1.2.0-extension.zip</a></li>
<li>Extract the ZIP file</li>
<li>Open Chrome → Extensions → Enable &quot;Developer mode&quot;</li>
<li>Click &quot;Load unpacked&quot; and select the extracted extension folder</li>
<li>Enable the extension for browser automation features</li>
</ol>
<p><strong>MCP Server Setup</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Install and run MCP server (Terminal 1)</span></span>
<span class="line"></span>
<span class="line">npx @agentdeskai/browser-tools-mcp@1.2.0</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Start local server (Terminal 2)</span></span>
<span class="line"></span>
<span class="line">npx @agentdeskai/browser-tools-server@1.2.0</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude Desktop Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"browser-tools"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"@agentdeskai/browser-tools-mcp@1.2.0"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Important Notes</strong></p>
<ul>
<li>Keep both servers running simultaneously</li>
<li>Ensure only one Chrome DevTools panel is open</li>
<li>Restart Chrome if connectivity issues occur</li>
</ul>
<hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Development Workflow</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Example MCP interactions through AI:</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Monitor console errors on the current page"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Run a Lighthouse audit for performance analysis"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Check accessibility compliance for form elements"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Capture network requests for the login flow"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The server provides seamless integration between browser debugging and AI-assisted development. You can monitor real-time browser activity, automate testing procedures, and analyze web performance - all through natural language interactions with your AI coding assistant.</p>
<p><strong>Advanced Features</strong></p>
<ul>
<li><strong>Auto-Paste Integration</strong>: Browser extension automatically pastes captured data into Cursor</li>
<li><strong>Performance Monitoring</strong>: Real-time metrics collection and analysis</li>
<li><strong>Error Tracking</strong>: Comprehensive JavaScript error monitoring and reporting</li>
<li><strong>Accessibility Auditing</strong>: WCAG 2.1 compliance checking with detailed reports</li>
</ul>
<hr>
<h5 id="community-insight" tabindex="-1"><a class="header-anchor" href="#community-insight"><span>Community Insight</span></a></h5>
<p>Browser Tools MCP has earned a 4.8/5 star rating with users praising the auto-paste functionality that &quot;streamlines debugging workflow by automatically sending browser data to Cursor.&quot; Real-time monitoring has proven invaluable for frontend developers.</p>
<img src="/img/discovery/022_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Browser Tools MCP is developed by AgentDeskAI and is open-source. For technical support, feature requests, and community discussions, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


