<template><div><h1 id="whatsapp-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#whatsapp-mcp-claudelog"><span>WhatsApp MCP | ClaudeLog</span></a></h1>
<p><strong>Personal WhatsApp messaging and search capabilities for Claude Code</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/lharries" target="_blank" rel="noopener noreferrer">lharries</a>  |  <a href="https://github.com/lharries/whatsapp-mcp" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  4.7k Stars|693 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>WhatsApp MCP enables Claude Code to interact with your personal WhatsApp account through the Model Context Protocol. Search and read your WhatsApp messages (including media), manage contacts, and send messages to individuals or groups using WhatsApp Web's multidevice API.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Message Search</strong> - Search through your personal WhatsApp message history</li>
<li><strong>Media Support</strong> - Access images, videos, documents, and audio messages</li>
<li><strong>Contact Management</strong> - Search contacts by name or phone number</li>
<li><strong>Group Messaging</strong> - Send messages to individuals or groups</li>
<li><strong>Local Storage</strong> - All messages stored locally in SQLite database</li>
<li><strong>Privacy-First</strong> - Messages only sent to LLM when actively accessed</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>WhatsApp account with multidevice support</li>
<li>Go 1.19+ programming language installed</li>
<li>Python 3.6+ installed</li>
<li>UV package manager: <code v-pre>pip install uv</code></li>
<li>FFmpeg (optional, for audio message conversion)</li>
<li><strong>Windows users</strong>: CGO enabled and C compiler installed</li>
</ul>
<p><strong>Step 1: Clone and Build</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token function">git</span> clone https://github.com/lharries/whatsapp-mcp.git</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">cd</span> whatsapp-mcp</span>
<span class="line"></span>
<span class="line">go build <span class="token parameter variable">-o</span> whatsapp-mcp-server</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Step 2: WhatsApp Bridge Setup</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">cd</span> whatsapp-bridge</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Start the bridge (follow repo instructions for your OS)</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Scan QR code with your WhatsApp mobile app when prompted</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Wait for initial message history sync to complete</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Step 3: Claude Code Configuration</strong></p>
<p>Edit <code v-pre>~/.claude.json</code>:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"projects"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"/path/to/your/project"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"whatsapp"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"uv"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">            <span class="token string">"--directory"</span>,</span>
<span class="line"></span>
<span class="line">            <span class="token string">"/path/to/whatsapp-mcp-server"</span>,</span>
<span class="line"></span>
<span class="line">            <span class="token string">"run"</span>,</span>
<span class="line"></span>
<span class="line">            <span class="token string">"main.py"</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">]</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"env"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Step 4: Start Services</strong></p>
<ol>
<li>Restart Claude Code after configuration</li>
<li>Ensure WhatsApp bridge is running</li>
<li>Test with a simple contact search command</li>
</ol>
<p><strong>Troubleshooting</strong></p>
<ul>
<li><strong>QR Code Issues</strong>: Ensure WhatsApp multidevice is enabled on your phone</li>
<li><strong>Build Errors</strong>: Verify Go installation and GOPATH configuration</li>
<li><strong>Windows Compilation</strong>: Install TDM-GCC or Visual Studio Build Tools</li>
<li><strong>Bridge Connection</strong>: Check firewall settings and port availability</li>
</ul>
<hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Message Search and Analysis</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Search your message history</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Search for messages about the project deadline from last week"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Analyze conversation patterns</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"What were the main topics discussed with John in the last month?"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>For detailed setup instructions and advanced configuration, see the <a href="https://github.com/lharries/whatsapp-mcp" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<p>Pro Tip</p>
<p>Set up Claude Code to monitor messages sent to your own WhatsApp number. By messaging yourself and starting with &quot;claude&quot;, it allows you to access Claude Code remotely from any device with WhatsApp access - including desktop, mobile and smartwatch.</p>
<h5 id="extensibility" tabindex="-1"><a class="header-anchor" href="#extensibility"><span>Extensibility</span></a></h5>
<p>WhatsApp MCP provides a great foundation for additional functionality. The repository can be easily extended to accommodate custom functionality beyond the default messaging capabilities.</p>
<img src="/img/discovery/004.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>WhatsApp MCP is developed by lharries as a community project. For technical support and setup assistance, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


