<template><div><h1 id="contact-claudelog" tabindex="-1"><a class="header-anchor" href="#contact-claudelog"><span>Contact | ClaudeLog</span></a></h1>
<h2 id="get-in-touch​" tabindex="-1"><a class="header-anchor" href="#get-in-touch​"><span>Get in Touch<a href="#get-in-touch" title="Direct link to Get in Touch">​</a></span></a></h2>
<p><strong>Email</strong> <a href="mailto:hello@claudelog.com" target="_blank" rel="noopener noreferrer">hello@claudelog.com</a></p>
<p><strong>Reddit</strong> <a href="https://www.reddit.com/user/inventor_black/" target="_blank" rel="noopener noreferrer">InventorBlack</a></p>
<p><strong>LinkedIn</strong> <a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer">Wilfred Kasekende</a></p>
<hr>
<h2 id="claude-md-vault-submissions​" tabindex="-1"><a class="header-anchor" href="#claude-md-vault-submissions​"><span>CLAUDE.md Vault Submissions<a href="#claudemd-vault-submissions" title="Direct link to CLAUDE.md Vault Submissions">​</a></span></a></h2>
<p>Got a cool <code v-pre>CLAUDE.md</code> you'd like to share? Send it over! I'm always looking for interesting examples to add to the vault.</p>
<p><strong>What to include:</strong></p>
<ul>
<li>Your <code v-pre>CLAUDE.md</code> file</li>
<li>Brief description of what it does</li>
<li>Any setup notes or dependencies</li>
</ul>
<p>Contact me on Reddit: <a href="https://www.reddit.com/user/inventor_black/" target="_blank" rel="noopener noreferrer">InventorBlack</a></p>
<hr>
<h2 id="community​" tabindex="-1"><a class="header-anchor" href="#community​"><span>Community<a href="#community" title="Direct link to Community">​</a></span></a></h2>
<p>Join the discussion on <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a> where we talk about Claude Code mechanics, share tips, and help each other out.</p>
<h5 id="want-to-contribute" tabindex="-1"><a class="header-anchor" href="#want-to-contribute"><span>Want to Contribute?</span></a></h5>
<p>Want to contribute? Get in contact on Reddit! ClaudeLog is the culmination of the findings from <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a>.</p>
<img src="/img/discovery/022_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<ul>
<li><a href="#get-in-touch">Get in Touch</a></li>
<li><a href="#claudemd-vault-submissions">CLAUDE.md Vault Submissions</a></li>
<li><a href="#community">Community</a></li>
</ul>
</div></template>


