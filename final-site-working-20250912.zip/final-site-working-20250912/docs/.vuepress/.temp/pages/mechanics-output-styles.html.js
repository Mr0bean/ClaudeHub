import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-output-styles.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-output-styles.html\",\"title\":\"Output Styles | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Output Styles | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-output-styles.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
