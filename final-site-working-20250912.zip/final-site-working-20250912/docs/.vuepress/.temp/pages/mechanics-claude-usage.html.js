import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-claude-usage.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-claude-usage.html\",\"title\":\"Claude Usage | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Claude Usage | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-claude-usage.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
