<template><div><h1 id="split-role-sub-agents-claudelog" tabindex="-1"><a class="header-anchor" href="#split-role-sub-agents-claudelog"><span>Split Role Sub-Agents | ClaudeLog</span></a></h1>
<p>A fascinating mechanic the <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">Reddit community</a> brought to my attention is the ability to designate different roles to sub-agents.</p>
<h3 id="the-role-foundation​" tabindex="-1"><a class="header-anchor" href="#the-role-foundation​"><span>The Role Foundation<a href="#the-role-foundation" title="Direct link to The Role Foundation">​</a></span></a></h3>
<p>Anthropic have <a href="https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/system-prompts" target="_blank" rel="noopener noreferrer">openly discussed</a> providing Claude with a <code v-pre>Role</code> which helps get him in the zone for the task at hand, for example:</p>
<blockquote>
<p>Your role is as a seasoned security expert which specialises in pen testing.</p>
</blockquote>
<p>Multiple members of the community have created sophisticated tools for orchestrating sub-agent roles. <RouteLink to="/claude-code-mcps/super-claude/">SuperClaude</RouteLink> provides <strong>9 cognitive personas</strong> (architect, frontend, backend, security, analyzer, qa, performance, refactorer, mentor) that can be applied as universal flags to any command. <RouteLink to="/claude-code-mcps/claudia/">Claudia</RouteLink> offers <strong>custom AI agents</strong> with tailored system prompts through a GUI interface for coordinating different agent roles.</p>
<hr>
<hr>
<h3 id="native-implementation​" tabindex="-1"><a class="header-anchor" href="#native-implementation​"><span>Native Implementation<a href="#native-implementation" title="Direct link to Native Implementation">​</a></span></a></h3>
<p>However, I am old school and love exploring a tool's raw mechanics without third-party dependencies. So I experimented with asking Claude to <code v-pre>Utilise multiple sub-agents to validate this code from multiple perspectives</code>.</p>
<p><strong>Sub-Agent Coordination Strategy:</strong></p>
<ol>
<li><strong>Setup Phase</strong> - Ensure Claude is in <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink> and that <RouteLink to="/mechanics/ultrathink-plus-plus/">ultrathink</RouteLink> is instantiated</li>
<li><strong>Role Suggestion</strong> - Claude automatically suggests various relevant roles applicable to the task</li>
<li><strong>Perspective Selection</strong> - Select the kind of perspectives you want the task reviewed from</li>
<li><strong>Parallel Analysis</strong> - Sub-agents complete their review using their specialized approaches</li>
<li><strong>Consolidation</strong> - Findings are consolidated and presented by Claude</li>
</ol>
<p><strong>Perspective Selection Examples:</strong></p>
<p>After multiple successful attempts it becomes second nature to suggest quirky perspectives for Claude to analyse tasks/problems from different perspectives.</p>
<p><strong>Code Review Tasks:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Create sub-agents and analyse the problem from the following perspectives:</span>
<span class="line"></span>
<span class="line">factual, senior engineer, security expert, consistency reviewer, redundancy checker</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>User Experience Tasks:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Create sub-agents and analyse the problem from a:</span>
<span class="line"></span>
<span class="line">creative, nooby user, designer, marketing, seo perspective</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Documentation Tasks:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Create sub-agents to review this documentation from the following perspectives:</span>
<span class="line"></span>
<span class="line">technical accuracy, beginner accessibility, SEO optimization, content clarity</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Interestingly enough each perspective naturally gravitates toward different tools based on their role and problem-solving approach. This creates a more comprehensive analysis as different agents instinctively choose the most relevant combination of tools for their domain of expertise.</p>
<p><strong>Performance &amp; Cost Optimization:</strong></p>
<p>This mechanic delivers exceptional value by maximizing Claude 4 Sonnet's capabilities through strategic orchestration. Rather than reaching for the 5x more expensive Opus model, split role sub-agents combined with <RouteLink to="/mechanics/ultrathink-plus-plus/">ultrathink</RouteLink> unlock sophisticated analysis at Sonnet pricing. The parallel nature of <RouteLink to="/mechanics/task-agent-tools/">Task</RouteLink> execution means multiple expert roles can analyze the same problem simultaneously, creating multiple insights that would be difficult to achieve through single-role analysis (due to previous roles and context influencing the context window).</p>
<h3 id="beyond-coding-applications​" tabindex="-1"><a class="header-anchor" href="#beyond-coding-applications​"><span>Beyond Coding Applications<a href="#beyond-coding-applications" title="Direct link to Beyond Coding Applications">​</a></span></a></h3>
<p>This mechanic applies beyond coding! I have used noob, seo, engineer, vibe coder, non-coder perspectives to get additional opinions on aspects of ClaudeLog and it all happens in parallel safely within <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>.</p>
<p>The beauty of split role sub-agents lies in their scalability - you can adapt the perspective combinations to any domain or problem type. Start with the fundamental technical perspectives, then experiment with creative combinations as you discover what insights each role type reveals. <RouteLink to="/mechanics/always-be-experimenting/">A.B.E</RouteLink> (Always be experimenting)</p>
<h5 id="multi-perspective-analysis" tabindex="-1"><a class="header-anchor" href="#multi-perspective-analysis"><span>Multi-Perspective Analysis</span></a></h5>
<p>The power of split role sub-agents lies in their ability to surface insights you neither a single Claude instance could surface alone. Each perspective uses different tools and approaches, creating a comprehensive analysis that dramatically improves decision quality.</p>
<p>&lt;img src=&quot;/img/discovery/023_excite_orange.png&quot; alt=&quot;Custom image&quot; style=&quot;max-width: 165px; height: auto;&quot; /&gt;</p>
<h5 id="pushing-the-limit" tabindex="-1"><a class="header-anchor" href="#pushing-the-limit"><span>Pushing the Limit</span></a></h5>
<p>Utilise <code v-pre>Claude 4 Sonnet</code> + <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink> + <code v-pre>ultrathink</code> + <code v-pre>role sub-agents</code> to extract the maximum performance from the Claude 4 Sonnet model, prior to reaching for the 5x more expensive and often overkill Claude 4 Opus model.</p>
<img src="/img/discovery/037_sonnet_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink>|<RouteLink to="/mechanics/tactical-model-selection/">Tactical Model Selection</RouteLink>|<RouteLink to="/mechanics/always-be-experimenting/">Always Be Experimenting</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#the-role-foundation">The Role Foundation</a></li>
<li><a href="#native-implementation">Native Implementation</a></li>
<li><a href="#beyond-coding-applications">Beyond Coding Applications</a></li>
</ul>
</div></template>


