<template><div><h1 id="install-claude-code-claudelog" tabindex="-1"><a class="header-anchor" href="#install-claude-code-claudelog"><span>Install Claude Code | ClaudeLog</span></a></h1>
<p>Get Claude Code up and running on your system in just a few steps. This complete Claude Code installation and setup guide covers download, installation, configuration, and model selection for Windows, Mac, and Linux systems.</p>
<p><strong>Note:</strong> For the most up-to-date installation instructions, visit the <a href="https://docs.anthropic.com/en/docs/claude-code" target="_blank" rel="noopener noreferrer">official Claude Code documentation</a>.</p>
<hr>
<hr>
<h2 id="claude-code-system-requirements-and-prerequisites​" tabindex="-1"><a class="header-anchor" href="#claude-code-system-requirements-and-prerequisites​"><span>Claude Code System Requirements and Prerequisites<a href="#claude-code-system-requirements-and-prerequisites" title="Direct link to Claude Code System Requirements and Prerequisites">​</a></span></a></h2>
<p>Claude Code supports the following operating systems:</p>
<ul>
<li><strong>macOS</strong> 10.15 (Catalina) or later</li>
<li><strong>Windows</strong> 10 or later</li>
<li><strong>Linux</strong> (Ubuntu 18.04+, CentOS 7+, or equivalent)</li>
</ul>
<p><strong>Hardware Requirements:</strong></p>
<ul>
<li>4GB RAM minimum (16GB is my recommendation)</li>
<li>500MB available disk space</li>
<li>Internet connection for API communication</li>
</ul>
<h2 id="prerequisites​" tabindex="-1"><a class="header-anchor" href="#prerequisites​"><span>Prerequisites<a href="#prerequisites" title="Direct link to Prerequisites">​</a></span></a></h2>
<p>Before installing Claude Code, make sure you have:</p>
<ul>
<li><strong>Node.js</strong> version 18.0 or higher</li>
<li>An <strong>Anthropic API key</strong> (get one from <a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer">console.anthropic.com</a>)</li>
<li>A terminal or command prompt</li>
</ul>
<hr>
<hr>
<h2 id="how-to-install-claude-code-step-by-step-methods​" tabindex="-1"><a class="header-anchor" href="#how-to-install-claude-code-step-by-step-methods​"><span>How to Install Claude Code: Step-by-Step Methods<a href="#how-to-install-claude-code-step-by-step-methods" title="Direct link to How to Install Claude Code: Step-by-Step Methods">​</a></span></a></h2>
<h3 id="option-1-npm-recommended-​" tabindex="-1"><a class="header-anchor" href="#option-1-npm-recommended-​"><span>Option 1: npm (Recommended)<a href="#option-1-npm-recommended" title="Direct link to Option 1: npm (Recommended)">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> @anthropic-ai/claude-code</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h2 id="claude-code-setup-and-configuration-guide​" tabindex="-1"><a class="header-anchor" href="#claude-code-setup-and-configuration-guide​"><span>Claude Code Setup and Configuration Guide<a href="#claude-code-setup-and-configuration-guide" title="Direct link to Claude Code Setup and Configuration Guide">​</a></span></a></h2>
<h3 id="api-key-configuration​" tabindex="-1"><a class="header-anchor" href="#api-key-configuration​"><span>API Key Configuration<a href="#api-key-configuration" title="Direct link to API Key Configuration">​</a></span></a></h3>
<p>After installation, configure Claude Code with your API key:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude config</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>You'll complete a one-time OAuth process with your Claude Max or Anthropic Console account.</p>
<h3 id="alternative-environment-variable​" tabindex="-1"><a class="header-anchor" href="#alternative-environment-variable​"><span>Alternative: Environment Variable<a href="#alternative-environment-variable" title="Direct link to Alternative: Environment Variable">​</a></span></a></h3>
<p>You can also set your API key using an environment variable:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_API_KEY</span><span class="token operator">=</span><span class="token string">"your-api-key-here"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Add this to your shell profile (<code v-pre>.bashrc</code>, <code v-pre>.zshrc</code>, etc.) to make it persistent.</p>
<hr>
<h3 id="claude-max-subscription​" tabindex="-1"><a class="header-anchor" href="#claude-max-subscription​"><span>Claude Max Subscription<a href="#claude-max-subscription" title="Direct link to Claude Max Subscription">​</a></span></a></h3>
<p><strong>Important:</strong> The Anthropic API is pay-per-use and can become expensive with frequent usage. For regular Claude Code users, a <a href="https://claude.ai/upgrade" target="_blank" rel="noopener noreferrer">Claude Max subscription</a> is likely the more economical option. Claude Max provides higher usage limits at a fixed monthly cost, making it ideal for developers using Claude Code extensively.</p>
<p>Consider Claude Max if you plan to:</p>
<ul>
<li>Use Claude Code for multiple hours per day</li>
<li>Work on large codebases</li>
<li>Perform complex multi-file operations regularly</li>
</ul>
<p><strong>Getting Started:</strong> If you're unsure about your usage patterns, consider starting with ~$20 in API credits to test Claude Code with your typical workflows. This will help you determine whether the Claude Max subscription is worth the investment for your specific use case.</p>
<p>For complete pricing breakdown and plan comparison, see our <RouteLink to="/claude-code-pricing/">Claude AI Pricing Guide</RouteLink>.</p>
<p><em>Disclaimer: The author uses Claude Max 5x.</em></p>
<hr>
<hr>
<h3 id="claude-code-model-selection-and-configuration​" tabindex="-1"><a class="header-anchor" href="#claude-code-model-selection-and-configuration​"><span>Claude Code Model Selection and Configuration<a href="#claude-code-model-selection-and-configuration" title="Direct link to Claude Code Model Selection and Configuration">​</a></span></a></h3>
<p>Claude Code supports multiple models. You can specify which model to use for optimal performance:</p>
<p><strong>Claude 4 Sonnet:</strong> Latest balanced performance and speed</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-sonnet-4-20250514"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude 4 Opus:</strong> Maximum capability for complex tasks</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-opus-4-20250514"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude 3.5 Haiku:</strong> Fastest and most cost-effective</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-3-5-haiku-20241022"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Important limitations: Claude 3.5 Haiku</p>
<p>While Haiku is cost-effective, it has significant limitations for Claude Code usage:</p>
<ul>
<li><strong>Reduced reasoning capabilities</strong> - Struggles with complex multi-step planning and architectural decisions</li>
<li><strong>Limited context understanding</strong> - Less effective at analyzing large codebases and maintaining context across multiple files</li>
<li><strong>Simplified code analysis</strong> - May miss subtle bugs, dependencies, or complex patterns that modern models catch</li>
<li><strong>Basic refactoring only</strong> - Not suitable for sophisticated restructuring or feature implementations</li>
<li><strong>Limited framework knowledge</strong> - Less effective with complex frameworks or novel coding patterns</li>
</ul>
<p><strong>Recommended use cases for Haiku:</strong></p>
<ul>
<li>Simple single-file edits</li>
<li>Basic syntax corrections</li>
<li>Quick code questions</li>
<li>Learning Claude Code basics before upgrading</li>
</ul>
<p>For serious development work, Claude 4 Sonnet or Opus provide substantially better results and are worth the additional cost.</p>
<p><strong>Alternative Method:</strong> You can also specify the model directly when starting Claude Code:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude <span class="token parameter variable">--model</span> claude-sonnet-4-20250514</span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">--model</span> claude-opus-4-20250514</span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">--model</span> claude-3-5-haiku-20241022</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>To monitor your usage and costs, consider the <RouteLink to="/claude-code-mcps/cc-usage/">cc-usage add-on</RouteLink>.</p>
<p>For detailed model comparison and selection guidance, see our <RouteLink to="/model-comparison/">Complete Model Comparison Guide</RouteLink>.</p>
<hr>
<hr>
<h2 id="platform-specific-claude-code-setup-windows-mac-and-linux​" tabindex="-1"><a class="header-anchor" href="#platform-specific-claude-code-setup-windows-mac-and-linux​"><span>Platform-Specific Claude Code Setup: Windows, Mac, and Linux<a href="#platform-specific-claude-code-setup-windows-mac-and-linux" title="Direct link to Platform-Specific Claude Code Setup: Windows, Mac, and Linux">​</a></span></a></h2>
<h3 id="claude-code-windows-setup​" tabindex="-1"><a class="header-anchor" href="#claude-code-windows-setup​"><span>Claude Code Windows Setup<a href="#claude-code-windows-setup" title="Direct link to Claude Code Windows Setup">​</a></span></a></h3>
<p>For the best Claude Code experience on Windows, follow these optimization steps:</p>
<h4 id="wsl2-installation-and-configuration​" tabindex="-1"><a class="header-anchor" href="#wsl2-installation-and-configuration​"><span>WSL2 Installation and Configuration<a href="#wsl2-installation-and-configuration" title="Direct link to WSL2 Installation and Configuration">​</a></span></a></h4>
<p><strong>1. Install WSL2</strong> (if not already installed):</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">wsl <span class="token parameter variable">--install</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>2. Install a Linux distribution</strong> (Ubuntu recommended):</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">wsl <span class="token parameter variable">--install</span> <span class="token parameter variable">-d</span> Ubuntu</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>3. WSL2 Performance Optimization:</strong></p>
<p>Set WSL2 memory limit by creating <code v-pre>.wslconfig</code> in your Windows user directory:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># In Windows: %USERPROFILE%\.wslconfig</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">[</span>wsl2<span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">memory</span><span class="token operator">=</span>8GB          <span class="token comment"># Limit WSL2 memory usage</span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">processors</span><span class="token operator">=</span><span class="token number">4</span>        <span class="token comment"># Limit CPU cores</span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">swap</span><span class="token operator">=</span>2GB           <span class="token comment"># Set swap size</span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">localhostForwarding</span><span class="token operator">=</span>true</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>4. Update WSL2 to latest version:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">wsl <span class="token parameter variable">--update</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><h4 id="terminal-recommendation​" tabindex="-1"><a class="header-anchor" href="#terminal-recommendation​"><span>Terminal Recommendation<a href="#terminal-recommendation" title="Direct link to Terminal Recommendation">​</a></span></a></h4>
<p>I personally use Windows Terminal app for Claude Code development. You can download it from the <a href="https://apps.microsoft.com/store/detail/windows-terminal/9N0DX20HK701" target="_blank" rel="noopener noreferrer">Microsoft Store</a> or <a href="https://github.com/Microsoft/Terminal/releases" target="_blank" rel="noopener noreferrer">GitHub releases</a>.</p>
<h4 id="claude-code-vs-code-integration​" tabindex="-1"><a class="header-anchor" href="#claude-code-vs-code-integration​"><span>Claude Code VS Code Integration<a href="#claude-code-vs-code-integration" title="Direct link to Claude Code VS Code Integration">​</a></span></a></h4>
<p><strong>1. Install VS Code Extensions:</strong></p>
<ul>
<li><strong>WSL Extension:</strong> <code v-pre>ms-vscode-remote.remote-wsl</code></li>
<li><strong>Remote Development Extension Pack:</strong> <code v-pre>ms-vscode-remote.vscode-remote-extensionpack</code></li>
</ul>
<p><strong>2. Connect VS Code to WSL:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># From WSL terminal in your project directory</span></span>
<span class="line"></span>
<span class="line">code <span class="token builtin class-name">.</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>3. Install Claude Code VS Code Extension:</strong> Install the official Claude Code extension from the <a href="https://marketplace.visualstudio.com/items?itemName=codeflow-studio.claude-code-extension" target="_blank" rel="noopener noreferrer">VS Code Marketplace</a> or search for &quot;Claude Code&quot; in VS Code's Extensions panel.</p>
<p><strong>4. Restart VS Code</strong> completely for the extension to take effect.</p>
<p><strong>5. Use Claude Code with VS Code:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># In VS Code integrated terminal (WSL)</span></span>
<span class="line"></span>
<span class="line">claude</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Or use /ide command from any external terminal to connect</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>6. VS Code Integration Features:</strong></p>
<ul>
<li>Use <code v-pre>Cmd+Esc</code> (Mac) or <code v-pre>Ctrl+Esc</code> (Windows/Linux) to open Claude Code directly</li>
<li>File references: <code v-pre>Cmd+Option+K</code> (Mac) or <code v-pre>Alt+Ctrl+K</code> (Windows/Linux) to insert file references</li>
<li>View proposed changes in VS Code's diff viewer</li>
</ul>
<hr>
<hr>
<h2 id="verify-claude-code-installation-testing-your-setup​" tabindex="-1"><a class="header-anchor" href="#verify-claude-code-installation-testing-your-setup​"><span>Verify Claude Code Installation: Testing Your Setup<a href="#verify-claude-code-installation-testing-your-setup" title="Direct link to Verify Claude Code Installation: Testing Your Setup">​</a></span></a></h2>
<p>Verify your Claude Code installation by running:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude <span class="token parameter variable">--version</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>You should see the current version of Claude Code printed to the terminal.</p>
<h5 id="installation-complete" tabindex="-1"><a class="header-anchor" href="#installation-complete"><span>Installation Complete</span></a></h5>
<p>With Claude Code successfully installed, you now have access to one of the most powerful AI development tools available. Every great development journey begins with a solid foundation.</p>
<img src="/img/discovery/014.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/claude-code-pricing/">Pricing Plans</RouteLink>|<RouteLink to="/faq/">FAQs</RouteLink>|<RouteLink to="/claude-code-mcps/">MCPs &amp; Add-ons</RouteLink>|<RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink></p>
<ul>
<li><a href="#claude-code-system-requirements-and-prerequisites">Claude Code System Requirements and Prerequisites</a></li>
<li><a href="#prerequisites">Prerequisites</a></li>
<li><a href="#how-to-install-claude-code-step-by-step-methods">How to Install Claude Code: Step-by-Step Methods</a>
<ul>
<li><a href="#option-1-npm-recommended">Option 1: npm (Recommended)</a></li>
</ul>
</li>
<li><a href="#claude-code-setup-and-configuration-guide">Claude Code Setup and Configuration Guide</a>
<ul>
<li><a href="#api-key-configuration">API Key Configuration</a></li>
<li><a href="#alternative-environment-variable">Alternative: Environment Variable</a></li>
<li><a href="#claude-max-subscription">Claude Max Subscription</a></li>
<li><a href="#claude-code-model-selection-and-configuration">Claude Code Model Selection and Configuration</a></li>
</ul>
</li>
<li><a href="#platform-specific-claude-code-setup-windows-mac-and-linux">Platform-Specific Claude Code Setup: Windows, Mac, and Linux</a>
<ul>
<li><a href="#claude-code-windows-setup">Claude Code Windows Setup</a></li>
</ul>
</li>
<li><a href="#verify-claude-code-installation-testing-your-setup">Verify Claude Code Installation: Testing Your Setup</a></li>
</ul>
</div></template>


