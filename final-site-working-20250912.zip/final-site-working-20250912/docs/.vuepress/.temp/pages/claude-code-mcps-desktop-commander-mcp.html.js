import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/claude-code-mcps-desktop-commander-mcp.html.vue"
const data = JSON.parse("{\"path\":\"/claude-code-mcps-desktop-commander-mcp.html\",\"title\":\"Desktop Commander MCP | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Desktop Commander MCP | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"claude-code-mcps-desktop-commander-mcp.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
