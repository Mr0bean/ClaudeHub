<template><div><h1 id="context-inspection-claudelog" tabindex="-1"><a class="header-anchor" href="#context-inspection-claudelog"><span>Context Inspection | ClaudeLog</span></a></h1>
<p>The <code v-pre>/context</code> slash command is a new feature which dropped in <code v-pre>v1.0.86</code> which allows you to see an approximation of your context usage across different components:</p>
<ul>
<li><strong>System Prompt</strong> - Core instructions and behavior definitions</li>
<li><strong>System tools</strong> - Built-in Claude Code functionality</li>
<li><strong>MCP tools</strong> - Model Context Protocol server integrations</li>
<li><strong>Memory files</strong> - <code v-pre>CLAUDE.md</code> and project context</li>
<li><strong>Custom Agents</strong> - Specialized sub-agent definitions</li>
<li><strong>Messages</strong> - Current conversation history</li>
</ul>
<p>It shows how many tokens are used and what percentage of your context window is remaining.</p>
<blockquote>
<p>This is the ultimate tool for <code v-pre>Context Engineers</code>.</p>
</blockquote>
<hr>
<hr>
<h3 id="strategic-context-engineering​" tabindex="-1"><a class="header-anchor" href="#strategic-context-engineering​"><span>Strategic Context Engineering<a href="#strategic-context-engineering" title="Direct link to Strategic Context Engineering">​</a></span></a></h3>
<p>I am particularly interested in the ease of access to metrics about <RouteLink to="/mechanics/custom-agents/">Custom agents</RouteLink> and <RouteLink to="/claude-code-mcps/">MCP tools</RouteLink>. Given the existence of <RouteLink to="/mechanics/context-window-depletion/">context window based performance depletion</RouteLink>, it is important for us as context engineers to craft the context as efficiently as possible.</p>
<p>We can now tactically enable/disable MCP tool functions with full knowledge about how many tokens are being consumed. No more guessing whether that MCP server functions is worth the context overhead.</p>
<p>The same principle applies to <code v-pre>Custom Agents</code> which are designed by Anthropic to be easily discovered, shared, downloaded and invoked. As I mentioned in <RouteLink to="/mechanics/agent-engineering/">Agent Engineering</RouteLink>, it is important to refine your agents so that they can easily be activated but also so that they are context efficient. The <code v-pre>/context</code> command allows us to have better introspection into how efficient our <code v-pre>Custom Agents</code> are.</p>
<hr>
<hr>
<h3 id="current-limitations-and-future-potential​" tabindex="-1"><a class="header-anchor" href="#current-limitations-and-future-potential​"><span>Current Limitations and Future Potential<a href="#current-limitations-and-future-potential" title="Direct link to Current Limitations and Future Potential">​</a></span></a></h3>
<p>Initial use has flagged that the accuracy for context calculations can sometimes be off. However, I believe the value lies more in engineering what is fundamentally in your context, which affects your baseline performance. I anticipate the accuracy of the tool improving over time as Anthropic makes subtle adjustments to the way context is computed.</p>
<p>A potential upgrade of this user interface would be being able to use the arrow keys to navigate through the items and toggle them on/off so we can effectively <code v-pre>free up</code> space within the context. This would likely require a Claude reload but it would create a more seamless <code v-pre>Context Engineering</code> experience.</p>
<h3 id="integration-with-other-mechanics​" tabindex="-1"><a class="header-anchor" href="#integration-with-other-mechanics​"><span>Integration with Other Mechanics<a href="#integration-with-other-mechanics" title="Direct link to Integration with Other Mechanics">​</a></span></a></h3>
<p>This tool in combination with features like the <code v-pre>Micro compact</code> feature which automatically frees up space within the context window related to tool calls helps create a more streamlined experience for managing context efficiently throughout long sessions.</p>
<hr>
<hr>
<h3 id="interactive-context-analysis​" tabindex="-1"><a class="header-anchor" href="#interactive-context-analysis​"><span>Interactive Context Analysis<a href="#interactive-context-analysis" title="Direct link to Interactive Context Analysis">​</a></span></a></h3>
<p>A cool thing I explored is after generating the context data, I asked Claude:</p>
<blockquote>
<p>Where is my context potentially inefficient?</p>
</blockquote>
<p>And he provided suggestions about how the context could be engineered to be more efficient. This creates a feedback loop where you can identify bottlenecks and optimize accordingly.</p>
<p><strong>Mechanic Benefits:</strong></p>
<ul>
<li><strong>Token visibility</strong>: Clear breakdown of context consumption across all components</li>
<li><strong>Strategic optimization</strong>: Data-driven decisions about MCP tools and Custom Agents</li>
<li><strong>Performance engineering</strong>: Identify context bloat before it impacts response quality</li>
<li><strong>Baseline awareness</strong>: Understand your fundamental context overhead for better planning</li>
<li><strong>Interactive analysis</strong>: Ask Claude to review and suggest context improvements</li>
</ul>
<h5 id="context-engineering" tabindex="-1"><a class="header-anchor" href="#context-engineering"><span>Context Engineering</span></a></h5>
<p>Ask Claude to review your context usage and suggest optimizations. Use <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink> combined with <RouteLink to="/faqs/what-is-ultrathink/">ultrathink</RouteLink> for comprehensive analysis: &quot;Where is my context potentially inefficient and how can I optimize it?&quot;</p>
<img src="/img/discovery/013_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/context-window-depletion/">Context Window Depletion</RouteLink>|<RouteLink to="/mechanics/agent-engineering/">Agent Engineering</RouteLink>|<RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#strategic-context-engineering">Strategic Context Engineering</a></li>
<li><a href="#current-limitations-and-future-potential">Current Limitations and Future Potential</a></li>
<li><a href="#integration-with-other-mechanics">Integration with Other Mechanics</a></li>
<li><a href="#interactive-context-analysis">Interactive Context Analysis</a></li>
</ul>
</div></template>


