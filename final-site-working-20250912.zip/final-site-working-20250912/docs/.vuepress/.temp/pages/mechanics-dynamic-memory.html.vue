<template><div><h1 id="dynamic-memory-claudelog" tabindex="-1"><a class="header-anchor" href="#dynamic-memory-claudelog"><span>Dynamic Memory | ClaudeLog</span></a></h1>
<p>When Claude Code is in interactive mode you can have Claude modify its own <code v-pre>CLAUDE.md</code> temporarily to run tasks with a specific context. After the task is completed you can ask Claude to revert the <code v-pre>CLAUDE.md</code> back to its previous state. There are several ways of backing up the <code v-pre>CLAUDE.md</code>:</p>
<ul>
<li><strong>Git versioning</strong>: Use git stash or commit before changes for easy rollback</li>
<li><strong>File duplication</strong>: Have Claude copy to a backup filename like <code v-pre>CLAUDE.md.backup</code></li>
</ul>
<p>To change the information persisted through the <code v-pre>CLAUDE.md</code> interface you can use 'quick Memory' with #.</p>
<hr>
<hr>
<p>This mechanic is useful if you have a <code v-pre>CLAUDE.md</code> library which specifies the processes for performing different tasks. Unfortunately, Claude is currently unable to read changes to his <code v-pre>CLAUDE.md</code> into 'memory' unless it utilises explicit commands such as:</p>
<ul>
<li><strong>Quick Memory</strong>: Using # commands to temporarily change persisted information</li>
<li><strong>Memory refresh commands</strong>: Explicitly asking Claude to re-read the modified <code v-pre>CLAUDE.md</code></li>
<li><strong>Session restart</strong>: Starting a new Claude Code session to pick up changes</li>
<li><strong>Explicit file reads</strong>: Using read commands to load the updated content</li>
</ul>
<p>This led to me exploring getting Claude to spawn another instance of itself in a directory which has a different <code v-pre>CLAUDE.md</code>. The benefits being:</p>
<ul>
<li><strong>Cleaner context separation</strong>: Each spawned instance operates with its own specific <code v-pre>CLAUDE.md</code> context</li>
<li><strong>No memory reload issues</strong>: New instances automatically load their directory's <code v-pre>CLAUDE.md</code></li>
<li><strong>Parallel processing</strong>: Multiple contexts can run simultaneously without interference</li>
<li><strong>Reduced context pollution</strong>: Previous session context doesn't bleed into the new specialized task</li>
</ul>
<p><strong>Note:</strong> Claude instances will automatically crawl up the directory structure and read any <code v-pre>CLAUDE.md</code> files they encounter. So to have a strict separation of context ensure the project directory <code v-pre>CLAUDE.md</code> is lightweight and non-specific.</p>
<h5 id="directory-crawling" tabindex="-1"><a class="header-anchor" href="#directory-crawling"><span>Directory Crawling</span></a></h5>
<p>Claude instances will automatically crawl up the directory structure and read any <code v-pre>CLAUDE.md</code> files they encounter. So to have a strict separation of context ensure the project directory <code v-pre>CLAUDE.md</code> is lightweight and non-specific.</p>
<img src="/img/discovery/007.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink>|<RouteLink to="/mechanics/context-window-constraints-as-training/">Context Window Constraints</RouteLink>|<RouteLink to="/mechanics/context-window-depletion/">Context Window Depletion</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
</div></template>


