import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-poison-context-awareness.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-poison-context-awareness.html\",\"title\":\"Poison.md | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Poison.md | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-poison-context-awareness.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
