<template><div><h1 id="puppeteer-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#puppeteer-mcp-claudelog"><span>Puppeteer MCP | ClaudeLog</span></a></h1>
<p><strong>Web automation with AI vision capabilities for Claude Code</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/modelcontextprotocol" target="_blank" rel="noopener noreferrer">Model Context Protocol</a>  |  <a href="https://github.com/modelcontextprotocol/servers-archived/tree/main/src/puppeteer" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  65.5k Stars|7.7k Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Puppeteer MCP brings powerful web automation to Claude Code through the Model Context Protocol. Control headless Chrome browsers, scrape dynamic content, and automate complex web workflows with AI vision capabilities to handle cookies, captchas, and interactive elements automatically.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>AI Vision Integration</strong> - Automatically handle cookies, captchas, and interactive elements</li>
<li><strong>Headless Browser Control</strong> - Launch and control Chrome/Chromium instances programmatically</li>
<li><strong>Dynamic Content Scraping</strong> - Extract data from JavaScript-heavy and SPA applications</li>
<li><strong>High-Quality Markdown</strong> - Convert web pages to well-formatted markdown</li>
<li><strong>Screenshot &amp; PDF Generation</strong> - Capture visual content and generate documents</li>
<li><strong>Form Automation</strong> - Fill out forms, submit data, and handle user interactions</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Chrome or Chromium browser installed (auto-installed with NPX method)</li>
</ul>
<p><strong>Setup MCP Server</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Install via NPX (recommended)</span></span>
<span class="line"></span>
<span class="line">npx <span class="token parameter variable">-y</span> @modelcontextprotocol/server-puppeteer</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude Code Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"projects"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"/path/to/your/project"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"puppeteer"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"-y"</span>, <span class="token string">"@modelcontextprotocol/server-puppeteer"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Basic Web Automation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Navigate and extract content with AI vision</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Browse to the product page and extract all pricing information"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Handle complex interactions automatically</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Navigate the login form and extract user dashboard data"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Advanced Automation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># AI-powered form filling</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Fill out the registration form and handle any captchas"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Markdown conversion</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Convert the documentation page to high-quality markdown"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>For detailed automation examples and API reference, refer to the <a href="https://github.com/modelcontextprotocol/servers-archived/tree/main/src/puppeteer" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<h5 id="community-feedback" tabindex="-1"><a class="header-anchor" href="#community-feedback"><span>Community Feedback</span></a></h5>
<p>Developers find Puppeteer MCP valuable for complex web interactions that basic scraping tools can't handle. Particularly useful for navigating dynamic content, JavaScript-heavy sites, and automating multi-step workflows.</p>
<img src="/img/discovery/018.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Puppeteer MCP is part of the official Model Context Protocol servers and is licensed under the MIT License. For technical support and updates, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


