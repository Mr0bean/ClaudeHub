<template><div><h1 id="tdd-guard-claudelog" tabindex="-1"><a class="header-anchor" href="#tdd-guard-claudelog"><span>TDD Guard | ClaudeLog</span></a></h1>
<p><strong>Automated Test-Driven Development enforcement for Claude Code</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/nizos" target="_blank" rel="noopener noreferrer">@nizos</a>  |  <a href="https://github.com/nizos/tdd-guard" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  Stats unavailable</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>TDD Guard is a utility that enforces Test-Driven Development principles for Claude Code by intercepting file modification operations and validating TDD adherence. It blocks actions that violate TDD rules, specifically preventing implementation without failing tests, over-implementation beyond test requirements, and adding multiple tests simultaneously.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Test-First Enforcement</strong> - Blocks implementation without failing tests</li>
<li><strong>Over-Implementation Prevention</strong> - Prevents code beyond current test requirements</li>
<li><strong>Multiple Test Detection</strong> - Blocks adding multiple tests simultaneously</li>
<li><strong>Customizable Rules</strong> - Adjust validation rules to match your TDD style</li>
<li><strong>Multi-Language Support</strong> - Works with JavaScript, Python, PHP, Go, and Rust</li>
<li><strong>Automated Process Enforcement</strong> - Let TDD Guard handle discipline so you focus on design</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Requirements</strong></p>
<ul>
<li>Node.js 18+</li>
<li>Claude Code</li>
<li>Test framework for your language</li>
</ul>
<p><strong>Quick Start</strong></p>
<p><strong>1. Install TDD Guard</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> tdd-guard</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>2. Add Test Reporter</strong> TDD Guard needs to capture test results from your test runner. Choose your language:</p>
<ul>
<li><strong>JavaScript/TypeScript</strong></li>
<li><strong>Python (pytest)</strong></li>
<li><strong>PHP (PHPUnit)</strong></li>
<li><strong>Go</strong></li>
<li><strong>Rust</strong></li>
</ul>
<p>See the <a href="https://github.com/nizos/tdd-guard" target="_blank" rel="noopener noreferrer">official repository</a> for language-specific test reporter setup.</p>
<p><strong>3. Configure Claude Code Hook</strong> Use the <code v-pre>/hooks</code> command in Claude Code:</p>
<ol>
<li>Type <code v-pre>/hooks</code> in Claude Code</li>
<li>Select <strong>PreToolUse - Before tool execution</strong></li>
<li>Choose <strong>+ Add new matcher...</strong> and enter: <code v-pre>Write|Edit|MultiEdit|TodoWrite</code></li>
<li>Select <strong>+ Add new hook...</strong> and enter: <code v-pre>tdd-guard</code></li>
<li>Choose where to save (Project settings recommended)</li>
</ol>
<p>See <a href="https://github.com/nizos/tdd-guard" target="_blank" rel="noopener noreferrer">Strengthening TDD Enforcement</a> to prevent agents from bypassing validation.</p>
<hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p>TDD Guard runs as a separate process and validates file modifications against TDD principles. It intercepts <code v-pre>Write</code>, <code v-pre>Edit</code>, and <code v-pre>MultiEdit</code> operations, checking for three primary TDD violations:</p>
<ol>
<li>Implementing functionality without a failing test</li>
<li>Over-implementing beyond test requirements</li>
<li>Adding multiple tests simultaneously</li>
</ol>
<p>This automation lets you focus on problem-solving and design instead of manually policing TDD process adherence.</p>
<p><strong>Security Notice</strong> TDD Guard hooks execute with your full user permissions. Review hook configurations carefully and ensure your development environment is properly secured.</p>
<p>For detailed configuration options and advanced usage patterns, see the <a href="https://github.com/nizos/tdd-guard" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<hr>
<h3 id="benefits​" tabindex="-1"><a class="header-anchor" href="#benefits​"><span>Benefits<a href="#benefits" title="Direct link to Benefits">​</a></span></a></h3>
<p>TDD Guard automates TDD discipline enforcement, providing several key advantages:</p>
<ul>
<li><strong>Consistent Code Quality</strong> - Prevents common AI coding mistakes like jumping straight to implementation</li>
<li><strong>Thorough Test Coverage</strong> - Ensures tests are written first and cover all functionality</li>
<li><strong>Living Documentation</strong> - Your test suite becomes comprehensive documentation of your codebase</li>
<li><strong>Focus on Design</strong> - Automated process enforcement lets you concentrate on problem-solving</li>
<li><strong>Extended Enforcement</strong> - Can be configured to enforce additional coding standards beyond TDD</li>
</ul>
<p>Performance Note</p>
<p>Be aware that TDD Guard can introduce lag to your <code v-pre>Write</code>, <code v-pre>Edit</code>, <code v-pre>MultiEdit</code>, and <code v-pre>TodoWrite</code> operations as it validates each action against TDD principles.</p>
<h5 id="tdd-automation" tabindex="-1"><a class="header-anchor" href="#tdd-automation"><span>TDD Automation</span></a></h5>
<p>TDD Guard automates the discipline of Test-Driven Development, letting you focus on problem-solving and design while ensuring consistent adherence to TDD principles.</p>
<img src="/img/discovery/035_plan.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>TDD Guard is developed by Nizar and is open-source under MIT License. For technical support, configuration help, and community discussions, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
<li><a href="#benefits">Benefits</a></li>
</ul>
</div></template>


