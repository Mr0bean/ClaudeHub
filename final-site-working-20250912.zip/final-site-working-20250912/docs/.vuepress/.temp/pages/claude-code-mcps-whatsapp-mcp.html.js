import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/claude-code-mcps-whatsapp-mcp.html.vue"
const data = JSON.parse("{\"path\":\"/claude-code-mcps-whatsapp-mcp.html\",\"title\":\"WhatsApp MCP | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"WhatsApp MCP | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"claude-code-mcps-whatsapp-mcp.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
