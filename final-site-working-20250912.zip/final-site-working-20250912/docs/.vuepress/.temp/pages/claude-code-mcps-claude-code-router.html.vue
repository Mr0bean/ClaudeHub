<template><div><h1 id="claude-code-router-claudelog" tabindex="-1"><a class="header-anchor" href="#claude-code-router-claudelog"><span>Claude Code Router | ClaudeLog</span></a></h1>
<p><strong>Use Claude Code without an Anthropic account through intelligent AI provider routing</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/musistudio" target="_blank" rel="noopener noreferrer">@musistudio</a>  |  <a href="https://github.com/musistudio/claude-code-router" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  15k Stars|1.1k Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Claude Code Router is a proxy tool that enables Claude Code functionality without requiring an Anthropic account. It intercepts Claude Code requests and routes them to alternative AI providers like OpenRouter, DeepSeek, Ollama, and Gemini, giving you access to Claude Code's interface while using any supported AI model.</p>
<hr>
<hr>
<!-- Screenshot temporarily removed due to missing asset -->
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>No Anthropic Account Required</strong> - Use Claude Code interface with alternative AI providers</li>
<li><strong>8+ Supported Providers</strong> - OpenRouter, DeepSeek, Ollama, Gemini, VolcEngine, SiliconFlow, ModelScope, DashScope</li>
<li><strong>Dynamic Model Switching</strong> - Change models mid-session with <code v-pre>/model provider,model_name</code> commands</li>
<li><strong>Context-Based Routing</strong> - Automatic routing for default, background, reasoning, and long-context tasks</li>
<li><strong>Custom Transformers</strong> - Configure request/response transformations for provider compatibility</li>
<li><strong>GitHub Actions Integration</strong> - CI/CD workflow support with automated model routing</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Node.js runtime environment</li>
<li>Claude Code: <code v-pre>npm install -g @anthropic-ai/claude-code</code></li>
</ul>
<p><strong>Install Router</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Install the router globally</span></span>
<span class="line"></span>
<span class="line"><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> @musistudio/claude-code-router</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Configuration Setup</strong> Create <code v-pre>~/.claude-code-router/config.json</code> with your preferred AI providers:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"Providers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"name"</span><span class="token builtin class-name">:</span> <span class="token string">"openrouter"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"api_base_url"</span><span class="token builtin class-name">:</span> <span class="token string">"https://openrouter.ai/api/v1/chat/completions"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"api_key"</span><span class="token builtin class-name">:</span> <span class="token string">"sk-xxx"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"models"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"anthropic/claude-3.5-sonnet"</span>, <span class="token string">"google/gemini-2.5-pro-preview"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"name"</span><span class="token builtin class-name">:</span> <span class="token string">"deepseek"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"api_base_url"</span><span class="token builtin class-name">:</span> <span class="token string">"https://api.deepseek.com/chat/completions"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"api_key"</span><span class="token builtin class-name">:</span> <span class="token string">"sk-xxx"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"models"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"deepseek-chat"</span>, <span class="token string">"deepseek-reasoner"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">]</span>,</span>
<span class="line"></span>
<span class="line">  <span class="token string">"Router"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"default"</span><span class="token builtin class-name">:</span> <span class="token string">"deepseek,deepseek-chat"</span>,</span>
<span class="line"></span>
<span class="line">    <span class="token string">"background"</span><span class="token builtin class-name">:</span> <span class="token string">"deepseek,deepseek-chat"</span>,</span>
<span class="line"></span>
<span class="line">    <span class="token string">"think"</span><span class="token builtin class-name">:</span> <span class="token string">"deepseek,deepseek-reasoner"</span>,</span>
<span class="line"></span>
<span class="line">    <span class="token string">"longContext"</span><span class="token builtin class-name">:</span> <span class="token string">"openrouter,google/gemini-2.5-pro-preview"</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Start Claude Code with Router</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Use this command instead of regular Claude Code</span></span>
<span class="line"></span>
<span class="line">ccr code</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Dynamic Model Switching</strong> During your session, switch models with:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Switch to different provider and model</span></span>
<span class="line"></span>
<span class="line">/model deepseek,deepseek-chat</span>
<span class="line"></span>
<span class="line">/model openrouter,anthropic/claude-3.5-sonnet</span>
<span class="line"></span>
<span class="line">/model ollama,qwen2.5-coder:latest</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Context-Based Routing</strong> The router automatically selects models based on task context:</p>
<ul>
<li><strong>Default</strong>: General development tasks</li>
<li><strong>Background</strong>: Simple, cost-effective operations</li>
<li><strong>Think</strong>: Complex reasoning and analysis</li>
<li><strong>Long Context</strong>: Tasks requiring extensive context windows</li>
</ul>
<p>For detailed configuration options and routing rules, read the <a href="https://github.com/musistudio/claude-code-router" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<h5 id="no-anthropic-account-needed" tabindex="-1"><a class="header-anchor" href="#no-anthropic-account-needed"><span>No Anthropic Account Needed</span></a></h5>
<p>Access Claude Code's interface using alternative AI providers without requiring an Anthropic subscription.</p>
<img src="/img/discovery/004.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Claude Code Router is an independent community project. For technical support and updates, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


