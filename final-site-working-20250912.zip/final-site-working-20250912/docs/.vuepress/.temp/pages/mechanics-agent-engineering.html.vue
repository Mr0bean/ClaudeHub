<template><div><h1 id="agent-engineering-claudelog" tabindex="-1"><a class="header-anchor" href="#agent-engineering-claudelog"><span>Agent Engineering | ClaudeLog</span></a></h1>
<p>We've evolved through three distinct eras of AI interaction: from Prompt Engineering (crafting perfect individual prompts) to Context Engineering (optimizing the context, what goes into it and what remains in it through <code v-pre>CLAUDE.md</code> files) and now to Agent Engineering (designing specialized, reusable, efficient AI agents). At each stage, our ability to share deliverables and grow as a community has expanded: from sharing individual prompts, to sharing comprehensive context configurations and tactics, to now sharing complete portable agent definitions that work across any project.</p>
<p><code v-pre>Custom agents</code> represent this latest paradigm shift in Claude Code workflows from manual orchestration to automatic delegation, from project-specific solutions to portable specialist tools. This guide covers the essential foundations you need to understand before diving into advanced tactics.</p>
<hr>
<hr>
<h2 id="understanding-the-agent-ecosystem​" tabindex="-1"><a class="header-anchor" href="#understanding-the-agent-ecosystem​"><span>Understanding the Agent Ecosystem<a href="#understanding-the-agent-ecosystem" title="Direct link to Understanding the Agent Ecosystem">​</a></span></a></h2>
<p>Comparison: Custom Agents vs. Sub-agents vs. Task Tools</p>
<p>Aspect</p>
<p>Custom Agents</p>
<p>Split Role Sub-agents</p>
<p>Task/Agent Tools</p>
<p><strong>Token Efficiency</strong></p>
<p><strong>Activation</strong></p>
<p>Automatic delegation</p>
<p>Manual delegation</p>
<p>Manual delegation</p>
<p><strong>Shared System Prompt</strong></p>
<p>No</p>
<p>Yes</p>
<p>Yes</p>
<p><strong>Portability</strong></p>
<p>Highly portable (single .md file)</p>
<p>Impractical</p>
<p>Impractical</p>
<p><strong>Configuration</strong></p>
<p>YAML frontmatter + system prompt</p>
<p>Task description only</p>
<p>Task description only</p>
<p><strong>System Prompt</strong></p>
<p>Custom system prompt access</p>
<p>Inherits system prompt</p>
<p>Inherits system prompt</p>
<p><strong>Custom Tool Selection</strong></p>
<p>Yes</p>
<p>No</p>
<p>No</p>
<p><strong>Claude.md Inheritance</strong></p>
<p>Yes</p>
<p>Yes</p>
<p>Yes</p>
<p><strong>Use Case</strong></p>
<p>Specialized repeatable tasks</p>
<p>Multi-perspective analysis</p>
<p>Parallel task execution</p>
<p><code v-pre>Custom agents</code> deliver <strong>automatic activation</strong>, <strong>isolated contexts</strong>, and <strong>surgical tool selection</strong>, eliminating the token bloat and manual orchestration of previous approaches.</p>
<hr>
<hr>
<h2 id="custom-agent-design​" tabindex="-1"><a class="header-anchor" href="#custom-agent-design​"><span>Custom Agent Design<a href="#custom-agent-design" title="Direct link to Custom Agent Design">​</a></span></a></h2>
<p>I believe one of the most important aspects when designing <code v-pre>custom agents</code> is to carefully engineer how many tokens your <code v-pre>custom agent</code> needs to initialize. Optimizing this serves multiple purposes: to improve initialization speed, reduce cost, maintain <RouteLink to="/mechanics/context-window-depletion/">peak performance</RouteLink>, and enable efficient chaining.</p>
<p>Each <code v-pre>custom agent</code> invocation carries a <strong>variable initialization cost</strong> based on tool count and configuration complexity. Design decisions should account for this:</p>
<p><strong>Performance Analysis by Tool Count (Anecdotal experiment):</strong></p>
<p>Tool Count</p>
<p>Token Usage</p>
<p>Relative Initialization Time</p>
<p>Claude.md Empty</p>
<p>0</p>
<p>640</p>
<p>2.6s</p>
<p>true</p>
<p>1</p>
<p>2.6k</p>
<p>3.9s</p>
<p>false</p>
<p>2</p>
<p>2.9k</p>
<p>4.3s</p>
<p>false</p>
<p>3</p>
<p>3.2k</p>
<p>6.0s</p>
<p>false</p>
<p>4</p>
<p>3.4k</p>
<p>6.1s</p>
<p>false</p>
<p>5</p>
<p>3.9k</p>
<p>5.1s</p>
<p>false</p>
<p>6</p>
<p>4.1k</p>
<p>7.0s</p>
<p>false</p>
<p>7</p>
<p>5.0k</p>
<p>6.9s</p>
<p>false</p>
<p>8</p>
<p>7.1k</p>
<p>5.6s</p>
<p>false</p>
<p>9</p>
<p>7.5k</p>
<p>5.1s</p>
<p>false</p>
<p>10</p>
<p>7.9k</p>
<p>6.2s</p>
<p>false</p>
<p>15+</p>
<p>13.9k - 25k</p>
<p>6.4s</p>
<p>false</p>
<p><em>Note: The 0 tool experiment was conducted with a completely empty <code v-pre>Claude.md</code> and thus reflects the best case scenario. Experiments for 1-15+ tools were conducted with a non-empty <code v-pre>Claude.md</code>. Token cost and initialization time were affected by the specific tools which were added.</em></p>
<p><strong>Agent Weight Classifications:</strong></p>
<ul>
<li><strong>Lightweight agents</strong>: Under 3k tokens - Low initialization cost</li>
<li><strong>Medium-weight agents</strong>: 10-15k tokens - Moderate initialization cost</li>
<li><strong>Heavy agents</strong>: 25k+ tokens - High initialization cost</li>
</ul>
<p><strong>Subscription and Model Optimization:</strong> A lightweight, performant <code v-pre>custom agent</code> will be used and experimented with more than a heavyweight <code v-pre>custom agent</code> due to subscription constraints. They are by far the most composable and effortless to use. We should strive to make our <code v-pre>custom agents</code> as performant and composable as possible.</p>
<p><strong>Model Selection Strategy:</strong> With the introduction of the <code v-pre>model</code> parameter in v1.0.64, you can now specify which model each agent should use (sonnet, opus, haiku). This creates unprecedented experimentation opportunities:</p>
<p><strong>Conventional Pairings (Starting Points):</strong></p>
<ul>
<li><strong>Haiku + Lightweight Agent</strong>: Frequent, simple tasks - minimal cost and maximum composability</li>
<li><strong>Sonnet + Medium Agent</strong>: Balanced approach for moderate complexity tasks</li>
<li><strong>Opus + Heavy Agent</strong>: Complex analysis requiring maximum reasoning capability</li>
</ul>
<p><strong>Cross-Experimentation Opportunities (Unexplored Territory):</strong></p>
<ul>
<li><strong>Opus + Lightweight Agent</strong>: Might unlock surprising depth in simple tasks</li>
<li><strong>Haiku + Heavy Agent</strong>: Could reveal new paths through complex workflows (Slot Machine)</li>
<li><strong>Model Rotation</strong>: Same agent with different models for A/B testing performance</li>
</ul>
<p>The key insight is that this is <strong>uncharted territory</strong> - benchmark extensively and share discoveries. Conventional wisdom may not apply to these new combinations.</p>
<p><strong>Agent Chainability Impact:</strong> The complexity of a <code v-pre>custom agent</code> significantly affects its chainability due to startup time and token usage. Heavy <code v-pre>custom agents</code> (25k+ tokens) create bottlenecks in multi-agent workflows, while lightweight <code v-pre>custom agents</code> (under 3k tokens) enable fluid orchestration. As future <strong>Agent Engineers</strong>, we must optimize both individual <code v-pre>custom agent</code> metrics and their composability:</p>
<ul>
<li><strong>Individual Optimization</strong>: Minimize tool count while preserving capability</li>
<li><strong>Composition Strategy</strong>: Balance specialized high-cost <code v-pre>custom agents</code> with efficient ones (Similar to the <a href="https://en.wikipedia.org/wiki/ARM_big.LITTLE" target="_blank" rel="noopener noreferrer">big.LITTLE</a> concept from CPU design)</li>
<li><strong>Workflow Design</strong>: Consider cumulative token costs when chaining multiple <code v-pre>custom agents</code></li>
<li><strong>Performance Monitoring</strong>: Track <code v-pre>custom agent</code> efficiency metrics across different use cases</li>
</ul>
<hr>
<hr>
<h2 id="when-to-use-custom-agents​" tabindex="-1"><a class="header-anchor" href="#when-to-use-custom-agents​"><span>When to Use Custom Agents<a href="#when-to-use-custom-agents" title="Direct link to When to Use Custom Agents">​</a></span></a></h2>
<p><code v-pre>Custom agents</code> excel in the same scenarios as <RouteLink to="/mechanics/split-role-sub-agents/">split role sub-agents</RouteLink>, but with enhanced portability and automatic activation:</p>
<h3 id="specialized-domain-tasks​" tabindex="-1"><a class="header-anchor" href="#specialized-domain-tasks​"><span>Specialized Domain Tasks<a href="#specialized-domain-tasks" title="Direct link to Specialized Domain Tasks">​</a></span></a></h3>
<ul>
<li><strong>Code Review</strong> - Security, performance, maintainability analysis</li>
<li><strong>Research Tasks</strong> - API documentation, library comparison, best practices</li>
<li><strong>Quality Assurance</strong> - Testing strategies, edge case identification</li>
<li><strong>Documentation</strong> - Technical writing, SEO optimization, accessibility</li>
<li><strong>Design Analysis</strong> - UX review, layout assessment, design consistency</li>
<li><strong>Content Quality</strong> - Legibility expert, grammar expert, brand voice expert</li>
</ul>
<h3 id="portable-workflows​" tabindex="-1"><a class="header-anchor" href="#portable-workflows​"><span>Portable Workflows<a href="#portable-workflows" title="Direct link to Portable Workflows">​</a></span></a></h3>
<p>Unlike <code v-pre>sub-agents</code> tied to specific projects, <code v-pre>custom agents</code> can be refined once and utilized across multiple projects, making them ideal for:</p>
<ul>
<li>Cross-project standards enforcement</li>
<li>Team workflow standardization</li>
<li>Personal expertise amplification</li>
<li>Community knowledge sharing</li>
</ul>
<hr>
<hr>
<h2 id="essential-features​" tabindex="-1"><a class="header-anchor" href="#essential-features​"><span>Essential Features<a href="#essential-features" title="Direct link to Essential Features">​</a></span></a></h2>
<h3 id="no-claude-md-inheritance​" tabindex="-1"><a class="header-anchor" href="#no-claude-md-inheritance​"><span>No CLAUDE.md Inheritance<a href="#no-claudemd-inheritance" title="Direct link to No CLAUDE.md Inheritance">​</a></span></a></h3>
<p><strong>Major Advantage</strong>: Unlike traditional sub-agents, custom agents are designed to not automatically inherit the project's <code v-pre>CLAUDE.md</code> configuration. This prevents context pollution and ensures consistent behavior across projects. You can verify this with a <RouteLink to="/mechanics/sanity-check/">sanity check</RouteLink>.</p>
<h3 id="coloring-your-custom-agent​" tabindex="-1"><a class="header-anchor" href="#coloring-your-custom-agent​"><span>Coloring Your Custom Agent<a href="#coloring-your-custom-agent" title="Direct link to Coloring Your Custom Agent">​</a></span></a></h3>
<p>Custom agents can be visually distinguished through terminal color formatting in their indicator, making it easier to track which agent is responding during complex workflows. This helps maintain clarity when multiple agents are active or when reviewing conversation history.</p>
<h3 id="agent-nicknaming-for-efficiency​" tabindex="-1"><a class="header-anchor" href="#agent-nicknaming-for-efficiency​"><span>Agent Nicknaming for Efficiency<a href="#agent-nicknaming-for-efficiency" title="Direct link to Agent Nicknaming for Efficiency">​</a></span></a></h3>
<p>Configure short nicknames for frequently used agents:</p>
<ul>
<li><strong>UX agent (<code v-pre>A1</code>)</strong> - Quick UX analysis</li>
<li><strong>Security agent (<code v-pre>S1</code>)</strong> - Rapid security review</li>
<li><strong>Performance agent (<code v-pre>P1</code>)</strong> - Performance optimization</li>
</ul>
<p>Example configuration with nickname:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">---</span>
<span class="line"></span>
<span class="line">name: UX Agent <span class="token punctuation">(</span>A1<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">description: UX specialist <span class="token keyword">for</span> user experience analysis. Use this agent when evaluating interfaces and user workflows.</span>
<span class="line"></span>
<span class="line">tools: Read, Grep, Glob</span>
<span class="line"></span>
<span class="line">---</span>
<span class="line"></span>
<span class="line">You are a UX specialist focused on user experience analysis and interface evaluation.</span>
<span class="line"></span>
<span class="line">When invoked:</span>
<span class="line"></span>
<span class="line"><span class="token number">1</span>. Analyze user interface elements and workflows</span>
<span class="line"></span>
<span class="line"><span class="token number">2</span>. Identify usability issues and improvement opportunities</span>
<span class="line"></span>
<span class="line"><span class="token number">3</span>. Provide actionable UX recommendations</span>
<span class="line"></span>
<span class="line"><span class="token number">4</span>. Consider accessibility and user journey optimization</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Calling the agent with nickname:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">ask agent a1 to review the navigation menu UX</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>or:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">ask a1 to review the navigation menu UX</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="advanced-nickname-workflows​" tabindex="-1"><a class="header-anchor" href="#advanced-nickname-workflows​"><span>Advanced Nickname Workflows<a href="#advanced-nickname-workflows" title="Direct link to Advanced Nickname Workflows">​</a></span></a></h3>
<p>The ability to provide nicknames to <code v-pre>custom agents</code> helps to improve manual invocation and opens up possibilities like calling <code v-pre>custom agents</code> via nicknames <code v-pre>A1, P2, C1</code>.</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">ask A1, P2, C1 to review the changes</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="configuring-automatic-delegation​" tabindex="-1"><a class="header-anchor" href="#configuring-automatic-delegation​"><span>Configuring Automatic Delegation<a href="#configuring-automatic-delegation" title="Direct link to Configuring Automatic Delegation">​</a></span></a></h3>
<p><code v-pre>Custom agents</code> are automatically utilized by the <code v-pre>delegating agent</code> based on the task description within your prompt, the description field within your <code v-pre>custom agent</code> configuration, the current context and available tools.</p>
<p>When crafting your <code v-pre>custom agents</code> you will need to evaluate Claude's reliability at invoking your <code v-pre>custom agent</code>. If you need to improve the reliability, explore updating your agent's name, description or system prompt. Configuring your <code v-pre>custom agent</code> to be promptly utilized by Claude is a form of <code v-pre>Tool SEO</code>.</p>
<p>Anthropic has mentioned that to encourage proactive <code v-pre>custom agent</code> use we should include terms like <code v-pre>use PROACTIVELY</code> or <code v-pre>MUST BE USED</code> in the <code v-pre>description</code> fields of our <code v-pre>custom agents</code>. This functions similarly to how you would use such terms to get good adherence out of Claude by correctly formatting your <code v-pre>Claude.md</code>.</p>
<hr>
<hr>
<h2 id="design-considerations​" tabindex="-1"><a class="header-anchor" href="#design-considerations​"><span>Design Considerations<a href="#design-considerations" title="Direct link to Design Considerations">​</a></span></a></h2>
<h3 id="getting-started-strategy​" tabindex="-1"><a class="header-anchor" href="#getting-started-strategy​"><span>Getting Started Strategy<a href="#getting-started-strategy" title="Direct link to Getting Started Strategy">​</a></span></a></h3>
<p><strong>Token-First Design:</strong></p>
<ul>
<li>Create focused, single-purpose agents initially</li>
<li>Start with lightweight agents (minimal or no tools) for maximum composability</li>
<li>Carefully engineer how many tokens your custom agent needs to initialize</li>
<li>Prioritize efficiency over capability for frequent-use agents</li>
</ul>
<p><strong>Configuration Best Practices:</strong></p>
<ul>
<li>Use clear, specific descriptions for reliable auto-activation</li>
<li>Grant only necessary tools initially, expand as needed</li>
<li><strong>Choose appropriate models</strong>: Start with Haiku for simple agents, scale to sonnet/opus based on complexity needs</li>
<li>Test agent reliability before expanding</li>
<li>Include examples in system prompts for better pattern recognition</li>
<li>Test agents in isolation before deploying in workflows</li>
<li>Design for chainability and multi-agent piping</li>
<li><strong>Match model to agent weight</strong>: Pair lightweight agents with Haiku, heavy agents with Sonnet for optimal cost/performance</li>
<li>Frequently test agents and share them with others to help validate effectiveness</li>
</ul>
<h3 id="model-selection-strategy​" tabindex="-1"><a class="header-anchor" href="#model-selection-strategy​"><span>Model Selection Strategy<a href="#model-selection-strategy" title="Direct link to Model Selection Strategy">​</a></span></a></h3>
<p>The <code v-pre>model</code> parameter opens unexplored possibilities in agent engineering. <strong>This is frontier territory</strong> - approach with experimental curiosity rather than rigid rules.</p>
<p><strong>Baseline Understanding (Traditional Expectations):</strong></p>
<ul>
<li><strong>Haiku agents</strong>: Commit message generation, simple formatting, basic validation, repetitive tasks</li>
<li><strong>Sonnet agents</strong>: Moderate analysis, balanced reasoning tasks, general-purpose workflows</li>
<li><strong>Opus agents</strong>: Complex analysis, code review, research, deep reasoning tasks</li>
</ul>
<p><strong>Experimental Discovery Framework:</strong></p>
<ul>
<li><strong>Challenge assumptions</strong>: Test whether &quot;simple&quot; tasks benefit from opus intelligence</li>
<li><strong>Reverse expectations</strong>: Try Haiku on complex agents to find efficiency breakthroughs</li>
<li><strong>Benchmark systematically</strong>: Measure actual performance vs. theoretical predictions</li>
</ul>
<p><strong>Discovery-Oriented Lifecycle:</strong></p>
<ol>
<li><strong>Start with conventional pairing</strong>: Establish baseline performance</li>
<li><strong>Cross-experiment</strong>: Test unconventional model/agent combinations</li>
<li><strong>Measure everything</strong>: Token usage, token cost, speed, quality, user satisfaction</li>
<li><strong>Share breakthrough discoveries</strong>: Contribute findings to expand collective knowledge</li>
<li><strong>Iterate based on real data</strong>: Let empirical results guide optimization, not assumptions</li>
</ol>
<p><strong>Community Collaboration:</strong> The agent engineering community should actively share benchmarking results and surprising discoveries. What works for one use case might revolutionize another.</p>
<hr>
<p>Getting Started</p>
<p>Start with one simple, focused custom agent that solves a specific problem you encounter regularly. Test its effectiveness and refine its description based on how reliably Claude invokes it automatically.</p>
<p>Experimental Approach</p>
<p>While efficiency matters, don't let optimization assumptions limit discovery. A heavy agent with Haiku might surprise you with efficient performance, or a &quot;simple&quot; agent with opus might unlock unexpected capabilities.</p>
<h5 id="foundation-first" tabindex="-1"><a class="header-anchor" href="#foundation-first"><span>Foundation First</span></a></h5>
<p>Master the fundamentals of custom agents before diving into complex chaining. A solid understanding of these foundations will enable more effective chaining and increased usage frequency.</p>
<img src="/img/discovery/028_fire.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink>|<RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#understanding-the-agent-ecosystem">Understanding the Agent Ecosystem</a></li>
<li><a href="#custom-agent-design">Custom Agent Design</a></li>
<li><a href="#when-to-use-custom-agents">When to Use Custom Agents</a>
<ul>
<li><a href="#specialized-domain-tasks">Specialized Domain Tasks</a></li>
<li><a href="#portable-workflows">Portable Workflows</a></li>
</ul>
</li>
<li><a href="#essential-features">Essential Features</a>
<ul>
<li><a href="#no-claudemd-inheritance">No CLAUDE.md Inheritance</a></li>
<li><a href="#coloring-your-custom-agent">Coloring Your Custom Agent</a></li>
<li><a href="#agent-nicknaming-for-efficiency">Agent Nicknaming for Efficiency</a></li>
<li><a href="#advanced-nickname-workflows">Advanced Nickname Workflows</a></li>
<li><a href="#configuring-automatic-delegation">Configuring Automatic Delegation</a></li>
</ul>
</li>
<li><a href="#design-considerations">Design Considerations</a>
<ul>
<li><a href="#getting-started-strategy">Getting Started Strategy</a></li>
<li><a href="#model-selection-strategy">Model Selection Strategy</a></li>
</ul>
</li>
</ul>
</div></template>


