import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/watch-control.html.vue"
const data = JSON.parse("{\"path\":\"/watch-control.html\",\"title\":\"Watch Control Example | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Watch Control Example | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"watch-control.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
