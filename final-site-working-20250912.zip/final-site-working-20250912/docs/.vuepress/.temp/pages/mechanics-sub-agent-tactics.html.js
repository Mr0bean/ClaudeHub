import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-sub-agent-tactics.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-sub-agent-tactics.html\",\"title\":\"Sub-agent Tactics | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Sub-agent Tactics | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-sub-agent-tactics.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
