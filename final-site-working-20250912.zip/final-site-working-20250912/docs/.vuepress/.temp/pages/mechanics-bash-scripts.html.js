import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-bash-scripts.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-bash-scripts.html\",\"title\":\"Bash Scripts | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Bash Scripts | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-bash-scripts.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
