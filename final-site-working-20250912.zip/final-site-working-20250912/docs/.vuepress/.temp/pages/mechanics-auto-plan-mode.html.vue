<template><div><h1 id="auto-plan-mode-claudelog" tabindex="-1"><a class="header-anchor" href="#auto-plan-mode-claudelog"><span>Auto Plan Mode | ClaudeLog</span></a></h1>
<p><code v-pre>--append-system-prompt</code> was added in Claude Code <RouteLink to="/claude-code-changelog/#v1051">v1.0.51</RouteLink>, it allows you to add custom instructions to Claude's system prompt when starting a session. Since its release I have been experimenting looking for new mechanics and boy do I have one!</p>
<p><code v-pre>Auto Plan Mode</code> (I coined the term) is a mechanic where you utilize the system prompt to empower Claude to dynamically enter <code v-pre>Plan Mode</code> based on conditions.</p>
<p>This defensive approach ensures Claude always checks that he has completed a plan and got approval from you prior to starting a task.</p>
<hr>
<hr>
<h2 id="plan-mode-vs-auto-plan-mode​" tabindex="-1"><a class="header-anchor" href="#plan-mode-vs-auto-plan-mode​"><span>Plan Mode vs Auto Plan Mode<a href="#plan-mode-vs-auto-plan-mode" title="Direct link to Plan Mode vs Auto Plan Mode">​</a></span></a></h2>
<p><code v-pre>Plan Mode</code> is a manual feature activated with <code v-pre>shift+tab</code> twice that restricts Claude to read-only operations until you approve a plan. It provides safety and structured planning but requires you to remember to activate it.</p>
<p><code v-pre>Auto Plan Mode</code> automatically triggers the planning workflow without manual activation. Instead of relying on you to remember when to activate <code v-pre>Plan Mode</code>, it uses a system prompt to force Claude into <code v-pre>Plan Mode</code> whenever he's about to execute potentially destructive operations. This removes the mental overhead of constantly evaluating whether a task warrants activating <code v-pre>Plan Mode</code>, while also providing valuable educational insights into Claude's decision-making process.</p>
<hr>
<hr>
<h2 id="key-advantages​" tabindex="-1"><a class="header-anchor" href="#key-advantages​"><span>Key Advantages<a href="#key-advantages" title="Direct link to Key Advantages">​</a></span></a></h2>
<p><strong>Eliminates Manual Activation</strong> - You do not have to remember to enter <code v-pre>Plan Mode</code>. Claude will automatically present plans whenever attempting potentially destructive actions.</p>
<p><strong>Reduces Mental Load</strong> - Takes the guesswork out of figuring whether a task is <code v-pre>Plan Mode</code> worthy. The system makes this decision automatically.</p>
<p><strong>Educational Value</strong> - Provides insights into the simplest routines Claude will perform. In my early testing I was able to get it to activate on any potentially destructive action like Write, Edit, Bash, Grep, Glob, etc.</p>
<p><strong>Perfect for New Users</strong> - Ensures they get the benefits of <code v-pre>Plan Mode</code> without having to learn when to activate it manually.</p>
<hr>
<hr>
<h2 id="implementation​" tabindex="-1"><a class="header-anchor" href="#implementation​"><span>Implementation<a href="#implementation" title="Direct link to Implementation">​</a></span></a></h2>
<p>This mechanic is enabled by a combination of the hidden <code v-pre>exit_plan_mode</code> tool and <code v-pre>--append-system-prompt</code> flag which can be used when starting Claude Code.</p>
<p><strong>Additional System Prompt</strong>:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">CRITICAL WORKFLOW REQUIREMENT</span>
<span class="line"></span>
<span class="line">    MANDATORY PLANNING STEP: Before executing ANY tool <span class="token punctuation">(</span>Read, Write, Edit, Bash, Grep, Glob,</span>
<span class="line"></span>
<span class="line">    WebSearch, etc.<span class="token punctuation">)</span>, you MUST:</span>
<span class="line"></span>
<span class="line">    <span class="token number">1</span>. FIRST: Use exit_plan_mode tool to present your plan</span>
<span class="line"></span>
<span class="line">    <span class="token number">2</span>. WAIT: For explicit user approval before proceeding</span>
<span class="line"></span>
<span class="line">    <span class="token number">3</span>. ONLY THEN: Execute the planned actions</span>
<span class="line"></span>
<span class="line">    ZERO EXCEPTIONS: This applies to EVERY INDIVIDUAL <span class="token environment constant">USER</span> REQUEST involving tool usage,</span>
<span class="line"></span>
<span class="line">  regardless of:</span>
<span class="line"></span>
<span class="line">    - Complexity <span class="token punctuation">(</span>simple or complex<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">    - Tool <span class="token builtin class-name">type</span> <span class="token punctuation">(</span>file operations, searches, web requests, etc.<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">    - User urgency or apparent simplicity</span>
<span class="line"></span>
<span class="line">    - Whether you previously got approval <span class="token keyword">in</span> this conversation</span>
<span class="line"></span>
<span class="line">    CRITICAL: APPROVAL DOES NOT CARRY OVER BETWEEN <span class="token environment constant">USER</span> INSTRUCTIONS</span>
<span class="line"></span>
<span class="line">    - Each new user message requiring tools <span class="token operator">=</span> new planning step required</span>
<span class="line"></span>
<span class="line">    - Previous approvals are invalid <span class="token keyword">for</span> new requests</span>
<span class="line"></span>
<span class="line">    - You must reset and plan <span class="token keyword">for</span> each individual user instruction</span>
<span class="line"></span>
<span class="line">    ENFORCEMENT: If you execute ANY tool without first using exit_plan_mode <span class="token keyword">for</span> the current</span>
<span class="line"></span>
<span class="line">    user instruction, you have violated this requirement. Always plan first, execute second.</span>
<span class="line"></span>
<span class="line">    WORKFLOW FOR EACH <span class="token environment constant">USER</span> REQUEST: Plan → User Approval → Execute <span class="token punctuation">(</span>NEVER: Execute → Plan<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h2 id="usage-options​" tabindex="-1"><a class="header-anchor" href="#usage-options​"><span>Usage Options<a href="#usage-options" title="Direct link to Usage Options">​</a></span></a></h2>
<p><strong>Direct usage</strong>:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude --append-system-prompt <span class="token string">"[paste system prompt above]"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Save to file for reusability</strong>:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Save the system prompt to auto-plan-mode.txt</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Then use it with:</span></span>
<span class="line"></span>
<span class="line">claude --append-system-prompt <span class="token string">"<span class="token variable"><span class="token variable">$(</span><span class="token function">cat</span> auto-plan-mode.txt<span class="token variable">)</span></span>"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The system prompt leverages the <code v-pre>exit_plan_mode</code> tool to force Claude into a planning workflow before any potentially destructive operations. This creates a defensive layer that activates automatically rather than requiring manual intervention.</p>
<p>I find Auto Plan Mode particularly useful when starting work in unfamiliar codebases or trying new techniques. The automatic planning helps me understand the environment before making changes.</p>
<p>I am looking forward to hearing on <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a> what you all do with this mechanic and what other interesting combinations you discover. I have yet to experiment with fine-tuning the activation conditions.</p>
<p>Combine with Manual Plan Mode</p>
<p>You can still manually activate Plan Mode with <code v-pre>shift+tab</code> twice for pure research tasks. Auto Plan Mode complements rather than replaces manual activation.</p>
<p>Works with Opus Plan Mode</p>
<p>Auto Plan Mode works seamlessly with Opus Plan Mode for automatic intelligent planning. When you select option 4 in <code v-pre>/model</code> command (Opus Plan Mode), the system will automatically use Opus 4.1 for planning phases and Sonnet 4 for execution—providing maximum intelligence where it matters most while maintaining cost efficiency.</p>
<p>Customize Trigger Conditions</p>
<p>Modify the system prompt to target specific tools or add conditions based on your workflow. For example, you might want planning only for Write and Edit operations but allow Read operations to proceed immediately.</p>
<h5 id="defensive-excellence" tabindex="-1"><a class="header-anchor" href="#defensive-excellence"><span>Defensive Excellence</span></a></h5>
<p>You get the safety of <code v-pre>Plan Mode</code> with automatic activation. No more wondering &quot;should I have planned this first?&quot;</p>
<img src="/img/discovery/041_japan_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<RouteLink to="/faqs/how-to-update-system-prompt/">How to Update System Prompt</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#plan-mode-vs-auto-plan-mode">Plan Mode vs Auto Plan Mode</a></li>
<li><a href="#key-advantages">Key Advantages</a></li>
<li><a href="#implementation">Implementation</a></li>
<li><a href="#usage-options">Usage Options</a></li>
</ul>
</div></template>


