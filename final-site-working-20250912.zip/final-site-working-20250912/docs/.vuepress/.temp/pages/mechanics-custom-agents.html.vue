<template><div><h1 id="custom-agents-claudelog" tabindex="-1"><a class="header-anchor" href="#custom-agents-claudelog"><span>Custom Agents | ClaudeLog</span></a></h1>
<p><code v-pre>Sub-agents</code> were always one of Claude Code's greatest strengths. However, the expectation for users to know when to invoke them manually and remember what expertise to give them always held back the functionality for normal users. No longer...</p>
<p><code v-pre>Custom agents</code> are specialized agents that can be utilized to solve specific tasks. They are <strong>automatically invoked by Claude</strong> in a similar manner to how <code v-pre>Tools</code> are invoked automatically!</p>
<p>This approach brings incredible potential! Given how reliable and well-developed the MCP tools ecosystem has become, I envision a thriving future where we collaboratively build, share, and exchange agents. If you have cool agents or want to iterate on existing ones, be sure to head over to <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a>.</p>
<p>Unlike traditional <code v-pre>sub-agents</code>, they have their own <code v-pre>custom system prompt</code>, tools, and context window separate from their <code v-pre>delegating agent</code>. <code v-pre>Custom agents</code> are engineered to be specialized, isolated and efficient. Their configuration is integrated natively within Claude Code, effectively removing the need for third-party persona orchestration tools.</p>
<hr>
<hr>
<h3 id="the-game-will-never-be-the-same​" tabindex="-1"><a class="header-anchor" href="#the-game-will-never-be-the-same​"><span>The Game Will Never Be The Same<a href="#the-game-will-never-be-the-same" title="Direct link to The Game Will Never Be The Same">​</a></span></a></h3>
<p><strong>Automatic Delegation</strong> - This mechanic is powerful and scalable because of the automatic delegation of tasks to specialized isolated agents. The integration process is seamless and builds on Claude's reliability when using tools. Claude delegates tasks based on the task description in your request, the description field in agent configurations, the current context, and available tools.</p>
<p><strong>No Manual Invocation Required</strong> - You no longer need to remember which role <code v-pre>sub-agent</code> to use or when. Claude intelligently routes tasks to the appropriate specialist, just like how it automatically selects the right tools. However, you will need to benchmark how reliable the task routing is within your setup, especially if you flood Claude with too many <code v-pre>custom agent</code> options.</p>
<h3 id="core-benefits​" tabindex="-1"><a class="header-anchor" href="#core-benefits​"><span>Core Benefits<a href="#core-benefits" title="Direct link to Core Benefits">​</a></span></a></h3>
<ul>
<li>
<p><strong>Separate Context Windows</strong> - Each <code v-pre>custom agent</code> operates with its own context window, separate from the <code v-pre>delegating agent</code>. This allows larger tasks to be completed without concerning the <code v-pre>delegating agent</code> with every detail, preventing different tasks from <RouteLink to="/mechanics/poison-context-awareness/">poisoning the context</RouteLink> while maintaining peak performance.</p>
</li>
<li>
<p><strong>Specialized System Prompts</strong> - Individual <code v-pre>custom agent</code> system prompts can be scoped precisely, avoiding the inheritance of redundant context, thus preserving the limited context window.</p>
</li>
<li>
<p><strong>Role-Specific Tools</strong> - Agents can be configured with specific tools, helping prevent security issues by only allowing trusted agents to perform certain tasks. Specific agents can be tested and evaluated for reliability at their role. This first-party level of integration takes the concept of <RouteLink to="/mechanics/split-role-sub-agents/">Split role sub-agents</RouteLink> to the next level!</p>
</li>
<li>
<p><strong>Community Sharing</strong> - Once refined, <code v-pre>custom agents</code> can be shared across projects, among teams, or even in <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a>, creating a collaborative ecosystem of ever-evolving specialized agents.</p>
</li>
</ul>
<hr>
<hr>
<h3 id="quick-start-guide​" tabindex="-1"><a class="header-anchor" href="#quick-start-guide​"><span>Quick Start Guide<a href="#quick-start-guide" title="Direct link to Quick Start Guide">​</a></span></a></h3>
<p><code v-pre>Custom agents</code> were introduced in Claude Code <RouteLink to="/claude-code-changelog/#v1060">v1.0.60</RouteLink></p>
<p><strong>1. Open the Custom Agents Interface</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">/agents</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>2. Select 'Create New Agent'</strong> Choose whether to create a project-level or user-level <code v-pre>custom agent</code>.</p>
<p><strong>3. Define Your Agent</strong></p>
<ul>
<li><strong>Recommended</strong>: Generate with Claude first, then customize to make it yours</li>
<li>Describe your agent in detail and when it should be used</li>
<li>Select specific tools or leave blank to inherit all tools</li>
<li>Edit the system prompt to define role, capabilities, and approach</li>
<li>Pick the color of your agent</li>
<li>Review the configuration of your <code v-pre>custom agent</code></li>
</ul>
<p><strong>4. Save and Use</strong> Your <code v-pre>custom agent</code> is now available! Claude will use it automatically when appropriate, or you can invoke it explicitly: <code v-pre>Use the algorithmic complexity specialist agent to analyze this function.</code></p>
<p><strong>File Format</strong>:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">---</span>
<span class="line"></span>
<span class="line">name: your-agent-name</span>
<span class="line"></span>
<span class="line">description: Description of when this agent should be invoked</span>
<span class="line"></span>
<span class="line">tools: tool1, tool2, tool3  <span class="token comment"># Optional - inherits all tools if omitted</span></span>
<span class="line"></span>
<span class="line">model: sonnet  <span class="token comment"># Optional - sonnet, opus, or haiku. Inherits if omitted</span></span>
<span class="line"></span>
<span class="line">---</span>
<span class="line"></span>
<span class="line">Your agent's system prompt goes here. Define the role, capabilities,</span>
<span class="line"></span>
<span class="line">and approach to solving problems. Include specific instructions,</span>
<span class="line"></span>
<span class="line">best practices, and any constraints the agent should follow.</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="basic-usage​" tabindex="-1"><a class="header-anchor" href="#basic-usage​"><span>Basic Usage<a href="#basic-usage" title="Direct link to Basic Usage">​</a></span></a></h3>
<p><strong>Automatic Invocation</strong> - Once created, your <code v-pre>custom agents</code> work automatically. Claude will select and use the appropriate agent based on your request and the agent's description.</p>
<p><strong>Manual Invocation</strong> - You can also explicitly request a specific agent:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Use the algorithmic complexity specialist agent to analyze this function.</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Task Delegation</strong> - Claude intelligently routes tasks to specialized isolated agents, similar to how it automatically selects tools for different operations.</p>
<hr>
<hr>
<h3 id="configuration​" tabindex="-1"><a class="header-anchor" href="#configuration​"><span>Configuration<a href="#configuration" title="Direct link to Configuration">​</a></span></a></h3>
<p><code v-pre>Custom agents</code> are stored as Markdown files with YAML frontmatter in two possible locations:</p>
<p>Type</p>
<p>Location</p>
<p>Scope</p>
<p>Priority</p>
<p>Project agents</p>
<p><code v-pre>.claude/agents/</code></p>
<p>Available in current project</p>
<p>Highest</p>
<p>User agents</p>
<p><code v-pre>~/.claude/agents/</code></p>
<p>Available across all projects</p>
<p>Lower</p>
<p>When agent names conflict, project-level agents take precedence over user-level agents.</p>
<p><strong>Configuration Fields</strong></p>
<p>Field</p>
<p>Required</p>
<p>Description</p>
<p>name</p>
<p>Yes</p>
<p>Unique identifier using lowercase letters and hyphens</p>
<p>description</p>
<p>Yes</p>
<p>Natural language description of the agent's purpose</p>
<p>tools</p>
<p>No</p>
<p>Comma-separated list of specific tools. If omitted, inherits all tools from the main thread</p>
<p>model</p>
<p>No</p>
<p>Model to use for this agent: sonnet, opus, or haiku. If omitted, inherits model</p>
<hr>
<h3 id="best-practices​" tabindex="-1"><a class="header-anchor" href="#best-practices​"><span>Best Practices<a href="#best-practices" title="Direct link to Best Practices">​</a></span></a></h3>
<ul>
<li>
<p><strong>Start with Claude Generation</strong> - Generate your initial agent with Claude, then customize it to make it your own.</p>
</li>
<li>
<p><strong>Separation of Concerns</strong> - Like with programming, better separation of concerns in your <code v-pre>custom agents</code> leads to better performance, maintainability, inspectability, and shareability.</p>
</li>
<li>
<p><strong>Provide Examples</strong> - Include positive/negative examples in your system prompts. LLMs excel at pattern recognition and repetition, so be sure to provide a sufficient amount of distinct instances.</p>
</li>
<li>
<p><strong>Progressive Tool Expansion</strong> - Begin with a carefully scoped set of tools for your <code v-pre>custom agent</code> and progressively expand the tool scope as you validate its behavior and identify additional capabilities needed for optimal performance.</p>
</li>
</ul>
<hr>
<hr>
<h3 id="community-vision​" tabindex="-1"><a class="header-anchor" href="#community-vision​"><span>Community Vision<a href="#community-vision" title="Direct link to Community Vision">​</a></span></a></h3>
<p>I'm beyond excited for the future of agentic workflows! We should all work together to refine optimal instances of various agents and share them among each other. This kind of initiative is much more viable with automatic delegation since users don't need to understand when to activate agents.</p>
<p>Sharing custom agents is as simple as copying a single Markdown file. For example, a <code v-pre>code-reviewer.md</code> agent created for one project can be instantly shared with teammates or the community:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">---</span>
<span class="line"></span>
<span class="line">name: code-reviewer</span>
<span class="line"></span>
<span class="line">description: Expert code review specialist. Proactively reviews code <span class="token keyword">for</span> quality, security, and maintainability. Use immediately after writing or modifying code.</span>
<span class="line"></span>
<span class="line">tools: Read, Grep, Glob, Bash</span>
<span class="line"></span>
<span class="line">model: opus</span>
<span class="line"></span>
<span class="line">---</span>
<span class="line"></span>
<span class="line">You are a senior code reviewer ensuring high standards of code quality and security.</span>
<span class="line"></span>
<span class="line">When invoked:</span>
<span class="line"></span>
<span class="line"><span class="token number">1</span>. Run <span class="token function">git</span> <span class="token function">diff</span> to see recent changes</span>
<span class="line"></span>
<span class="line"><span class="token number">2</span>. Focus on modified files</span>
<span class="line"></span>
<span class="line"><span class="token number">3</span>. Begin review immediately</span>
<span class="line"></span>
<span class="line">Review checklist:</span>
<span class="line"></span>
<span class="line">- Code is simple and readable</span>
<span class="line"></span>
<span class="line">- Functions and variables are well-named</span>
<span class="line"></span>
<span class="line">- No duplicated code</span>
<span class="line"></span>
<span class="line">- Proper error handling</span>
<span class="line"></span>
<span class="line">- No exposed secrets or API keys</span>
<span class="line"></span>
<span class="line">- Input validation implemented</span>
<span class="line"></span>
<span class="line">- Good <span class="token builtin class-name">test</span> coverage</span>
<span class="line"></span>
<span class="line">- Performance considerations addressed</span>
<span class="line"></span>
<span class="line">- Time complexity of algorithms analyzed</span>
<span class="line"></span>
<span class="line">- Licenses of integrated libraries checked</span>
<span class="line"></span>
<span class="line">Provide feedback organized by priority:</span>
<span class="line"></span>
<span class="line">- Critical issues <span class="token punctuation">(</span>must fix<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">- Warnings <span class="token punctuation">(</span>should fix<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">- Suggestions <span class="token punctuation">(</span>consider improving<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line">Include specific examples of how to fix issues.</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Your goal should be to build a comprehensive collection of battle-tested <code v-pre>custom agents</code> from different domains, allowing you to effectively tackle any task.</p>
<p><strong>Official Documentation</strong>: <a href="https://docs.anthropic.com/en/docs/claude-code/sub-agents" target="_blank" rel="noopener noreferrer">Sub-agents Documentation</a></p>
<p>Community Collaboration</p>
<p>The true power of custom agents emerges through community sharing and iteration. Build upon others' agents, share your specialized creations, and contribute to a growing ecosystem of battle-tested specialists. Visit <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a> to discover, share, and refine agents collaboratively.</p>
<p>Token Cost Awareness</p>
<p>Each custom agent invocation carries a variable initialization cost based on tool count and configuration complexity. Design your <RouteLink to="/mechanics/agent-engineering/">agents</RouteLink> thoughtfully to ensure they provide sufficient value to justify this overhead, focusing on specialized tasks that benefit from dedicated context and expertise.</p>
<p>Model Selection Strategy</p>
<p>This new capability opens unexplored territory! While logical pairings make sense (Haiku for simple tasks, opus for complex analysis), cross-experiment to discover surprising synergies.</p>
<h5 id="specialized-intelligence" tabindex="-1"><a class="header-anchor" href="#specialized-intelligence"><span>Specialized Intelligence</span></a></h5>
<p>Custom agents act like specialized team members - each with domain expertise, specific tools, and focused responsibilities. This creates a collaborative AI environment where the right specialist handles each task.</p>
<img src="/img/discovery/022_excite_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink> | <RouteLink to="/mechanics/agent-engineering/">Agent Engineering</RouteLink> | <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">r/ClaudeAI</a></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#the-game-will-never-be-the-same">The Game Will Never Be The Same</a></li>
<li><a href="#core-benefits">Core Benefits</a></li>
<li><a href="#quick-start-guide">Quick Start Guide</a></li>
<li><a href="#basic-usage">Basic Usage</a></li>
<li><a href="#configuration">Configuration</a></li>
<li><a href="#best-practices">Best Practices</a></li>
<li><a href="#community-vision">Community Vision</a></li>
</ul>
</div></template>


