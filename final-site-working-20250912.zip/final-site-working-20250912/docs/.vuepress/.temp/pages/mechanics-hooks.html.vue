<template><div><h1 id="hooks-claudelog" tabindex="-1"><a class="header-anchor" href="#hooks-claudelog"><span>Hooks | ClaudeLog</span></a></h1>
<p>Hooks are a new mechanic introduced to Claude Code to allow deterministic responses based on a given event such as tool executions, file changes, or deployment activities.</p>
<h3 id="real-world-implementation​" tabindex="-1"><a class="header-anchor" href="#real-world-implementation​"><span>Real-World Implementation<a href="#real-world-implementation" title="Direct link to Real-World Implementation">​</a></span></a></h3>
<p>I have been experimenting with simple use cases for how they can be used to improve the reliability of my existing workflows such as running various pre/post deploy related activities before deploying the ClaudeLog website live.</p>
<p>When you update a website online there are various SEO related activities which must be performed such as:</p>
<ul>
<li><strong>Deploying your sitemap</strong> to various web master tools</li>
<li><strong>Checking build process</strong> has not generated invalid JSON schemas (different web masters are surprisingly sensitive)</li>
<li><strong>Validating URLs</strong> are all live and well formed</li>
</ul>
<p>These were simple low hanging fruit which Claude suggested for me to explore implementing into my workflow based on my existing deployment pipeline.</p>
<hr>
<hr>
<h3 id="the-scoping-challenge​" tabindex="-1"><a class="header-anchor" href="#the-scoping-challenge​"><span>The Scoping Challenge<a href="#the-scoping-challenge" title="Direct link to The Scoping Challenge">​</a></span></a></h3>
<p>Interestingly I found the fiddliest bit was scoping the activation requirements such that they do not activate too early.</p>
<h3 id="badly-scoped-hook-example​" tabindex="-1"><a class="header-anchor" href="#badly-scoped-hook-example​"><span>Badly Scoped Hook Example<a href="#badly-scoped-hook-example" title="Direct link to Badly Scoped Hook Example">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"hooks"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"PreToolUse"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"matcher"</span><span class="token builtin class-name">:</span> <span class="token string">"Bash"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"hooks"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">            <span class="token string">"type"</span><span class="token builtin class-name">:</span> <span class="token string">"command"</span>,</span>
<span class="line"></span>
<span class="line">            <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"./scripts/expensive-validation.sh"</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><em>This fires on ANY bash command, running expensive validation even for simple <code v-pre>ls</code> or <code v-pre>pwd</code> commands</em></p>
<h3 id="better-scoped-hook-example-smart-dispatcher-pattern​" tabindex="-1"><a class="header-anchor" href="#better-scoped-hook-example-smart-dispatcher-pattern​"><span>Better Scoped Hook Example - Smart Dispatcher Pattern<a href="#better-scoped-hook-example---smart-dispatcher-pattern" title="Direct link to Better Scoped Hook Example - Smart Dispatcher Pattern">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"hooks"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"PreToolUse"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"matcher"</span><span class="token builtin class-name">:</span> <span class="token string">"Bash"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"hooks"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">            <span class="token string">"type"</span><span class="token builtin class-name">:</span> <span class="token string">"command"</span>,</span>
<span class="line"></span>
<span class="line">            <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"./scripts/smart-hook-dispatcher.sh"</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Smart Dispatcher Script:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token shebang important">#!/bin/bash</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Read JSON input from Claude Code</span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">json_input</span><span class="token operator">=</span><span class="token variable"><span class="token variable">$(</span><span class="token function">cat</span><span class="token variable">)</span></span></span>
<span class="line"></span>
<span class="line"><span class="token assign-left variable">command</span><span class="token operator">=</span><span class="token variable"><span class="token variable">$(</span><span class="token builtin class-name">echo</span> <span class="token string">"<span class="token variable">$json_input</span>"</span> <span class="token operator">|</span> jq <span class="token parameter variable">-r</span> <span class="token string">'.tool_input.command // empty'</span><span class="token variable">)</span></span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Exit early if no command</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">if</span> <span class="token punctuation">[</span> <span class="token parameter variable">-z</span> <span class="token string">"<span class="token variable">$command</span>"</span> <span class="token punctuation">]</span><span class="token punctuation">;</span> <span class="token keyword">then</span></span>
<span class="line"></span>
<span class="line">  <span class="token builtin class-name">exit</span> <span class="token number">0</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">fi</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Scope to specific commands only</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">if</span> <span class="token builtin class-name">echo</span> <span class="token string">"<span class="token variable">$command</span>"</span> <span class="token operator">|</span> <span class="token function">grep</span> <span class="token parameter variable">-q</span> <span class="token string">"npm run deploy"</span><span class="token punctuation">;</span> <span class="token keyword">then</span></span>
<span class="line"></span>
<span class="line">  <span class="token builtin class-name">echo</span> <span class="token string">"🚀 Running pre-deployment validation..."</span></span>
<span class="line"></span>
<span class="line">  ./scripts/pre-deployment-checks.sh <span class="token operator">&amp;</span>lt<span class="token punctuation">;</span><span class="token operator">&lt;&lt;</span> <span class="token string">"<span class="token variable">$json_input</span>"</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">fi</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">if</span> <span class="token builtin class-name">echo</span> <span class="token string">"<span class="token variable">$command</span>"</span> <span class="token operator">|</span> <span class="token function">grep</span> <span class="token parameter variable">-q</span> <span class="token string">"npm run build"</span><span class="token punctuation">;</span> <span class="token keyword">then</span></span>
<span class="line"></span>
<span class="line">  <span class="token builtin class-name">echo</span> <span class="token string">"🔧 Running build validation..."</span></span>
<span class="line"></span>
<span class="line">  ./scripts/build-validator.sh <span class="token operator">&lt;&lt;&lt;</span> <span class="token string">"<span class="token variable">$json_input</span>"</span></span>
<span class="line"></span>
<span class="line"><span class="token keyword">fi</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><em>This intelligently routes commands based on content analysis, only running expensive operations when needed</em></p>
<hr>
<hr>
<h3 id="finding-hook-opportunities​" tabindex="-1"><a class="header-anchor" href="#finding-hook-opportunities​"><span>Finding Hook Opportunities<a href="#finding-hook-opportunities" title="Direct link to Finding Hook Opportunities">​</a></span></a></h3>
<p>To find suggestions for where hooks could be useful within your setup be sure to ask Claude to review your current systems and suggest the benefit of Hooks.</p>
<p>Just beware that if they're unnecessarily firing you will have an extremely slowed down Agent (thankfully it is not costing you tokens though).</p>
<h3 id="available-triggers​" tabindex="-1"><a class="header-anchor" href="#available-triggers​"><span>Available Triggers<a href="#available-triggers" title="Direct link to Available Triggers">​</a></span></a></h3>
<ul>
<li><strong>PreToolUse</strong> - Before tool execution</li>
<li><strong>PostToolUse</strong> - After tool completion</li>
<li><strong>UserPromptSubmit</strong> - When user submits a prompt</li>
<li><strong>Stop</strong> - When Claude Code agent finishes responding</li>
</ul>
<h3 id="best-practices​" tabindex="-1"><a class="header-anchor" href="#best-practices​"><span>Best Practices<a href="#best-practices" title="Direct link to Best Practices">​</a></span></a></h3>
<ul>
<li><strong>Smart dispatching</strong> - Use single entry point with intelligent command routing to avoid performance penalties</li>
<li><strong>Exit code checking</strong> - Validate successful command execution in PostToolUse hooks (<code v-pre>.tool_response.exit_code</code> only available after execution)</li>
<li><strong>Parallel execution</strong> - Run independent validations concurrently with <code v-pre>&amp;</code> and <code v-pre>wait</code> for faster processing</li>
<li><strong>JSON input parsing</strong> - Extract command details with <code v-pre>jq -r '.tool_input.command // empty'</code> (fallback handles missing fields gracefully)</li>
<li><strong>Performance monitoring</strong> - Track hook execution time and cache results to identify bottlenecks</li>
<li><strong>Error handling</strong> - Graceful failure for non-critical hooks prevents workflow interruption</li>
<li><strong>Scope precisely</strong> - Target specific commands rather than broad tool categories to maintain responsiveness</li>
</ul>
<h5 id="workflow-automation" tabindex="-1"><a class="header-anchor" href="#workflow-automation"><span>Workflow Automation</span></a></h5>
<p>Hooks transform reactive development into proactive automation. Well-scoped hooks eliminate manual deployment steps and catch issues before they reach production. The key is precise trigger patterns.</p>
<p>&lt;img src=&quot;/img/discovery/032_wind_orange.png&quot; alt=&quot;Custom image&quot; style=&quot;max-width: 165px; height: auto;&quot; /&gt;</p>
<hr>
<p><strong>See Also</strong>: <RouteLink to="/configuration/">Configuration</RouteLink>|<RouteLink to="/faqs/what-is-hooks-in-claude-code/">What is Hooks in Claude Code</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#real-world-implementation">Real-World Implementation</a></li>
<li><a href="#the-scoping-challenge">The Scoping Challenge</a></li>
<li><a href="#badly-scoped-hook-example">Badly Scoped Hook Example</a></li>
<li><a href="#better-scoped-hook-example---smart-dispatcher-pattern">Better Scoped Hook Example - Smart Dispatcher Pattern</a></li>
<li><a href="#finding-hook-opportunities">Finding Hook Opportunities</a></li>
<li><a href="#available-triggers">Available Triggers</a></li>
<li><a href="#best-practices">Best Practices</a></li>
</ul>
</div></template>


