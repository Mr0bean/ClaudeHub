<template><div><h1 id="tweakcc-claudelog" tabindex="-1"><a class="header-anchor" href="#tweakcc-claudelog"><span>TweakCC | ClaudeLog</span></a></h1>
<p><strong>Lightweight CLI tool for personalizing your Claude Code interface with custom themes and visual enhancements</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/Piebald-AI" target="_blank" rel="noopener noreferrer">@Piebald-AI</a>  |  <a href="https://github.com/Piebald-AI/tweakcc" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  69 Stars|4 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>TweakCC transforms your Claude Code experience through comprehensive interface personalization. This lightweight CLI tool allows you to customize colors, animations, messaging, and styling to create a unique development environment that reflects your personal preferences.</p>
<p>Built with React and Ink, TweakCC provides an interactive terminal interface for creating custom themes, selecting from over 70 animations, and personalizing every aspect of your Claude Code CLI experience.</p>
<hr>
<hr>
<!-- Screenshot temporarily removed due to missing asset -->
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Custom Theme Creation</strong> - Interactive HSL/RGB color picker for complete interface customization</li>
<li><strong>70+ Thinking Animations</strong> - Choose from a vast collection of spinning and processing animations</li>
<li><strong>Personalized Thinking Verbs</strong> - Custom messages displayed during Claude's processing states</li>
<li><strong>Markdown Element Styling</strong> - Customize the appearance of markdown elements in responses (Work in Progress)</li>
<li><strong>User Message Styling</strong> - Personalize how your messages appear in chat history</li>
<li><strong>Banner Text Customization</strong> - Change banner text with figlet font styling</li>
<li><strong>Cross-Platform Support</strong> - Compatible with Windows, macOS, and Linux</li>
<li><strong>Persistent Configuration</strong> - Settings saved in <code v-pre>~/.tweakcc/config.js</code> and persist across updates</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Quick Start (Recommended)</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">npx tweakcc</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Alternative Package Managers</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Using pnpm</span></span>
<span class="line"></span>
<span class="line"><span class="token function">pnpm</span> dlx tweakcc</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Global installation (if preferred)</span></span>
<span class="line"></span>
<span class="line"><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> tweakcc</span>
<span class="line"></span>
<span class="line">tweakcc</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Interactive Theme Creation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Launch the customization interface</span></span>
<span class="line"></span>
<span class="line">npx tweakcc</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Follow the interactive prompts to:</p>
<ul>
<li><strong>Select custom colors</strong> with visual picker</li>
<li><strong>Choose from 70+ animations</strong> for processing states</li>
<li><strong>Set personalized thinking verbs</strong> for custom messaging</li>
<li><strong>Configure markdown styling</strong> for response formatting (WIP feature)</li>
</ul>
<p><strong>Configuration Management</strong></p>
<p>TweakCC works by patching Claude Code's <code v-pre>cli.js</code> file and saves your preferences to <code v-pre>~/.tweakcc/config.js</code>. Your customizations include:</p>
<ul>
<li><strong>Color Themes</strong> - HSL/RGB values for interface elements</li>
<li><strong>Animation Selection</strong> - Preferred thinking/processing animations</li>
<li><strong>Custom Messages</strong> - Personalized thinking verbs and banner text</li>
<li><strong>Style Overrides</strong> - Markdown and user message styling preferences</li>
</ul>
<p><strong>Environment Integration</strong></p>
<ul>
<li>Your customizations automatically apply when running Claude Code</li>
<li>Configurations persist across Claude Code updates</li>
<li>Re-run tweakcc to modify or update your theme</li>
<li>Compatible with Claude Code version 1.0.88</li>
</ul>
<p>For detailed configuration options and advanced theming, see the <a href="https://github.com/Piebald-AI/tweakcc" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<hr>
<h3 id="integration-with-claude-code​" tabindex="-1"><a class="header-anchor" href="#integration-with-claude-code​"><span>Integration with Claude Code<a href="#integration-with-claude-code" title="Direct link to Integration with Claude Code">​</a></span></a></h3>
<p>TweakCC seamlessly integrates with your Claude Code installation, providing a personalized interface without affecting core functionality.</p>
<p><strong>Enhanced Development Experience</strong></p>
<ul>
<li>Visual customization that matches your development environment</li>
<li>Personalized animations and messages for a unique CLI experience</li>
<li>Persistent theming that survives Claude Code updates</li>
<li>Interactive configuration that makes customization accessible to all users</li>
</ul>
<h5 id="cli-personalization" tabindex="-1"><a class="header-anchor" href="#cli-personalization"><span>CLI Personalization</span></a></h5>
<p>Developers spend significant time in CLI environments, and TweakCC addresses the desire for personalized, visually appealing interfaces. The tool makes Claude Code feel uniquely yours while maintaining all its powerful functionality.</p>
<img src="/img/discovery/036_cl.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>TweakCC is developed by Piebald LLC as a community project. For technical support and updates, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
<li><a href="#integration-with-claude-code">Integration with Claude Code</a></li>
</ul>
</div></template>


