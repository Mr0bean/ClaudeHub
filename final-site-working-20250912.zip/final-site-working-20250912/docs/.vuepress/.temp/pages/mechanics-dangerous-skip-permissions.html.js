import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-dangerous-skip-permissions.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-dangerous-skip-permissions.html\",\"title\":\"Dangerous Skip Permissions | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Dangerous Skip Permissions | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-dangerous-skip-permissions.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
