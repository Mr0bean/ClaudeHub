<template><div><h1 id="todo-lists-as-instruction-mirrors-claudelog" tabindex="-1"><a class="header-anchor" href="#todo-lists-as-instruction-mirrors-claudelog"><span>Todo Lists as Instruction Mirrors | ClaudeLog</span></a></h1>
<p>The Todo list tool is my second favourite Claude Code tool, second only to the Task/Agent tool. The Todo list tool serves a purpose beyond just tracking progress, it reveals how Claude interprets your instructions.</p>
<p>I often benchmark my instructions against Claude's todos, particularly for step by step processes I am aspiring for a mirror like reflection. When his todos mirror my intentions, I know my instructions are grokked. When his todos diverge, it flags an area for potential improvement in my communication.</p>
<hr>
<hr>
<p><strong>Todo List Divergence</strong></p>
<ul>
<li><strong>Out of Order</strong>: Instructions specify step A then B, but Claude's todos list B then A</li>
<li><strong>Missing Todo Item</strong>: Instructions mention running tests, but Claude's todo list omits this step entirely</li>
<li><strong>Extra Todo Item</strong>: Claude adds &quot;backup existing files&quot; when instructions never mentioned this</li>
<li><strong>Wrong Granularity</strong>: Instructions say &quot;update documentation&quot; but Claude creates separate todos for each individual file</li>
<li><strong>Misinterpreted Step</strong>: Instructions say &quot;review changes&quot; but Claude lists &quot;commit changes&quot; instead</li>
</ul>
<p><strong>Real-Time Steering</strong></p>
<p>Claude's todo list communicates the effects of real-time steering of Claude's goals. You can steer future todo items as Claude reviews your prompts mid-task and uses them to update his planning.</p>
<p>Consider a basic example of changing an element's colour. Properly utilising the todo list allows for clearer steering of future todos as you can see exactly what he plans to do.</p>
<p><strong>Before Steering:</strong></p>
<ul>
<li>Fix the navigation menu alignment</li>
<li>Update the footer text</li>
<li>Add new contact form validation</li>
<li>Change the button background color to <code v-pre>blue</code></li>
<li>Update documentation</li>
</ul>
<p><strong>Mid-task Steering:</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Actually <span class="token function">make</span> it green instead</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>After Steering:</strong></p>
<ul>
<li>Fix the navigation menu alignment</li>
<li>Update the footer text</li>
<li>Add new contact form validation</li>
<li>Change the button background color to <code v-pre>green</code></li>
<li>Update documentation</li>
</ul>
<h5 id="experiment" tabindex="-1"><a class="header-anchor" href="#experiment"><span>Experiment</span></a></h5>
<p>Try encouraging Claude to be granular with his todos. Instead of &quot;style the navbar,&quot; get Claude to reveal specific adjustments: &quot;change height from 60px to 80px,&quot; &quot;reduce padding-top from 16px to 12px,&quot; &quot;adjust background from #ffffff to rgba(255,255,255,0.95).&quot; This transparency exposes Claude's design decisions before he makes them, letting you approve or redirect his aesthetic choices.</p>
<img src="/img/discovery/024_excite_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/you-are-the-main-thread/">You Are the Main Thread</RouteLink>|<RouteLink to="/mechanics/tight-feedback-loops/">Tight Feedback Loops</RouteLink>|<RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
</div></template>


