<template><div><h1 id="humanising-agents-claudelog" tabindex="-1"><a class="header-anchor" href="#humanising-agents-claudelog"><span>Humanising Agents | ClaudeLog</span></a></h1>
<p><code v-pre>Custom agents</code> are assigned distinct personalities through their specialised roles, system prompts, and tool configurations. However, the default interaction model can feel overly formal. We can create more engaging collaborations by humanizing our agents with <code v-pre>nicknames</code> and expressive <code v-pre>text-faces</code>.</p>
<hr>
<hr>
<h2 id="beyond-formal-invocation​" tabindex="-1"><a class="header-anchor" href="#beyond-formal-invocation​"><span>Beyond Formal Invocation<a href="#beyond-formal-invocation" title="Direct link to Beyond Formal Invocation">​</a></span></a></h2>
<p>Traditional agent invocation feels mechanical:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">ask performance optimiser assistant to review the changes</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>With <RouteLink to="/mechanics/agent-engineering/#agent-nicknaming-for-efficiency">nicknames</RouteLink>, the interaction becomes more natural:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">ask P1 to review the changes</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>But we can go even further by adding personality through <code v-pre>text-faces</code>, creating agents that feel more like collaborators than tools.</p>
<hr>
<hr>
<h2 id="text-face-personalities​" tabindex="-1"><a class="header-anchor" href="#text-face-personalities​"><span>Text-Face Personalities<a href="#text-face-personalities" title="Direct link to Text-Face Personalities">​</a></span></a></h2>
<p>While playing around with different ways to personalize agents, I had the idea of exploring <code v-pre>text-faces</code>. When it first loaded I knew it was a hit! Each face represents the agent's personality, role, or typical mood while complementing the clean terminal aesthetic that developers love.</p>
<h3 id="text-face-examples-by-role​" tabindex="-1"><a class="header-anchor" href="#text-face-examples-by-role​"><span>Text-Face Examples by Role<a href="#text-face-examples-by-role" title="Direct link to Text-Face Examples by Role">​</a></span></a></h3>
<p>Each category shows different personality approaches for common development roles:</p>
<h4 id="debugging-testing​" tabindex="-1"><a class="header-anchor" href="#debugging-testing​"><span>Debugging &amp; Testing<a href="#debugging--testing" title="Direct link to Debugging &amp; Testing">​</a></span></a></h4>
<p><code v-pre>( ͡° ͜ʖ ͡°) Mischievous Debugger</code> - Playful problem solver who enjoys hunting down tricky bugs <code v-pre>(つ◉益◉)つ Bug Hunter</code> - Aggressive pursuer of software defects <code v-pre>(¬_¬) Test Engineer</code> - Skeptical validator who questions everything</p>
<h4 id="code-review-quality​" tabindex="-1"><a class="header-anchor" href="#code-review-quality​"><span>Code Review &amp; Quality<a href="#code-review--quality" title="Direct link to Code Review &amp; Quality">​</a></span></a></h4>
<p><code v-pre>¯\_(ツ)_/¯ Casual Code Reviewer</code> - Laid-back reviewer who keeps things simple and practical <code v-pre>(ㆆ_ㆆ) Quality Auditor</code> - Sharp-eyed observer who notices every detail <code v-pre>ಠ_ಠ Security Analyst</code> - Disapproving guardian of system security</p>
<h4 id="performance-optimization​" tabindex="-1"><a class="header-anchor" href="#performance-optimization​"><span>Performance &amp; Optimization<a href="#performance--optimization" title="Direct link to Performance &amp; Optimization">​</a></span></a></h4>
<p><code v-pre>'(ᗒᗣᗕ)՞ Performance Optimizer</code> - High-energy assistant focused on speed and efficiency <code v-pre>★⌒ヽ( ͡° ε ͡°) Performance Tuner</code> - Stellar optimizer of system performance <code v-pre>˙ ͜ʟ˙ Memory Manager</code> - Focused fighter against memory leaks</p>
<h4 id="development-refactoring​" tabindex="-1"><a class="header-anchor" href="#development-refactoring​"><span>Development &amp; Refactoring<a href="#development--refactoring" title="Direct link to Development &amp; Refactoring">​</a></span></a></h4>
<p><code v-pre>(• ε •) Gentle Refactorer</code> - Soft-spoken helper that improves code with care <code v-pre>ʕ•ᴥ•ʔ UI Developer</code> - Friendly interface specialist with a warm approach <code v-pre>(ง'̀-'́)ง Dead Code Remover</code> - Fighting eliminator of unused code</p>
<h4 id="documentation-communication​" tabindex="-1"><a class="header-anchor" href="#documentation-communication​"><span>Documentation &amp; Communication<a href="#documentation--communication" title="Direct link to Documentation &amp; Communication">​</a></span></a></h4>
<p><code v-pre>(͡• ͜໒ ͡• ) Documentation Writer</code> - Loving creator of beautiful documentation <code v-pre>♥‿♥ Requirements Helper</code> - Sweet assistant for unclear specifications <code v-pre>┌༼◉ل͟◉༽┐ Grammar Checker</code> - Intense scrutinizer of language precision</p>
<h4 id="operations-management​" tabindex="-1"><a class="header-anchor" href="#operations-management​"><span>Operations &amp; Management<a href="#operations--management" title="Direct link to Operations &amp; Management">​</a></span></a></h4>
<p><code v-pre>┗(▀̿Ĺ̯▀̿ ̿)┓ Git Manager</code> - Cool operator dancing between branches <code v-pre>( ͡ _ ͡°)ﾉ⚲ Deployment Guard</code> - Waving protector of production releases <code v-pre>⚆_⚆ Database Expert</code> - Wide-eyed master of data management</p>
<h4 id="specialized-creative​" tabindex="-1"><a class="header-anchor" href="#specialized-creative​"><span>Specialized &amp; Creative<a href="#specialized--creative" title="Direct link to Specialized &amp; Creative">​</a></span></a></h4>
<p><code v-pre>【≽ܫ≼】 Research King</code> - Magnificent gatherer of knowledge and insights <code v-pre>⋋| ◉ ͟ʖ ◉ |⋌ Metrics Spy</code> - Watchful observer of performance data <code v-pre>(┛ಠДಠ)┛彡┻━┻ Frustrated Developer</code> - Overwhelmed coder who's had enough</p>
<hr>
<hr>
<h2 id="implementation-strategy​" tabindex="-1"><a class="header-anchor" href="#implementation-strategy​"><span>Implementation Strategy<a href="#implementation-strategy" title="Direct link to Implementation Strategy">​</a></span></a></h2>
<p>When designing your own humanized assistants, use the categories above as a starting point:</p>
<ol>
<li><strong>Match personality to function</strong> - A <code v-pre>┗(▀̿Ĺ̯▀̿ ̿)┓ Git Manager</code> needs different energy than a <code v-pre>(• ε •) Gentle Refactorer</code></li>
<li><strong>Choose appropriate intensity</strong> - Compare the laid-back <code v-pre>¯\_(ツ)_/¯ Casual Code Reviewer</code> with the intense <code v-pre>┌༼◉ل͟◉༽┐ Grammar Checker</code></li>
<li><strong>Consider your team context</strong> - The <code v-pre>(┛ಠДಠ)┛彡┻━┻ Frustrated Developer</code> might work in casual teams but not formal environments</li>
<li><strong>Match complexity to specialization</strong> - Complex faces like <code v-pre>⋌༼ •̀ ⌂ •́ ༽⋋ Algorithm Expert</code> should match equally specialized roles</li>
<li><strong>Test display compatibility</strong> - Ensure your chosen <code v-pre>text-faces</code> render correctly across different terminals and systems</li>
</ol>
<hr>
<h2 id="resources​" tabindex="-1"><a class="header-anchor" href="#resources​"><span>Resources<a href="#resources" title="Direct link to Resources">​</a></span></a></h2>
<p>For additional <code v-pre>text-face</code> inspiration, explore: <a href="https://texteditor.com/text-faces/" target="_blank" rel="noopener noreferrer">Text Faces Collection</a></p>
<p>Color Personalization</p>
<p>You can match the color of your custom agent output to make it even more personalized! Each agent can have its own distinctive color scheme that complements its <code v-pre>text-face</code> personality.</p>
<h5 id="fun-social-coding" tabindex="-1"><a class="header-anchor" href="#fun-social-coding"><span>Fun &amp; Social Coding</span></a></h5>
<p>Using <code v-pre>text-faces</code> with <code v-pre>custom agents</code> transforms coding from a solitary technical task into something surprisingly fun and social! Each assistant feels like a distinct personality you're collaborating with, making development sessions more engaging.</p>
<img src="/img/discovery/021_happy_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink> | <RouteLink to="/mechanics/agent-engineering/">Agent Engineering</RouteLink> | <RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#beyond-formal-invocation">Beyond Formal Invocation</a></li>
<li><a href="#text-face-personalities">Text-Face Personalities</a>
<ul>
<li><a href="#text-face-examples-by-role">Text-Face Examples by Role</a></li>
</ul>
</li>
<li><a href="#implementation-strategy">Implementation Strategy</a></li>
<li><a href="#resources">Resources</a></li>
</ul>
</div></template>


