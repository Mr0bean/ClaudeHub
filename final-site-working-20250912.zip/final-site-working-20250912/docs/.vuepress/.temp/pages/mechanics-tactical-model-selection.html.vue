<template><div><h1 id="tactical-model-selection-claudelog" tabindex="-1"><a class="header-anchor" href="#tactical-model-selection-claudelog"><span>Tactical Model Selection | ClaudeLog</span></a></h1>
<p>I have seen a trend amongst developers of opting to use Opus for everything. Not only is this a costly habit, but Claude Opus is not necessarily the best model for every operation. Behind the scenes, Anthropic tactically chooses when to utilise Claude Haiku 3.5 to perform routine grunt work which requires minimal intelligence.</p>
<hr>
<hr>
<h2 id="model-selection-strategy​" tabindex="-1"><a class="header-anchor" href="#model-selection-strategy​"><span>Model Selection Strategy<a href="#model-selection-strategy" title="Direct link to Model Selection Strategy">​</a></span></a></h2>
<p><strong>Context Window Considerations:</strong></p>
<ul>
<li><strong>Standard Models</strong>: 200K tokens (Opus, Sonnet 3.5, Haiku)</li>
<li><strong>Sonnet 4 via API</strong>: 1M tokens (5x larger context window)</li>
</ul>
<p><strong>Opus (Most Expensive, Highest Capability, 200K Context):</strong></p>
<ul>
<li>Complex architectural decisions requiring deep reasoning</li>
<li>Multi-step logical problems with intricate dependencies</li>
<li>Creative tasks requiring nuanced understanding</li>
<li>Code reviews requiring architectural judgment</li>
<li>Complex refactoring across multiple systems</li>
</ul>
<p><strong>Sonnet 4 (Balanced Cost-Performance, 1M Context via API):</strong></p>
<ul>
<li>Ideal for large codebases - 1M token window eliminates context constraints</li>
<li>Standard feature implementation and development tasks</li>
<li>Most debugging and troubleshooting scenarios</li>
<li>Code generation with moderate complexity</li>
<li>Documentation writing and editing</li>
<li>Task coordination and workflow management</li>
<li>Extended development sessions without context resets</li>
</ul>
<p><strong>Haiku (Cheapest, Fastest):</strong></p>
<ul>
<li>Simple file reads and basic content extraction</li>
<li>Routine formatting and style corrections</li>
<li>Basic syntax validation and linting</li>
<li>Simple text transformations and data parsing</li>
<li>Quick status checks and basic analysis</li>
</ul>
<p><strong>Opus Plan Mode (Hybrid Intelligence):</strong></p>
<ul>
<li>Complex planning with economical execution</li>
<li>Architectural decisions requiring Opus-level reasoning</li>
<li>Large refactoring projects with cost constraints</li>
</ul>
<hr>
<hr>
<h2 id="cost-optimization-approach​" tabindex="-1"><a class="header-anchor" href="#cost-optimization-approach​"><span>Cost Optimization Approach<a href="#cost-optimization-approach" title="Direct link to Cost Optimization Approach">​</a></span></a></h2>
<p>I would set Claude 4 Sonnet as the base model and for specific tasks instruct Claude to launch a Claude Opus instance with <code v-pre>claude --model claude-opus-4-20250514</code>. This would allow specific processes to run Opus as their base model.</p>
<p><strong>Context Window Strategy:</strong></p>
<ul>
<li><strong>For large projects</strong>: Use Sonnet 4 via API to leverage the 1M token context window</li>
<li><strong>For complex reasoning</strong>: Switch to Opus when architectural decisions require superior analysis</li>
<li><strong>For simple tasks</strong>: Use Haiku for basic operations to minimize costs</li>
</ul>
<p>This tactic can potentially offer huge cost savings over having Opus drive all processes. Due to Claude 4 Opus being approximately 5x more expensive than Claude 4 Sonnet, there is substantial financial budget for exploring orchestration configurations with sub-agents to bring costs down whilst retaining performance. Sonnet 4's massive 1M token context via API often eliminates the need for Opus in large codebase scenarios.</p>
<p><strong>Note:</strong> When spawning Claude instances in print mode you may need to increase the <code v-pre>max turns</code> so that the process completes: <code v-pre>claude -p --model claude-opus-4-20250514 --max-turns 20</code></p>
<h5 id="cost-optimization" tabindex="-1"><a class="header-anchor" href="#cost-optimization"><span>Cost Optimization</span></a></h5>
<p>Strategic model selection can reduce Claude Code usage costs by up to 80% while maintaining output quality for most development tasks.</p>
<img src="/img/discovery/019.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/model-comparison/">Model Comparison</RouteLink>|<RouteLink to="/mechanics/context-window-depletion/">Context Window Depletion</RouteLink>|<RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#model-selection-strategy">Model Selection Strategy</a></li>
<li><a href="#cost-optimization-approach">Cost Optimization Approach</a></li>
</ul>
</div></template>


