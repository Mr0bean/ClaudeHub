<template><div><h1 id="claude-news-timeline-claudelog" tabindex="-1"><a class="header-anchor" href="#claude-news-timeline-claudelog"><span>Claude News Timeline | ClaudeLog</span></a></h1>
<p>Stay up-to-date with the latest announcements, product updates, and news from Anthropic about Claude.</p>
<hr>
<hr>
<h2 id="september-2025​" tabindex="-1"><a class="header-anchor" href="#september-2025​"><span><strong>September 2025</strong><a href="#september-2025" title="Direct link to september-2025">​</a></span></a></h2>
<h3 id="claude-can-now-create-and-edit-files​" tabindex="-1"><a class="header-anchor" href="#claude-can-now-create-and-edit-files​"><span><a href="https://www.anthropic.com/news/create-files" target="_blank" rel="noopener noreferrer">Claude can now create and edit files</a><a href="#claude-can-now-create-and-edit-files" title="Direct link to claude-can-now-create-and-edit-files">​</a></span></a></h3>
<p>Claude can now create and edit <code v-pre>Excel spreadsheets</code>, <code v-pre>documents</code>, <code v-pre>PowerPoint slides</code>, and <code v-pre>PDFs</code> directly in <code v-pre>Claude.ai</code> and the <code v-pre>desktop app</code>, transforming how users work by producing ready-to-use files from instructions and data. This feature is available as a preview for <code v-pre>Max</code>, <code v-pre>Team</code>, and <code v-pre>Enterprise</code> users, with <code v-pre>Pro</code> users getting access in <code v-pre>coming weeks</code>.</p>
<p>Sep 9, 2025 | Category: Product</p>
<hr>
<h3 id="anthropic-is-endorsing-sb-53​" tabindex="-1"><a class="header-anchor" href="#anthropic-is-endorsing-sb-53​"><span><a href="https://www.anthropic.com/news/anthropic-is-endorsing-sb-53" target="_blank" rel="noopener noreferrer">Anthropic is endorsing SB 53</a><a href="#anthropic-is-endorsing-sb-53" title="Direct link to anthropic-is-endorsing-sb-53">​</a></span></a></h3>
<p>Anthropic is endorsing California's <code v-pre>SB 53</code>, a bill governing powerful AI systems that requires companies to develop <code v-pre>safety frameworks</code>, publish <code v-pre>transparency reports</code>, and report <code v-pre>critical incidents</code> to the state. The company supports this <code v-pre>trust but verify</code> approach as it formalizes practices already followed by <code v-pre>frontier AI companies</code> while creating a level playing field for safety disclosure.</p>
<p>Sep 8, 2025 | Category: Announcements</p>
<hr>
<h3 id="updating-restrictions-of-sales-to-unsupported-regions​" tabindex="-1"><a class="header-anchor" href="#updating-restrictions-of-sales-to-unsupported-regions​"><span><a href="https://www.anthropic.com/news/updating-restrictions-of-sales-to-unsupported-regions" target="_blank" rel="noopener noreferrer">Updating restrictions of sales to unsupported regions</a><a href="#updating-restrictions-of-sales-to-unsupported-regions" title="Direct link to updating-restrictions-of-sales-to-unsupported-regions">​</a></span></a></h3>
<p>Anthropic is strengthening regional restrictions to prevent companies controlled by adversarial nations like <code v-pre>China</code> from accessing their services, even through subsidiaries in other countries. The updated policy prohibits entities more than <code v-pre>50% owned</code> by companies from unsupported regions, addressing <code v-pre>national security risks</code> where authoritarian governments can compel data sharing and intelligence cooperation.</p>
<p>Sep 4, 2025 | Category: Announcements</p>
<hr>
<h3 id="anthropic-raises-13b-series-f-at-183b-post-money-valuation​" tabindex="-1"><a class="header-anchor" href="#anthropic-raises-13b-series-f-at-183b-post-money-valuation​"><span><a href="https://www.anthropic.com/news/anthropic-raises-series-f-at-usd183b-post-money-valuation" target="_blank" rel="noopener noreferrer">Anthropic raises $13B Series F at $183B post-money valuation</a><a href="#anthropic-raises-13b-series-f-at-183b-post-money-valuation" title="Direct link to anthropic-raises-13b-series-f-at-183b-post-money-valuation">​</a></span></a></h3>
<p>Anthropic completed a <code v-pre>$13 billion</code> <code v-pre>Series F</code> funding round led by <code v-pre>ICONIQ</code>, valuing the company at <code v-pre>$183 billion</code> post-money with participation from major investors including <code v-pre>Fidelity</code>, <code v-pre>Lightspeed</code>, and <code v-pre>BlackRock</code>. The funding reflects Anthropic's rapid growth from <code v-pre>$1 billion</code> run-rate revenue in <code v-pre>early 2025</code> to over <code v-pre>$5 billion</code> by <code v-pre>August</code>, making it one of the fastest-growing technology companies in history.</p>
<p>Sep 2, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="august-2025​" tabindex="-1"><a class="header-anchor" href="#august-2025​"><span><strong>August 2025</strong><a href="#august-2025" title="Direct link to august-2025">​</a></span></a></h2>
<h3 id="updates-to-consumer-terms-and-privacy-policy​" tabindex="-1"><a class="header-anchor" href="#updates-to-consumer-terms-and-privacy-policy​"><span><a href="https://www.anthropic.com/news/updates-to-our-consumer-terms" target="_blank" rel="noopener noreferrer">Updates to Consumer Terms and Privacy Policy</a><a href="#updates-to-consumer-terms-and-privacy-policy" title="Direct link to updates-to-consumer-terms-and-privacy-policy">​</a></span></a></h3>
<p>Anthropic updated its Consumer Terms and Privacy Policy to allow training new models using data from <code v-pre>Free</code>, <code v-pre>Pro</code>, and <code v-pre>Max</code> accounts when users <code v-pre>opt-in</code>, with an extended <code v-pre>5-year</code> data retention period for those who consent. Current users have until <code v-pre>September 28, 2025</code> to make their selection, while new users choose during signup.</p>
<p>Aug 28, 2025 | Category: Product</p>
<hr>
<h3 id="introducing-the-anthropic-national-security-and-public-sector-advisory-council​" tabindex="-1"><a class="header-anchor" href="#introducing-the-anthropic-national-security-and-public-sector-advisory-council​"><span><a href="https://www.anthropic.com/news/introducing-the-anthropic-national-security-and-public-sector-advisory-council" target="_blank" rel="noopener noreferrer">Introducing the Anthropic National Security and Public Sector Advisory Council</a><a href="#introducing-the-anthropic-national-security-and-public-sector-advisory-council" title="Direct link to introducing-the-anthropic-national-security-and-public-sector-advisory-council">​</a></span></a></h3>
<p>Anthropic formed the <code v-pre>National Security and Public Sector Advisory Council</code>, featuring <code v-pre>bipartisan</code> former government leaders including Senators <code v-pre>Roy Blunt</code> and <code v-pre>Jon Tester</code>, former <code v-pre>Defense officials</code>, and <code v-pre>intelligence community veterans</code>. The council will help identify high-impact AI applications for <code v-pre>national security</code>, develop industry standards, and strengthen <code v-pre>public-private partnerships</code>.</p>
<p>Aug 27, 2025 | Category: Announcements</p>
<hr>
<h3 id="detecting-and-countering-misuse-of-ai-august-2025​" tabindex="-1"><a class="header-anchor" href="#detecting-and-countering-misuse-of-ai-august-2025​"><span><a href="https://www.anthropic.com/news/detecting-countering-misuse-aug-2025" target="_blank" rel="noopener noreferrer">Detecting and countering misuse of AI: August 2025</a><a href="#detecting-and-countering-misuse-of-ai-august-2025" title="Direct link to detecting-and-countering-misuse-of-ai-august-2025">​</a></span></a></h3>
<p>Anthropic's threat intelligence report reveals sophisticated AI misuse including a <code v-pre>large-scale extortion operation</code> using <code v-pre>Claude Code</code>, <code v-pre>North Korean</code> employment fraud schemes, and <code v-pre>AI-generated ransomware</code> sales. The report shows cybercriminals are weaponizing <code v-pre>agentic AI</code> to perform attacks rather than just advise, lowering barriers to sophisticated cybercrime for actors with <code v-pre>minimal technical skills</code>.</p>
<p>Aug 27, 2025 | Category: Announcements</p>
<hr>
<h3 id="claude-code-and-new-admin-controls-for-business-plans​" tabindex="-1"><a class="header-anchor" href="#claude-code-and-new-admin-controls-for-business-plans​"><span><a href="https://www.anthropic.com/news/claude-code-on-team-and-enterprise" target="_blank" rel="noopener noreferrer">Claude Code and new admin controls for business plans</a><a href="#claude-code-and-new-admin-controls-for-business-plans" title="Direct link to claude-code-and-new-admin-controls-for-business-plans">​</a></span></a></h3>
<p><code v-pre>Claude Code</code> is now available for <code v-pre>Team</code> and <code v-pre>Enterprise</code> customers through <code v-pre>premium seats</code> that include enhanced usage and coding capabilities, allowing seamless transitions between ideation and implementation. New admin controls include <code v-pre>self-serve seat management</code>, <code v-pre>granular spend controls</code>, <code v-pre>usage analytics</code>, and a <code v-pre>Compliance API</code> for real-time programmatic access to usage data.</p>
<p>Aug 20, 2025 | Category: Product</p>
<hr>
<h3 id="anthropic-appoints-hidetoshi-tojo-as-head-of-japan-and-announces-hiring-plans​" tabindex="-1"><a class="header-anchor" href="#anthropic-appoints-hidetoshi-tojo-as-head-of-japan-and-announces-hiring-plans​"><span><a href="https://www.anthropic.com/news/head-of-japan-hiring-plans" target="_blank" rel="noopener noreferrer">Anthropic appoints Hidetoshi Tojo as Head of Japan and announces hiring plans</a><a href="#anthropic-appoints-hidetoshi-tojo-as-head-of-japan-and-announces-hiring-plans" title="Direct link to anthropic-appoints-hidetoshi-tojo-as-head-of-japan-and-announces-hiring-plans">​</a></span></a></h3>
<p>Anthropic appointed <code v-pre>Hidetoshi Tojo</code> as Head of Japan, bringing extensive experience from scaling technology companies including <code v-pre>Snowflake</code>, <code v-pre>Google Cloud</code>, and <code v-pre>Microsoft</code> across Japan operations. The appointment supports Anthropic's expansion plans including opening their <code v-pre>first Asia office</code> in <code v-pre>Tokyo</code> and hiring local talent to serve Japanese customers.</p>
<p>Aug 6, 2025 | Category: Announcements</p>
<hr>
<h3 id="automate-security-reviews-with-claude-code​" tabindex="-1"><a class="header-anchor" href="#automate-security-reviews-with-claude-code​"><span><a href="https://www.anthropic.com/news/automate-security-reviews-with-claude-code" target="_blank" rel="noopener noreferrer">Automate security reviews with Claude Code</a><a href="#automate-security-reviews-with-claude-code" title="Direct link to automate-security-reviews-with-claude-code">​</a></span></a></h3>
<p><code v-pre>Claude Code</code> introduced automated security reviews through a new <code v-pre>/security-review</code> command and <code v-pre>GitHub Actions</code> integration that identifies vulnerabilities like <code v-pre>SQL injection</code>, <code v-pre>XSS</code>, and <code v-pre>authentication flaws</code> before code reaches production. The features allow <code v-pre>ad-hoc security analysis</code> from terminals and <code v-pre>automatic pull request reviews</code> with inline comments and fix recommendations.</p>
<p>Aug 6, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="july-2025​" tabindex="-1"><a class="header-anchor" href="#july-2025​"><span><strong>July 2025</strong><a href="#july-2025" title="Direct link to july-2025">​</a></span></a></h2>
<h3 id="anthropic-to-sign-the-eu-code-of-practice​" tabindex="-1"><a class="header-anchor" href="#anthropic-to-sign-the-eu-code-of-practice​"><span><a href="https://www.anthropic.com/news/eu-code-practice" target="_blank" rel="noopener noreferrer">Anthropic to sign the EU Code of Practice</a><a href="#anthropic-to-sign-the-eu-code-of-practice" title="Direct link to anthropic-to-sign-the-eu-code-of-practice">​</a></span></a></h3>
<p>Anthropic announced its intention to sign the <code v-pre>EU's General-Purpose AI Code of Practice</code>, viewing it as advancing <code v-pre>transparency</code>, <code v-pre>safety</code>, and <code v-pre>accountability</code> principles for frontier AI development. The Code establishes mandatory <code v-pre>Safety and Security Frameworks</code> building on Anthropic's <code v-pre>Responsible Scaling Policy</code> while maintaining flexibility to adapt with evolving technology.</p>
<p>Jul 21, 2025 | Category: Policy</p>
<hr>
<h3 id="paul-smith-to-join-anthropic-as-chief-commercial-officer​" tabindex="-1"><a class="header-anchor" href="#paul-smith-to-join-anthropic-as-chief-commercial-officer​"><span><a href="https://www.anthropic.com/news/paul-smith-to-join-anthropic" target="_blank" rel="noopener noreferrer">Paul Smith to join Anthropic as Chief Commercial Officer</a><a href="#paul-smith-to-join-anthropic-as-chief-commercial-officer" title="Direct link to paul-smith-to-join-anthropic-as-chief-commercial-officer">​</a></span></a></h3>
<p><code v-pre>Paul Smith</code> will join Anthropic as its <code v-pre>first Chief Commercial Officer</code> later in <code v-pre>2025</code>, bringing over <code v-pre>30 years</code> of experience building global go-to-market organizations at <code v-pre>Microsoft</code>, <code v-pre>Salesforce</code>, and <code v-pre>ServiceNow</code>. The appointment comes during exceptional growth with <code v-pre>hundreds of thousands</code> of active API customers and <code v-pre>Claude Code</code> revenue growing over <code v-pre>5x</code> in <code v-pre>two months</code>.</p>
<p>Jul 15, 2025 | Category: Announcements</p>
<hr>
<h3 id="anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations​" tabindex="-1"><a class="header-anchor" href="#anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations​"><span><a href="https://www.anthropic.com/news/anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations" target="_blank" rel="noopener noreferrer">Anthropic and the Department of Defense to advance responsible AI in defense operations</a><a href="#anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations" title="Direct link to anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations">​</a></span></a></h3>
<p>Anthropic received a <code v-pre>$200 million</code>, <code v-pre>two-year</code> agreement from the <code v-pre>U.S. Department of Defense</code> to prototype frontier AI capabilities for <code v-pre>national security applications</code>. The partnership will focus on developing working prototypes fine-tuned on <code v-pre>DOD</code> data, collaborating on <code v-pre>adversarial AI mitigation</code>, and accelerating responsible AI adoption across defense operations.</p>
<p>Jul 14, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="june-2025​" tabindex="-1"><a class="header-anchor" href="#june-2025​"><span><strong>June 2025</strong><a href="#june-2025" title="Direct link to june-2025">​</a></span></a></h2>
<h3 id="national-security-expert-richard-fontaine-appointed-to-anthropic-s-long-term-benefit-trust​" tabindex="-1"><a class="header-anchor" href="#national-security-expert-richard-fontaine-appointed-to-anthropic-s-long-term-benefit-trust​"><span><a href="https://www.anthropic.com/news/national-security-expert-richard-fontaine-appointed-to-anthropic-s-long-term-benefit-trust" target="_blank" rel="noopener noreferrer">National security expert Richard Fontaine appointed to Anthropic’s long-term benefit trust</a><a href="#national-security-expert-richard-fontaine-appointed-to-anthropics-long-term-benefit-trust" title="Direct link to national-security-expert-richard-fontaine-appointed-to-anthropics-long-term-benefit-trust">​</a></span></a></h3>
<p><code v-pre>Richard Fontaine</code>, CEO of the <code v-pre>Center for a New American Security</code>, was appointed to Anthropic's <code v-pre>Long-Term Benefit Trust</code>, bringing extensive <code v-pre>national security experience</code> including roles at the <code v-pre>NSC</code>, <code v-pre>State Department</code>, and <code v-pre>Defense Policy Board</code>. His appointment addresses the growing intersection between <code v-pre>AI capabilities</code> and <code v-pre>geopolitical risks</code>, strengthening the Trust's ability to guide Anthropic through complex decisions.</p>
<p>Jun 7, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="may-2025​" tabindex="-1"><a class="header-anchor" href="#may-2025​"><span><strong>May 2025</strong><a href="#may-2025" title="Direct link to may-2025">​</a></span></a></h2>
<h3 id="reed-hastings-appointed-to-anthropic-s-board-of-directors​" tabindex="-1"><a class="header-anchor" href="#reed-hastings-appointed-to-anthropic-s-board-of-directors​"><span><a href="https://www.anthropic.com/news/reed-hastings" target="_blank" rel="noopener noreferrer">Reed Hastings appointed to Anthropic’s board of directors</a><a href="#reed-hastings-appointed-to-anthropics-board-of-directors" title="Direct link to reed-hastings-appointed-to-anthropics-board-of-directors">​</a></span></a></h3>
<p><code v-pre>Reed Hastings</code>, <code v-pre>Netflix</code> co-founder and former CEO, was appointed to Anthropic's <code v-pre>board of directors</code> by the <code v-pre>Long-Term Benefit Trust</code>. <code v-pre>Hastings</code> brings <code v-pre>25+ years</code> of scaling experience and recently donated <code v-pre>$50 million</code> to establish an <code v-pre>AI and Humanity research initiative</code> at <code v-pre>Bowdoin College</code>.</p>
<p>May 28, 2025 | Category: Announcements</p>
<hr>
<h3 id="new-capabilities-for-building-agents-on-the-anthropic-api​" tabindex="-1"><a class="header-anchor" href="#new-capabilities-for-building-agents-on-the-anthropic-api​"><span><a href="https://www.anthropic.com/news/agent-capabilities-api" target="_blank" rel="noopener noreferrer">New capabilities for building agents on the Anthropic API</a><a href="#new-capabilities-for-building-agents-on-the-anthropic-api" title="Direct link to new-capabilities-for-building-agents-on-the-anthropic-api">​</a></span></a></h3>
<p>Anthropic announced <code v-pre>four new API capabilities</code> for building AI agents: <code v-pre>code execution tool</code> for <code v-pre>Python</code> analysis, <code v-pre>MCP connector</code> for external system integration, <code v-pre>Files API</code> for document management, and extended <code v-pre>prompt caching</code> up to <code v-pre>one hour</code>. These features enable developers to build more powerful agents that can execute code, connect to third-party services, manage files across sessions, and maintain context <code v-pre>cost-effectively</code>.</p>
<p>May 22, 2025 | Category: Product</p>
<hr>
<hr>
<h2 id="april-2025​" tabindex="-1"><a class="header-anchor" href="#april-2025​"><span><strong>April 2025</strong><a href="#april-2025" title="Direct link to april-2025">​</a></span></a></h2>
<h3 id="claude-takes-research-to-new-places​" tabindex="-1"><a class="header-anchor" href="#claude-takes-research-to-new-places​"><span><a href="https://www.anthropic.com/news/research" target="_blank" rel="noopener noreferrer">Claude takes research to new places</a><a href="#claude-takes-research-to-new-places" title="Direct link to claude-takes-research-to-new-places">​</a></span></a></h3>
<p>Anthropic introduced <code v-pre>Research capabilities</code> that enable Claude to conduct <code v-pre>multi-step web searches</code> and a <code v-pre>Google Workspace</code> integration connecting <code v-pre>Gmail</code>, <code v-pre>Calendar</code>, and <code v-pre>Google Docs</code>. Research allows Claude to operate <code v-pre>agentically</code>, exploring different angles and building <code v-pre>comprehensive answers</code> with citations, while the Google Workspace integration provides deeper work context without manual file uploads.</p>
<p>Apr 15, 2025 | Category: Product</p>
<hr>
<h3 id="anthropic-appoints-guillaume-princen-as-head-of-emea-and-announces-100-new-roles-across-the-region​" tabindex="-1"><a class="header-anchor" href="#anthropic-appoints-guillaume-princen-as-head-of-emea-and-announces-100-new-roles-across-the-region​"><span><a href="https://www.anthropic.com/news/head-of-EMEA-new-roles" target="_blank" rel="noopener noreferrer">Anthropic appoints Guillaume Princen as Head of EMEA and announces 100+ new roles across the region</a><a href="#anthropic-appoints-guillaume-princen-as-head-of-emea-and-announces-100-new-roles-across-the-region" title="Direct link to anthropic-appoints-guillaume-princen-as-head-of-emea-and-announces-100-new-roles-across-the-region">​</a></span></a></h3>
<p><code v-pre>Guillaume Princen</code> was appointed as Anthropic's <code v-pre>Head of EMEA</code>, bringing experience from scaling <code v-pre>Stripe</code>'s European operations across <code v-pre>12 offices</code> and serving as CEO of <code v-pre>Mooncard</code>. Anthropic plans to create over <code v-pre>100 new roles</code> across sales, engineering, research, and operations in <code v-pre>Dublin</code> and <code v-pre>London</code> offices this year.</p>
<p>Apr 8, 2025 | Category: Announcements</p>
<hr>
<h3 id="introducing-anthropic-s-first-developer-conference-code-with-claude​" tabindex="-1"><a class="header-anchor" href="#introducing-anthropic-s-first-developer-conference-code-with-claude​"><span><a href="https://www.anthropic.com/news/Introducing-code-with-claude" target="_blank" rel="noopener noreferrer">Introducing Anthropic's first developer conference: Code with Claude</a><a href="#introducing-anthropics-first-developer-conference-code-with-claude" title="Direct link to introducing-anthropics-first-developer-conference-code-with-claude">​</a></span></a></h3>
<p>Anthropic announced <code v-pre>Code with Claude</code>, its <code v-pre>first developer conference</code> taking place <code v-pre>May 22, 2025</code> in <code v-pre>San Francisco</code> at <code v-pre>The Midway</code>. The hands-on event will focus on real-world implementations using the <code v-pre>Anthropic API</code>, <code v-pre>CLI tools</code>, and <code v-pre>Model Context Protocol (MCP)</code>, featuring interactive workshops, product roadmap discussions, and networking opportunities.</p>
<p>Apr 3, 2025 | Category: Event</p>
<hr>
<hr>
<h2 id="march-2025​" tabindex="-1"><a class="header-anchor" href="#march-2025​"><span><strong>March 2025</strong><a href="#march-2025" title="Direct link to march-2025">​</a></span></a></h2>
<h3 id="progress-from-our-frontier-red-team​" tabindex="-1"><a class="header-anchor" href="#progress-from-our-frontier-red-team​"><span><a href="https://www.anthropic.com/news/strategic-warning-for-ai-risk-progress-and-insights-from-our-frontier-red-team" target="_blank" rel="noopener noreferrer">Progress from our Frontier Red Team</a><a href="#progress-from-our-frontier-red-team" title="Direct link to progress-from-our-frontier-red-team">​</a></span></a></h3>
<p>Anthropic's <code v-pre>Frontier Red Team</code> reported significant progress in AI capabilities across <code v-pre>cybersecurity</code> and <code v-pre>biology</code>, with Claude advancing from <code v-pre>high school</code> to <code v-pre>undergraduate level</code> in cybersecurity CTF challenges within <code v-pre>one year</code>. While models show <code v-pre>early warning signs</code> in dual-use capabilities and exceed <code v-pre>expert baselines</code> in some biology tasks, they still fall short of thresholds for substantially elevated <code v-pre>national security risks</code>.</p>
<p>Mar 19, 2025 | Category: Policy</p>
<hr>
<hr>
<h2 id="february-2025​" tabindex="-1"><a class="header-anchor" href="#february-2025​"><span><strong>February 2025</strong><a href="#february-2025" title="Direct link to february-2025">​</a></span></a></h2>
<h3 id="anthropic-partners-with-u-s-national-labs-for-first-1-000-scientist-ai-jam​" tabindex="-1"><a class="header-anchor" href="#anthropic-partners-with-u-s-national-labs-for-first-1-000-scientist-ai-jam​"><span><a href="https://www.anthropic.com/news/anthropic-partners-with-u-s-national-labs-for-first-1-000-scientist-ai-jam" target="_blank" rel="noopener noreferrer">Anthropic partners with U.S. National Labs for first 1,000 Scientist AI Jam</a><a href="#anthropic-partners-with-us-national-labs-for-first-1000-scientist-ai-jam" title="Direct link to anthropic-partners-with-us-national-labs-for-first-1000-scientist-ai-jam">​</a></span></a></h3>
<p>Anthropic partnered with the <code v-pre>U.S. Department of Energy</code> for the first <code v-pre>1,000 Scientist AI Jam</code>, bringing together scientists from multiple <code v-pre>National Laboratories</code> to evaluate <code v-pre>Claude 3.7 Sonnet</code> on scientific research and <code v-pre>national security applications</code>. The event will test Claude's capabilities across real-world research problems including <code v-pre>hypothesis generation</code>, <code v-pre>experiment planning</code>, and <code v-pre>result analysis</code>.</p>
<p>Feb 28, 2025 | Category: Announcements</p>
<hr>
<h3 id="introducing-anthropic-s-transparency-hub​" tabindex="-1"><a class="header-anchor" href="#introducing-anthropic-s-transparency-hub​"><span><a href="https://www.anthropic.com/news/introducing-anthropic-transparency-hub" target="_blank" rel="noopener noreferrer">Introducing Anthropic's Transparency Hub</a><a href="#introducing-anthropics-transparency-hub" title="Direct link to introducing-anthropics-transparency-hub">​</a></span></a></h3>
<p>Anthropic launched its <code v-pre>Transparency Hub</code>, providing detailed information on <code v-pre>safety protocols</code>, <code v-pre>risk mitigation strategies</code>, <code v-pre>platform abuse detection</code>, and <code v-pre>governance policies</code>. The hub includes the first periodic report on key metrics like <code v-pre>banned accounts</code>, <code v-pre>appeals</code>, and <code v-pre>government requests</code>, designed as a unified framework to address diverse transparency requirements.</p>
<p>Feb 27, 2025 | Category: Societal Impacts</p>
<hr>
<h3 id="claude-and-alexa-​" tabindex="-1"><a class="header-anchor" href="#claude-and-alexa-​"><span><a href="https://www.anthropic.com/news/claude-and-alexa-plus" target="_blank" rel="noopener noreferrer">Claude and Alexa+</a><a href="#claude-and-alexa" title="Direct link to claude-and-alexa">​</a></span></a></h3>
<p>Claude models now power <code v-pre>Amazon's Alexa+</code> through a collaboration between Anthropic and Amazon teams, with Anthropic's Chief Product Officer <code v-pre>Mike Krieger</code> leading the integration effort. Alexa+ benefits from Claude's <code v-pre>advanced capabilities</code> and <code v-pre>safety features</code>, including <code v-pre>jailbreaking resistance</code>, and accesses Claude through <code v-pre>Amazon Bedrock</code>.</p>
<p>Feb 26, 2025 | Category: Announcements</p>
<hr>
<h3 id="statement-from-dario-amodei-on-the-paris-ai-action-summit​" tabindex="-1"><a class="header-anchor" href="#statement-from-dario-amodei-on-the-paris-ai-action-summit​"><span><a href="https://www.anthropic.com/news/paris-ai-summit" target="_blank" rel="noopener noreferrer">Statement from Dario Amodei on the Paris AI Action Summit</a><a href="#statement-from-dario-amodei-on-the-paris-ai-action-summit" title="Direct link to statement-from-dario-amodei-on-the-paris-ai-action-summit">​</a></span></a></h3>
<p><code v-pre>Dario Amodei</code> issued a statement following the <code v-pre>Paris AI Action Summit</code> emphasizing three critical areas needing greater focus: ensuring <code v-pre>democratic societies</code> lead in AI development, addressing growing security risks including <code v-pre>CBRN threats</code> and <code v-pre>autonomous AI dangers</code>, and preparing for massive <code v-pre>economic disruption</code> from AI advancement. He warned that by <code v-pre>2026-2027</code>, AI capabilities could resemble a <code v-pre>country of geniuses in a datacenter</code> and called for accelerated action to match the pace of AI progress.</p>
<p>Feb 11, 2025 | Category: Announcements</p>
<hr>
<h3 id="lyft-to-bring-claude-to-more-than-40-million-riders-and-over-1-million-drivers​" tabindex="-1"><a class="header-anchor" href="#lyft-to-bring-claude-to-more-than-40-million-riders-and-over-1-million-drivers​"><span><a href="https://www.anthropic.com/news/lyft-announcement" target="_blank" rel="noopener noreferrer">Lyft to bring Claude to more than 40 million riders and over 1 million drivers</a><a href="#lyft-to-bring-claude-to-more-than-40-million-riders-and-over-1-million-drivers" title="Direct link to lyft-to-bring-claude-to-more-than-40-million-riders-and-over-1-million-drivers">​</a></span></a></h3>
<p><code v-pre>Lyft</code> is partnering with Anthropic to integrate Claude across its platform serving over <code v-pre>40 million riders</code> and <code v-pre>1 million drivers</code>, focusing on AI-powered solutions, early testing of new models, and engineering advancement. The collaboration has already shown <code v-pre>significant impact</code>, with Lyft's Claude-powered customer care assistant reducing resolution time by <code v-pre>87%</code> while handling <code v-pre>thousands of daily inquiries</code>.</p>
<p>Feb 6, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="january-2025​" tabindex="-1"><a class="header-anchor" href="#january-2025​"><span><strong>January 2025</strong><a href="#january-2025" title="Direct link to january-2025">​</a></span></a></h2>
<h3 id="introducing-citations-on-the-anthropic-api​" tabindex="-1"><a class="header-anchor" href="#introducing-citations-on-the-anthropic-api​"><span><a href="https://www.anthropic.com/news/introducing-citations-api" target="_blank" rel="noopener noreferrer">Introducing Citations on the Anthropic API</a><a href="#introducing-citations-on-the-anthropic-api" title="Direct link to introducing-citations-on-the-anthropic-api">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Citations</code>, a new API feature that allows Claude to ground its responses in source documents by providing detailed references to <code v-pre>exact sentences</code> and <code v-pre>passages</code> used to generate answers. The feature is generally available on the <code v-pre>Anthropic API</code> and <code v-pre>Google Cloud's Vertex AI</code>, with internal evaluations showing up to <code v-pre>15%</code> improvement in <code v-pre>recall accuracy</code> compared to custom implementations.</p>
<p>Jan 23, 2025 | Category: Product</p>
<hr>
<h3 id="anthropic-achieves-iso-42001-certification-for-responsible-ai​" tabindex="-1"><a class="header-anchor" href="#anthropic-achieves-iso-42001-certification-for-responsible-ai​"><span><a href="https://www.anthropic.com/news/anthropic-achieves-iso-42001-certification-for-responsible-ai" target="_blank" rel="noopener noreferrer">Anthropic achieves ISO 42001 certification for responsible AI</a><a href="#anthropic-achieves-iso-42001-certification-for-responsible-ai" title="Direct link to anthropic-achieves-iso-42001-certification-for-responsible-ai">​</a></span></a></h3>
<p>Anthropic achieved <code v-pre>ISO 42001</code> certification, the <code v-pre>first international standard</code> for AI governance and management systems, making it <code v-pre>one of the first frontier AI labs</code> to receive this accreditation. The certification validates Anthropic's comprehensive framework for identifying, assessing, and mitigating AI risks through policies, testing, transparency measures, and established oversight responsibilities.</p>
<p>Jan 13, 2025 | Category: Announcements</p>
<hr>
<hr>
<h2 id="december-2024​" tabindex="-1"><a class="header-anchor" href="#december-2024​"><span><strong>December 2024</strong><a href="#december-2024" title="Direct link to december-2024">​</a></span></a></h2>
<h3 id="elections-and-ai-in-2024-observations-and-learnings​" tabindex="-1"><a class="header-anchor" href="#elections-and-ai-in-2024-observations-and-learnings​"><span><a href="https://www.anthropic.com/news/elections-ai-2024" target="_blank" rel="noopener noreferrer">Elections and AI in 2024: observations and learnings</a><a href="#elections-and-ai-in-2024-observations-and-learnings" title="Direct link to elections-and-ai-in-2024-observations-and-learnings">​</a></span></a></h3>
<p>Anthropic published observations from the <code v-pre>2024 election cycle</code>, noting that election-related activity constituted less than <code v-pre>0.5%</code> of overall Claude usage, rising to just over <code v-pre>1%</code> during peak election weeks. The company implemented comprehensive safety measures including policy enforcement, rigorous testing, and directing users to authoritative sources, while using their new <code v-pre>Clio tool</code> to analyze usage patterns and ensure responsible AI deployment during elections.</p>
<p>Dec 12, 2024 | Category: Societal Impacts</p>
<hr>
<h3 id="claude-3-5-haiku-on-aws-trainium2-and-model-distillation-in-amazon-bedrock​" tabindex="-1"><a class="header-anchor" href="#claude-3-5-haiku-on-aws-trainium2-and-model-distillation-in-amazon-bedrock​"><span><a href="https://www.anthropic.com/news/trainium2-and-distillation" target="_blank" rel="noopener noreferrer">Claude 3.5 Haiku on AWS Trainium2 and model distillation in Amazon Bedrock</a><a href="#claude-35-haiku-on-aws-trainium2-and-model-distillation-in-amazon-bedrock" title="Direct link to claude-35-haiku-on-aws-trainium2-and-model-distillation-in-amazon-bedrock">​</a></span></a></h3>
<p>Anthropic announced <code v-pre>Claude 3.5 Haiku</code> optimization for <code v-pre>AWS Trainium2</code> chips, delivering up to <code v-pre>60%</code> faster inference speeds, and introduced model distillation in <code v-pre>Amazon Bedrock</code> that enables <code v-pre>Claude 3 Haiku</code> to achieve <code v-pre>Claude 3.5 Sonnet</code>-like accuracy for specific tasks. The company also reduced <code v-pre>Claude 3.5 Haiku</code> pricing to <code v-pre>$0.80</code> per million input tokens and <code v-pre>$4</code> per million output tokens across all platforms.</p>
<p>Dec 3, 2024 | Category: Product</p>
<hr>
<hr>
<h2 id="november-2024​" tabindex="-1"><a class="header-anchor" href="#november-2024​"><span><strong>November 2024</strong><a href="#november-2024" title="Direct link to november-2024">​</a></span></a></h2>
<h3 id="tailor-claude-s-responses-to-your-personal-style​" tabindex="-1"><a class="header-anchor" href="#tailor-claude-s-responses-to-your-personal-style​"><span><a href="https://www.anthropic.com/news/styles" target="_blank" rel="noopener noreferrer">Tailor Claude’s responses to your personal style</a><a href="#tailor-claudes-responses-to-your-personal-style" title="Direct link to tailor-claudes-responses-to-your-personal-style">​</a></span></a></h3>
<p>Anthropic introduced <code v-pre>custom styles</code> for <code v-pre>Claude.ai</code>, allowing users to tailor Claude's responses to match their communication preferences, tone, and structure. Users can choose from <code v-pre>preset options</code> (<code v-pre>Formal</code>, <code v-pre>Concise</code>, <code v-pre>Explanatory</code>) or generate <code v-pre>custom styles</code> by uploading sample content, enabling Claude to adapt to individual workflows and writing preferences.</p>
<p>Nov 26, 2024 | Category: Product</p>
<hr>
<h3 id="introducing-the-model-context-protocol​" tabindex="-1"><a class="header-anchor" href="#introducing-the-model-context-protocol​"><span><a href="https://www.anthropic.com/news/model-context-protocol" target="_blank" rel="noopener noreferrer">Introducing the Model Context Protocol</a><a href="#introducing-the-model-context-protocol" title="Direct link to introducing-the-model-context-protocol">​</a></span></a></h3>
<p>Anthropic open-sourced the <code v-pre>Model Context Protocol (MCP)</code>, a new standard for connecting AI assistants to data sources including content repositories, business tools, and development environments. MCP provides a <code v-pre>universal protocol</code> to replace fragmented integrations, with <code v-pre>local server support</code> in <code v-pre>Claude Desktop</code> apps and pre-built servers for popular enterprise systems like <code v-pre>Google Drive</code>, <code v-pre>Slack</code>, <code v-pre>GitHub</code>, and <code v-pre>Postgres</code>.</p>
<p>Nov 25, 2024 | Category: Announcements</p>
<hr>
<h3 id="powering-the-next-generation-of-ai-development-with-aws​" tabindex="-1"><a class="header-anchor" href="#powering-the-next-generation-of-ai-development-with-aws​"><span><a href="https://www.anthropic.com/news/anthropic-amazon-trainium" target="_blank" rel="noopener noreferrer">Powering the next generation of AI development with AWS</a><a href="#powering-the-next-generation-of-ai-development-with-aws" title="Direct link to powering-the-next-generation-of-ai-development-with-aws">​</a></span></a></h3>
<p>Anthropic announced an expanded <code v-pre>$4 billion</code> partnership with <code v-pre>AWS</code>, bringing Amazon's total investment to <code v-pre>$8 billion</code> while establishing AWS as their <code v-pre>primary cloud and training partner</code>. The collaboration includes deep technical work on <code v-pre>AWS Trainium</code> accelerators, with Anthropic contributing to hardware optimization and the <code v-pre>AWS Neuron</code> software stack to train their most advanced foundation models.</p>
<p>Nov 22, 2024 | Category: Announcements</p>
<hr>
<h3 id="improve-your-prompts-in-the-developer-console​" tabindex="-1"><a class="header-anchor" href="#improve-your-prompts-in-the-developer-console​"><span><a href="https://www.anthropic.com/news/prompt-improver" target="_blank" rel="noopener noreferrer">Improve your prompts in the developer console</a><a href="#improve-your-prompts-in-the-developer-console" title="Direct link to improve-your-prompts-in-the-developer-console">​</a></span></a></h3>
<p>Anthropic introduced a <code v-pre>prompt improver feature</code> in the developer console that automatically refines existing prompts using advanced engineering techniques like <code v-pre>chain-of-thought reasoning</code> and <code v-pre>example standardization</code>. The tool also includes <code v-pre>structured example management</code> and <code v-pre>evaluation capabilities</code>, with testing showing <code v-pre>30%</code> accuracy improvements for classification tasks and <code v-pre>100%</code> word count adherence for summarization.</p>
<p>Nov 14, 2024 | Category: Product</p>
<hr>
<hr>
<h2 id="october-2024​" tabindex="-1"><a class="header-anchor" href="#october-2024​"><span><strong>October 2024</strong><a href="#october-2024" title="Direct link to october-2024">​</a></span></a></h2>
<h3 id="the-case-for-targeted-regulation​" tabindex="-1"><a class="header-anchor" href="#the-case-for-targeted-regulation​"><span><a href="https://www.anthropic.com/news/the-case-for-targeted-regulation" target="_blank" rel="noopener noreferrer">The case for targeted regulation</a><a href="#the-case-for-targeted-regulation" title="Direct link to the-case-for-targeted-regulation">​</a></span></a></h3>
<p>Anthropic published their position on AI regulation, advocating for targeted, <code v-pre>RSP-based (Responsible Scaling Policy)</code> regulation that focuses on <code v-pre>transparency</code>, incentivizing better <code v-pre>safety practices</code>, and maintaining <code v-pre>simplicity</code>. The company argues that governments should urgently act within <code v-pre>18 months</code> to implement proportionate regulation that addresses <code v-pre>catastrophic risks</code> while supporting innovation, emphasizing the need for <code v-pre>surgical rather than broad</code> regulatory approaches.</p>
<p>Oct 31, 2024 | Category: Policy</p>
<hr>
<h3 id="claude-3-5-sonnet-on-github-copilot​" tabindex="-1"><a class="header-anchor" href="#claude-3-5-sonnet-on-github-copilot​"><span><a href="https://www.anthropic.com/news/github-copilot" target="_blank" rel="noopener noreferrer">Claude 3.5 Sonnet on GitHub Copilot</a><a href="#claude-35-sonnet-on-github-copilot" title="Direct link to claude-35-sonnet-on-github-copilot">​</a></span></a></h3>
<p><code v-pre>Claude 3.5 Sonnet</code> became available on <code v-pre>GitHub Copilot</code>, bringing Claude's coding capabilities to over <code v-pre>100 million developers</code> through <code v-pre>Visual Studio Code</code> and <code v-pre>GitHub.com</code>. The upgraded model outperforms all publicly available models on <code v-pre>SWE-bench Verified</code> and achieves <code v-pre>93.7%</code> on <code v-pre>HumanEval</code>, enabling developers to write production-ready code, debug with inline chat, and create comprehensive test suites.</p>
<p>Oct 29, 2024 | Category: Announcements</p>
<hr>
<h3 id="introducing-the-analysis-tool-in-claude-ai​" tabindex="-1"><a class="header-anchor" href="#introducing-the-analysis-tool-in-claude-ai​"><span><a href="https://www.anthropic.com/news/analysis-tool" target="_blank" rel="noopener noreferrer">Introducing the analysis tool in Claude.ai</a><a href="#introducing-the-analysis-tool-in-claudeai" title="Direct link to introducing-the-analysis-tool-in-claudeai">​</a></span></a></h3>
<p>Anthropic launched the <code v-pre>analysis tool</code> in <code v-pre>Claude.ai</code>, a built-in <code v-pre>JavaScript</code> code sandbox that enables Claude to write and run code for data processing, analysis, and <code v-pre>real-time insights</code>. The tool allows Claude to work like a <code v-pre>data analyst</code> by systematically processing data from <code v-pre>CSV files</code>, providing <code v-pre>mathematically precise</code> and <code v-pre>reproducible answers</code> for various business teams including <code v-pre>marketing</code>, <code v-pre>sales</code>, <code v-pre>product management</code>, and <code v-pre>finance</code>.</p>
<p>Oct 24, 2024 | Category: Product</p>
<hr>
<h3 id="developing-a-computer-use-model​" tabindex="-1"><a class="header-anchor" href="#developing-a-computer-use-model​"><span><a href="https://www.anthropic.com/news/developing-computer-use" target="_blank" rel="noopener noreferrer">Developing a computer use model</a><a href="#developing-a-computer-use-model" title="Direct link to developing-a-computer-use-model">​</a></span></a></h3>
<p>Anthropic announced Claude's new <code v-pre>computer use capability</code>, allowing the AI to control computers by <code v-pre>taking screenshots</code>, <code v-pre>moving cursors</code>, <code v-pre>clicking</code>, and <code v-pre>typing</code> like humans do. This represents a <code v-pre>significant breakthrough</code> in AI progress, enabling Claude to use <code v-pre>any software directly</code> rather than requiring custom tools, though the feature remains <code v-pre>slow and error-prone</code> in its current <code v-pre>beta state</code>.</p>
<p>Oct 22, 2024 | Category: Announcements</p>
<hr>
<h3 id="announcing-our-updated-responsible-scaling-policy​" tabindex="-1"><a class="header-anchor" href="#announcing-our-updated-responsible-scaling-policy​"><span><a href="https://www.anthropic.com/news/announcing-our-updated-responsible-scaling-policy" target="_blank" rel="noopener noreferrer">Announcing our updated Responsible Scaling Policy</a><a href="#announcing-our-updated-responsible-scaling-policy" title="Direct link to announcing-our-updated-responsible-scaling-policy">​</a></span></a></h3>
<p>Anthropic released a major update to its <code v-pre>Responsible Scaling Policy (RSP)</code>, introducing more flexible <code v-pre>risk assessment methods</code> and refined <code v-pre>capability thresholds</code> for upgrading safety measures. The updated framework includes new <code v-pre>AI Safety Level Standards</code> and specific thresholds for <code v-pre>autonomous AI research capabilities</code> and <code v-pre>CBRN weapons assistance</code>, while maintaining the core commitment not to deploy models without adequate safeguards.</p>
<p>Oct 15, 2024 | Category: Announcements</p>
<hr>
<h3 id="u-s-elections-readiness​" tabindex="-1"><a class="header-anchor" href="#u-s-elections-readiness​"><span><a href="https://www.anthropic.com/news/us-elections-readiness" target="_blank" rel="noopener noreferrer">U.S. Elections Readiness</a><a href="#us-elections-readiness" title="Direct link to us-elections-readiness">​</a></span></a></h3>
<p>Anthropic outlined its comprehensive <code v-pre>election readiness measures</code> for the <code v-pre>2024 U.S. elections</code>, including updated usage policies prohibiting <code v-pre>campaigning</code> and <code v-pre>misinformation</code>, <code v-pre>automated enforcement systems</code>, and redirecting users to <code v-pre>authoritative voting information</code>. The company implemented strict controls against election-related misuse while conducting ongoing <code v-pre>vulnerability testing</code> and policy refinements to ensure responsible AI use during the election period.</p>
<p>Oct 8, 2024 | Category: Societal Impacts</p>
<hr>
<h3 id="introducing-the-message-batches-api​" tabindex="-1"><a class="header-anchor" href="#introducing-the-message-batches-api​"><span><a href="https://www.anthropic.com/news/message-batches-api" target="_blank" rel="noopener noreferrer">Introducing the Message Batches API</a><a href="#introducing-the-message-batches-api" title="Direct link to introducing-the-message-batches-api">​</a></span></a></h3>
<p>Anthropic launched the <code v-pre>Message Batches API</code>, enabling developers to process up to <code v-pre>10,000 queries</code> asynchronously at <code v-pre>50%</code> lower cost than standard API calls. The service processes batches within <code v-pre>24 hours</code> and offers enhanced throughput without impacting standard rate limits, making <code v-pre>large-scale data processing</code> more economically viable for tasks like dataset analysis and document processing.</p>
<p>Oct 8, 2024 | Category: Product</p>
<hr>
<hr>
<h2 id="september-2024​" tabindex="-1"><a class="header-anchor" href="#september-2024​"><span><strong>September 2024</strong><a href="#september-2024" title="Direct link to september-2024">​</a></span></a></h2>
<h3 id="fine-tuning-for-claude-3-haiku-in-amazon-bedrock-is-now-generally-available​" tabindex="-1"><a class="header-anchor" href="#fine-tuning-for-claude-3-haiku-in-amazon-bedrock-is-now-generally-available​"><span><a href="https://www.anthropic.com/news/fine-tune-claude-3-haiku-ga" target="_blank" rel="noopener noreferrer">Fine-tuning for Claude 3 Haiku in Amazon Bedrock is now generally available</a><a href="#fine-tuning-for-claude-3-haiku-in-amazon-bedrock-is-now-generally-available" title="Direct link to fine-tuning-for-claude-3-haiku-in-amazon-bedrock-is-now-generally-available">​</a></span></a></h3>
<p>Fine-tuning for <code v-pre>Claude 3 Haiku</code> became generally available in <code v-pre>Amazon Bedrock</code>, allowing developers to customize the <code v-pre>fastest</code> and most <code v-pre>cost-effective</code> Claude model with their own data. The feature enables enhanced <code v-pre>domain expertise</code>, <code v-pre>cost savings</code>, and <code v-pre>faster response times</code>, with demonstrated improvements showing fine-tuned Haiku outperforming even <code v-pre>Claude 3.5 Sonnet</code> base model in specialized <code v-pre>financial analysis tasks</code>.</p>
<p>Sep 23, 2024 | Category: Product</p>
<hr>
<h3 id="introducing-contextual-retrieval​" tabindex="-1"><a class="header-anchor" href="#introducing-contextual-retrieval​"><span><a href="https://www.anthropic.com/news/contextual-retrieval" target="_blank" rel="noopener noreferrer">Introducing Contextual Retrieval</a><a href="#introducing-contextual-retrieval" title="Direct link to introducing-contextual-retrieval">​</a></span></a></h3>
<p>Anthropic introduced <code v-pre>Contextual Retrieval</code>, a new technique that dramatically improves <code v-pre>RAG (Retrieval-Augmented Generation)</code> systems by adding <code v-pre>chunk-specific context</code> before embedding. The method reduces retrieval failures by <code v-pre>49%</code> when combined with <code v-pre>BM25</code>, and up to <code v-pre>67%</code> when paired with <code v-pre>reranking</code>, significantly enhancing the accuracy of knowledge base searches for AI applications.</p>
<p>Sep 19, 2024 | Category: Product</p>
<hr>
<h3 id="workspaces-in-the-anthropic-api-console​" tabindex="-1"><a class="header-anchor" href="#workspaces-in-the-anthropic-api-console​"><span><a href="https://www.anthropic.com/news/workspaces" target="_blank" rel="noopener noreferrer">Workspaces in the Anthropic API Console</a><a href="#workspaces-in-the-anthropic-api-console" title="Direct link to workspaces-in-the-anthropic-api-console">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Workspaces</code> in the <code v-pre>API Console</code> to help developers manage multiple Claude deployments across different environments and use cases. The feature provides <code v-pre>granular spend limits</code>, <code v-pre>resource organization</code>, <code v-pre>independent rate limit management</code>, <code v-pre>streamlined access controls</code>, and <code v-pre>workspace-level usage monitoring</code> for better project management and security.</p>
<p>Sep 10, 2024 | Category: Product</p>
<hr>
<h3 id="claude-for-enterprise​" tabindex="-1"><a class="header-anchor" href="#claude-for-enterprise​"><span><a href="https://www.anthropic.com/news/claude-for-enterprise" target="_blank" rel="noopener noreferrer">Claude for Enterprise</a><a href="#claude-for-enterprise" title="Direct link to claude-for-enterprise">​</a></span></a></h3>
<p>Anthropic announced <code v-pre>Claude for Enterprise</code>, offering a <code v-pre>500K context window</code>, enhanced security features like <code v-pre>SSO</code> and <code v-pre>role-based permissions</code>, and native <code v-pre>GitHub</code> integration for codebase collaboration. The enterprise plan enables organizations to securely work with <code v-pre>internal knowledge</code> while maintaining data protection, with early customers like <code v-pre>GitLab</code> and <code v-pre>Midjourney</code> using it across various business functions.</p>
<p>Sep 4, 2024 | Category: Product</p>
<hr>
<h3 id="salesforce-teams-up-with-anthropic-to-enhance-einstein-capabilities-with-claude​" tabindex="-1"><a class="header-anchor" href="#salesforce-teams-up-with-anthropic-to-enhance-einstein-capabilities-with-claude​"><span><a href="https://www.anthropic.com/news/salesforce-partnership" target="_blank" rel="noopener noreferrer">Salesforce teams up with Anthropic to enhance Einstein capabilities with Claude</a><a href="#salesforce-teams-up-with-anthropic-to-enhance-einstein-capabilities-with-claude" title="Direct link to salesforce-teams-up-with-anthropic-to-enhance-einstein-capabilities-with-claude">​</a></span></a></h3>
<p><code v-pre>Salesforce</code> partnered with Anthropic to integrate Claude models (<code v-pre>3.5 Sonnet</code>, <code v-pre>Opus</code>, and <code v-pre>Haiku</code>) into <code v-pre>Einstein</code> capabilities through <code v-pre>Amazon Bedrock</code>. The integration allows Salesforce customers to use Claude for <code v-pre>sales</code>, <code v-pre>marketing</code>, <code v-pre>customer service</code>, and other enterprise functions while maintaining security through Salesforce's <code v-pre>Einstein Trust Layer</code> and existing compliance standards.</p>
<p>Sep 3, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="august-2024​" tabindex="-1"><a class="header-anchor" href="#august-2024​"><span><strong>August 2024</strong><a href="#august-2024" title="Direct link to august-2024">​</a></span></a></h2>
<h3 id="artifacts-are-now-generally-available​" tabindex="-1"><a class="header-anchor" href="#artifacts-are-now-generally-available​"><span><a href="https://www.anthropic.com/news/artifacts" target="_blank" rel="noopener noreferrer">Artifacts are now generally available</a><a href="#artifacts-are-now-generally-available" title="Direct link to artifacts-are-now-generally-available">​</a></span></a></h3>
<p><code v-pre>Artifacts</code> became generally available to all <code v-pre>Claude.ai</code> users across <code v-pre>Free</code>, <code v-pre>Pro</code>, and <code v-pre>Team</code> plans, including mobile <code v-pre>iOS</code> and <code v-pre>Android</code> apps. The feature creates a dedicated workspace for users to instantly see, iterate, and build on creative work with Claude, from <code v-pre>code snippets</code> and <code v-pre>visualizations</code> to <code v-pre>interactive prototypes</code>, with <code v-pre>tens of millions</code> of Artifacts created since the preview launch.</p>
<p>Aug 27, 2024 | Category: Announcements</p>
<hr>
<h3 id="prompt-caching-with-claude​" tabindex="-1"><a class="header-anchor" href="#prompt-caching-with-claude​"><span><a href="https://www.anthropic.com/news/prompt-caching" target="_blank" rel="noopener noreferrer">Prompt caching with Claude</a><a href="#prompt-caching-with-claude" title="Direct link to prompt-caching-with-claude">​</a></span></a></h3>
<p>Anthropic introduced <code v-pre>prompt caching</code> for Claude, enabling developers to cache frequently used context between API calls with up to <code v-pre>90%</code> cost reduction and <code v-pre>85%</code> latency improvement. The feature is particularly effective for <code v-pre>conversational agents</code>, <code v-pre>coding assistants</code>, and <code v-pre>large document processing</code>, with cached content costing only <code v-pre>10%</code> of base input token prices while cache writes cost <code v-pre>25%</code> more.</p>
<p>Aug 14, 2024 | Category: Product</p>
<hr>
<h3 id="expanding-our-model-safety-bug-bounty-program​" tabindex="-1"><a class="header-anchor" href="#expanding-our-model-safety-bug-bounty-program​"><span><a href="https://www.anthropic.com/news/model-safety-bug-bounty" target="_blank" rel="noopener noreferrer">Expanding our model safety bug bounty program</a><a href="#expanding-our-model-safety-bug-bounty-program" title="Direct link to expanding-our-model-safety-bug-bounty-program">​</a></span></a></h3>
<p>Anthropic expanded its <code v-pre>model safety bug bounty program</code> to focus on identifying <code v-pre>universal jailbreak attacks</code> that could bypass AI safety guardrails across high-risk domains like <code v-pre>CBRN</code> and <code v-pre>cybersecurity</code>. The <code v-pre>invite-only</code> program offers rewards up to <code v-pre>$15,000</code> for novel vulnerabilities and provides <code v-pre>early access</code> to test next-generation safety mitigation systems before public deployment.</p>
<p>Aug 8, 2024 | Category: Announcements</p>
<hr>
<h3 id="claude-is-now-available-in-brazil​" tabindex="-1"><a class="header-anchor" href="#claude-is-now-available-in-brazil​"><span><a href="https://www.anthropic.com/news/claude-brazil" target="_blank" rel="noopener noreferrer">Claude is now available in Brazil</a><a href="#claude-is-now-available-in-brazil" title="Direct link to claude-is-now-available-in-brazil">​</a></span></a></h3>
<p>Anthropic announced Claude's availability in <code v-pre>Brazil</code> on <code v-pre>August 1, 2024</code>, making the AI assistant accessible through <code v-pre>Claude.ai</code>, <code v-pre>mobile apps</code>, and the <code v-pre>API</code>. Brazilian users can access Claude for free or subscribe to <code v-pre>Pro</code> (<code v-pre>R$ 110/month</code>) and <code v-pre>Team</code> plans (<code v-pre>R$ 165/month</code>) with enhanced usage limits and features.</p>
<p>Aug 1, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="july-2024​" tabindex="-1"><a class="header-anchor" href="#july-2024​"><span><strong>July 2024</strong><a href="#july-2024" title="Direct link to july-2024">​</a></span></a></h2>
<h3 id="anthropic-partners-with-menlo-ventures-to-launch-anthology-fund​" tabindex="-1"><a class="header-anchor" href="#anthropic-partners-with-menlo-ventures-to-launch-anthology-fund​"><span><a href="https://www.anthropic.com/news/anthropic-partners-with-menlo-ventures-to-launch-anthology-fund" target="_blank" rel="noopener noreferrer">Anthropic partners with Menlo Ventures to launch Anthology Fund</a><a href="#anthropic-partners-with-menlo-ventures-to-launch-anthology-fund" title="Direct link to anthropic-partners-with-menlo-ventures-to-launch-anthology-fund">​</a></span></a></h3>
<p>Anthropic partnered with <code v-pre>Menlo Ventures</code> to launch the <code v-pre>$100 million</code> <code v-pre>Anthology Fund</code> on <code v-pre>July 17, 2024</code>, aimed at supporting startups building with Anthropic technology. The fund focuses on five key areas including AI infrastructure, healthcare applications, consumer AI solutions, and trust and safety tooling.</p>
<p>Jul 17, 2024 | Category: Announcements</p>
<hr>
<h3 id="claude-android-app​" tabindex="-1"><a class="header-anchor" href="#claude-android-app​"><span><a href="https://www.anthropic.com/news/android-app" target="_blank" rel="noopener noreferrer">Claude Android app</a><a href="#claude-android-app" title="Direct link to claude-android-app">​</a></span></a></h3>
<p>Anthropic launched the <code v-pre>Claude Android app</code> on <code v-pre>July 16, 2024</code>, bringing <code v-pre>Claude 3.5 Sonnet</code> to Android users for free. The app offers cross-platform conversation continuity with web and iOS versions, vision capabilities for image analysis, multilingual processing, and advanced reasoning for complex tasks.</p>
<p>Jul 16, 2024 | Category: Product</p>
<hr>
<h3 id="fine-tune-claude-3-haiku-in-amazon-bedrock​" tabindex="-1"><a class="header-anchor" href="#fine-tune-claude-3-haiku-in-amazon-bedrock​"><span><a href="https://www.anthropic.com/news/fine-tune-claude-3-haiku" target="_blank" rel="noopener noreferrer">Fine-tune Claude 3 Haiku in Amazon Bedrock</a><a href="#fine-tune-claude-3-haiku-in-amazon-bedrock" title="Direct link to fine-tune-claude-3-haiku-in-amazon-bedrock">​</a></span></a></h3>
<p>Anthropic announced fine-tuning capabilities for <code v-pre>Claude 3 Haiku</code> in <code v-pre>Amazon Bedrock</code> on <code v-pre>July 11, 2024</code>, allowing customers to customize the model for specialized business tasks. Fine-tuning enables better performance on domain-specific tasks, faster speeds at lower costs, and consistent brand-aligned formatting.</p>
<p>Jul 11, 2024 | Category: Product</p>
<hr>
<h3 id="evaluate-prompts-in-the-developer-console​" tabindex="-1"><a class="header-anchor" href="#evaluate-prompts-in-the-developer-console​"><span><a href="https://www.anthropic.com/news/evaluate-prompts" target="_blank" rel="noopener noreferrer">Evaluate prompts in the developer console</a><a href="#evaluate-prompts-in-the-developer-console" title="Direct link to evaluate-prompts-in-the-developer-console">​</a></span></a></h3>
<p>Anthropic introduced prompt evaluation features in the developer console on <code v-pre>July 9, 2024</code>, streamlining AI application development. The new tools include automatic prompt generation powered by <code v-pre>Claude 3.5 Sonnet</code>, test case generation, and side-by-side output comparison capabilities.</p>
<p>Jul 9, 2024 | Category: Product</p>
<hr>
<h3 id="a-new-initiative-for-developing-third-party-model-evaluations​" tabindex="-1"><a class="header-anchor" href="#a-new-initiative-for-developing-third-party-model-evaluations​"><span><a href="https://www.anthropic.com/news/a-new-initiative-for-developing-third-party-model-evaluations" target="_blank" rel="noopener noreferrer">A new initiative for developing third-party model evaluations</a><a href="#a-new-initiative-for-developing-third-party-model-evaluations" title="Direct link to a-new-initiative-for-developing-third-party-model-evaluations">​</a></span></a></h3>
<p>Anthropic launched a new initiative on <code v-pre>July 1, 2024</code>, to fund third-party organizations developing AI model evaluations, addressing the limited evaluation ecosystem. The initiative prioritizes AI Safety Level assessments, advanced capability metrics, and evaluation infrastructure development.</p>
<p>Jul 1, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="june-2024​" tabindex="-1"><a class="header-anchor" href="#june-2024​"><span><strong>June 2024</strong><a href="#june-2024" title="Direct link to june-2024">​</a></span></a></h2>
<h3 id="expanding-access-to-claude-for-government​" tabindex="-1"><a class="header-anchor" href="#expanding-access-to-claude-for-government​"><span><a href="https://www.anthropic.com/news/expanding-access-to-claude-for-government" target="_blank" rel="noopener noreferrer">Expanding access to Claude for government</a><a href="#expanding-access-to-claude-for-government" title="Direct link to expanding-access-to-claude-for-government">​</a></span></a></h3>
<p>Anthropic expanded Claude access to government users on <code v-pre>June 26, 2024</code>, making <code v-pre>Claude 3 Haiku</code> and <code v-pre>Sonnet</code> available through <code v-pre>AWS Marketplace</code> for the <code v-pre>US Intelligence Community</code> and <code v-pre>AWS GovCloud</code>. The expansion includes carefully crafted contractual exceptions for legally authorized foreign intelligence analysis while maintaining restrictions on disinformation, weapons design, and malicious cyber operations.</p>
<p>Jun 26, 2024 | Category: Announcements</p>
<hr>
<h3 id="collaborate-with-claude-on-projects​" tabindex="-1"><a class="header-anchor" href="#collaborate-with-claude-on-projects​"><span><a href="https://www.anthropic.com/news/projects" target="_blank" rel="noopener noreferrer">Collaborate with Claude on Projects</a><a href="#collaborate-with-claude-on-projects" title="Direct link to collaborate-with-claude-on-projects">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Projects</code> on <code v-pre>Claude.ai</code> for <code v-pre>Pro</code> and <code v-pre>Team</code> users on <code v-pre>June 25, 2024</code>, enabling organized collaboration with curated knowledge sets and shared conversations. Projects include a <code v-pre>200K context window</code> for documents and code, custom instructions for tailored responses, and team sharing capabilities.</p>
<p>Jun 25, 2024 | Category: Product</p>
<hr>
<h3 id="claude-3-5-sonnet​" tabindex="-1"><a class="header-anchor" href="#claude-3-5-sonnet​"><span><a href="https://www.anthropic.com/news/claude-3-5-sonnet" target="_blank" rel="noopener noreferrer">Claude 3.5 Sonnet</a><a href="#claude-35-sonnet" title="Direct link to claude-35-sonnet">​</a></span></a></h3>
<p>Anthropic released <code v-pre>Claude 3.5 Sonnet</code> on <code v-pre>June 21, 2024</code>, setting new industry benchmarks while operating at <code v-pre>twice the speed</code> of <code v-pre>Claude 3 Opus</code>. The model excels in graduate-level reasoning, coding proficiency (solving <code v-pre>64%</code> of problems in internal evaluations), and vision capabilities for chart interpretation and text transcription.</p>
<p>Jun 21, 2024 | Category: Announcements</p>
<hr>
<h3 id="challenges-in-red-teaming-ai-systems​" tabindex="-1"><a class="header-anchor" href="#challenges-in-red-teaming-ai-systems​"><span><a href="https://www.anthropic.com/news/challenges-in-red-teaming-ai-systems" target="_blank" rel="noopener noreferrer">Challenges in red teaming AI systems</a><a href="#challenges-in-red-teaming-ai-systems" title="Direct link to challenges-in-red-teaming-ai-systems">​</a></span></a></h3>
<p>Anthropic published insights on red teaming AI systems on <code v-pre>June 12, 2024</code>, detailing various approaches including expert domain testing, automated red teaming, and multimodal evaluations. The post outlines challenges in standardizing red teaming practices and proposes policy recommendations including funding <code v-pre>NIST</code> for technical standards and supporting independent testing organizations.</p>
<p>Jun 12, 2024 | Category: Policy</p>
<hr>
<h3 id="testing-and-mitigating-elections-related-risks​" tabindex="-1"><a class="header-anchor" href="#testing-and-mitigating-elections-related-risks​"><span><a href="https://www.anthropic.com/news/testing-and-mitigating-elections-related-risks" target="_blank" rel="noopener noreferrer">Testing and mitigating elections-related risks</a><a href="#testing-and-mitigating-elections-related-risks" title="Direct link to testing-and-mitigating-elections-related-risks">​</a></span></a></h3>
<p>Anthropic detailed its approach to testing and mitigating elections-related risks on <code v-pre>June 6, 2024</code>, combining Policy Vulnerability Testing with external experts and automated evaluations. The company implemented multiple mitigations including system prompt updates, model fine-tuning, and policy refinements to improve accuracy and appropriate referrals to authoritative sources.</p>
<p>Jun 6, 2024 | Category: Policy</p>
<hr>
<h3 id="introducing-claude-to-canada​" tabindex="-1"><a class="header-anchor" href="#introducing-claude-to-canada​"><span><a href="https://www.anthropic.com/news/introducing-claude-to-canada" target="_blank" rel="noopener noreferrer">Introducing Claude to Canada</a><a href="#introducing-claude-to-canada" title="Direct link to introducing-claude-to-canada">​</a></span></a></h3>
<p>Anthropic introduced Claude to Canada on <code v-pre>June 5, 2024</code>, making the AI assistant available through Claude.ai, iOS app, API, and Team plan. Canadian users can access Claude for free or subscribe to <code v-pre>Pro</code> for <code v-pre>CA$28/month</code> and <code v-pre>Team</code> for <code v-pre>CA$42/month</code> per user, with access to all Claude 3 models and enhanced usage limits.</p>
<p>Jun 5, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="may-2024​" tabindex="-1"><a class="header-anchor" href="#may-2024​"><span><strong>May 2024</strong><a href="#may-2024" title="Direct link to may-2024">​</a></span></a></h2>
<h3 id="claude-can-now-use-tools​" tabindex="-1"><a class="header-anchor" href="#claude-can-now-use-tools​"><span><a href="https://www.anthropic.com/news/tool-use-ga" target="_blank" rel="noopener noreferrer">Claude can now use tools</a><a href="#claude-can-now-use-tools" title="Direct link to claude-can-now-use-tools">​</a></span></a></h3>
<p>Claude's tool use capabilities became generally available across the entire Claude 3 model family on <code v-pre>May 30, 2024</code>, enabling Claude to interact with external tools and APIs for tasks like data extraction, API calls, and database searches. This feature includes streaming support, forced tool selection, and image compatibility, significantly expanding Claude's practical applications for developers and businesses.</p>
<p>May 30, 2024 | Category: Product</p>
<hr>
<h3 id="jay-kreps-appointed-to-anthropic-s-board-of-directors​" tabindex="-1"><a class="header-anchor" href="#jay-kreps-appointed-to-anthropic-s-board-of-directors​"><span><a href="https://www.anthropic.com/news/jay-kreps-appointed-to-board-of-directors" target="_blank" rel="noopener noreferrer">Jay Kreps appointed to Anthropic's Board of Directors</a><a href="#jay-kreps-appointed-to-anthropics-board-of-directors" title="Direct link to jay-kreps-appointed-to-anthropics-board-of-directors">​</a></span></a></h3>
<p><code v-pre>Jay Kreps</code>, co-founder and CEO of <code v-pre>Confluent</code>, joined Anthropic's Board of Directors on <code v-pre>May 29, 2024</code>, bringing extensive experience in building and scaling tech companies and expertise in data infrastructure. His appointment by the <code v-pre>Long-Term Benefit Trust</code> comes as Anthropic prepares for its next phase of growth, while <code v-pre>Luke Muehlhauser</code> stepped down from the board to focus on his work at <code v-pre>Open Philanthropy</code>.</p>
<p>May 29, 2024 | Category: Announcements</p>
<hr>
<h3 id="golden-gate-claude​" tabindex="-1"><a class="header-anchor" href="#golden-gate-claude​"><span><a href="https://www.anthropic.com/news/golden-gate-claude" target="_blank" rel="noopener noreferrer">Golden Gate Claude</a><a href="#golden-gate-claude" title="Direct link to golden-gate-claude">​</a></span></a></h3>
<p><code v-pre>Golden Gate Claude</code> was a 24-hour research demonstration released on <code v-pre>May 23, 2024</code>, showcasing Anthropic's breakthrough in AI interpretability by artificially amplifying Claude's Golden Gate Bridge feature to make it obsessively reference the bridge in all responses. This demonstrated the ability to surgically modify specific neural pathways in AI models, representing a significant advance in understanding and potentially controlling AI behavior for safety purposes.</p>
<p>May 23, 2024 | Category: Product</p>
<hr>
<h3 id="krishna-rao-joins-anthropic-as-chief-financial-officer​" tabindex="-1"><a class="header-anchor" href="#krishna-rao-joins-anthropic-as-chief-financial-officer​"><span><a href="https://www.anthropic.com/news/krishna-rao-joins-anthropic" target="_blank" rel="noopener noreferrer">Krishna Rao joins Anthropic as Chief Financial Officer</a><a href="#krishna-rao-joins-anthropic-as-chief-financial-officer" title="Direct link to krishna-rao-joins-anthropic-as-chief-financial-officer">​</a></span></a></h3>
<p><code v-pre>Krishna Rao</code> joined Anthropic as Chief Financial Officer on <code v-pre>May 21, 2024</code>, bringing nearly <code v-pre>20 years</code> of strategic finance experience from companies like <code v-pre>Fanatics Commerce</code>, <code v-pre>Cedar</code>, and <code v-pre>Airbnb</code> where he helped navigate the pandemic and IPO. His expertise in financial strategy, capital allocation, and scaling high-growth organizations will support Anthropic's enterprise momentum and international expansion plans.</p>
<p>May 21, 2024 | Category: Announcements</p>
<hr>
<h3 id="generate-better-prompts-in-the-developer-console​" tabindex="-1"><a class="header-anchor" href="#generate-better-prompts-in-the-developer-console​"><span><a href="https://www.anthropic.com/news/prompt-generator" target="_blank" rel="noopener noreferrer">Generate better prompts in the developer console</a><a href="#generate-better-prompts-in-the-developer-console" title="Direct link to generate-better-prompts-in-the-developer-console">​</a></span></a></h3>
<p>Anthropic launched a prompt generator feature in the developer console on <code v-pre>May 20, 2024</code>, that automatically creates production-ready prompt templates using best practices like chain-of-thought reasoning and role setting. The tool helps both new and experienced prompt engineers by generating effective, precise prompts based on task descriptions, significantly reducing development time and improving output quality.</p>
<p>May 20, 2024 | Category: Product</p>
<hr>
<h3 id="reflections-on-our-responsible-scaling-policy​" tabindex="-1"><a class="header-anchor" href="#reflections-on-our-responsible-scaling-policy​"><span><a href="https://www.anthropic.com/news/reflections-on-our-responsible-scaling-policy" target="_blank" rel="noopener noreferrer">Reflections on our Responsible Scaling Policy</a><a href="#reflections-on-our-responsible-scaling-policy" title="Direct link to reflections-on-our-responsible-scaling-policy">​</a></span></a></h3>
<p>Anthropic published reflections on implementing their Responsible Scaling Policy on <code v-pre>May 20, 2024</code>, outlining five key commitments including establishing <code v-pre>Red Line Capabilities</code>, conducting frontier risk evaluations, and developing <code v-pre>ASL-3</code> safety standards. The post detailed lessons learned from operationalizing the policy, including challenges in threat modeling, evaluation methodologies, and the need for significant organizational investment in safety measures.</p>
<p>May 20, 2024 | Category: Policy</p>
<hr>
<h3 id="mike-krieger-joins-anthropic-as-chief-product-officer​" tabindex="-1"><a class="header-anchor" href="#mike-krieger-joins-anthropic-as-chief-product-officer​"><span><a href="https://www.anthropic.com/news/mike-krieger-joins-anthropic" target="_blank" rel="noopener noreferrer">Mike Krieger joins Anthropic as Chief Product Officer</a><a href="#mike-krieger-joins-anthropic-as-chief-product-officer" title="Direct link to mike-krieger-joins-anthropic-as-chief-product-officer">​</a></span></a></h3>
<p><code v-pre>Mike Krieger</code>, co-founder and former CTO of <code v-pre>Instagram</code>, joined Anthropic as Chief Product Officer on <code v-pre>May 15, 2024</code>, bringing experience scaling platforms to over a billion users and building <code v-pre>Artifact</code>, a personalized news app. He will oversee product engineering, management, and design efforts as Anthropic expands its enterprise applications and brings Claude to a wider audience.</p>
<p>May 15, 2024 | Category: Announcements</p>
<hr>
<h3 id="claude-is-now-available-in-europe​" tabindex="-1"><a class="header-anchor" href="#claude-is-now-available-in-europe​"><span><a href="https://www.anthropic.com/news/claude-europe" target="_blank" rel="noopener noreferrer">Claude is now available in Europe</a><a href="#claude-is-now-available-in-europe" title="Direct link to claude-is-now-available-in-europe">​</a></span></a></h3>
<p>Claude became available across Europe on <code v-pre>May 14, 2024</code>, including Claude.ai, the iOS app, and the Team plan, following the earlier European launch of the Claude API. The expansion provides Europeans access to Claude's strong multilingual capabilities in French, German, Spanish, and Italian, with <code v-pre>Claude Pro</code> available for <code v-pre>€18 + VAT per month</code> and <code v-pre>Team</code> plan for <code v-pre>€28 + VAT per user per month</code>.</p>
<p>May 14, 2024 | Category: Announcements</p>
<hr>
<h3 id="updating-our-usage-policy​" tabindex="-1"><a class="header-anchor" href="#updating-our-usage-policy​"><span><a href="https://www.anthropic.com/news/updating-our-usage-policy" target="_blank" rel="noopener noreferrer">Updating our Usage Policy</a><a href="#updating-our-usage-policy" title="Direct link to updating-our-usage-policy">​</a></span></a></h3>
<p>Anthropic updated its Usage Policy (formerly Acceptable Use Policy) on <code v-pre>May 10, 2024</code>, with changes taking effect <code v-pre>June 6, 2024</code>, streamlining guidelines into <code v-pre>Universal Usage Standards</code> and clarifying restrictions on election interference and misinformation. The update also added requirements for high-risk use cases like healthcare decisions, expanded access for minors through organizations with safety measures, and strengthened privacy protections against biometric analysis and government censorship.</p>
<p>May 10, 2024 | Category: Announcements</p>
<hr>
<h3 id="introducing-the-claude-team-plan-and-ios-app​" tabindex="-1"><a class="header-anchor" href="#introducing-the-claude-team-plan-and-ios-app​"><span><a href="https://www.anthropic.com/news/team-plan-and-ios" target="_blank" rel="noopener noreferrer">Introducing the Claude Team plan and iOS app</a><a href="#introducing-the-claude-team-plan-and-ios-app" title="Direct link to introducing-the-claude-team-plan-and-ios-app">​</a></span></a></h3>
<p>Anthropic launched the Claude <code v-pre>Team</code> plan (<code v-pre>$30 per user per month</code>, minimum <code v-pre>5 seats</code>) and <code v-pre>iOS app</code> on <code v-pre>May 1, 2024</code>, providing teams with increased usage, access to the full Claude 3 model family, and administrative tools. The free <code v-pre>iOS app</code> offers seamless syncing with web chats, vision capabilities for photo analysis, and mobile access to Claude's frontier intelligence capabilities.</p>
<p>May 1, 2024 | Category: Product</p>
<hr>
<hr>
<h2 id="april-2024​" tabindex="-1"><a class="header-anchor" href="#april-2024​"><span><strong>April 2024</strong><a href="#april-2024" title="Direct link to april-2024">​</a></span></a></h2>
<h3 id="aligning-on-child-safety-principles​" tabindex="-1"><a class="header-anchor" href="#aligning-on-child-safety-principles​"><span><a href="https://www.anthropic.com/news/child-safety-principles" target="_blank" rel="noopener noreferrer">Aligning on child safety principles</a><a href="#aligning-on-child-safety-principles" title="Direct link to aligning-on-child-safety-principles">​</a></span></a></h3>
<p>Anthropic committed to child safety principles on <code v-pre>April 23, 2024</code>, as part of a <code v-pre>Safety by Design</code> initiative led by <code v-pre>Thorn</code> and <code v-pre>All Tech Is Human</code> to prevent AI-generated child sexual abuse material (<code v-pre>AIG-CSAM</code>). The commitment includes specific measures across development, deployment, and maintenance phases, such as responsibly sourcing training data, detecting abusive content, and reporting violations to <code v-pre>NCMEC</code>.</p>
<p>Apr 23, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="march-2024​" tabindex="-1"><a class="header-anchor" href="#march-2024​"><span><strong>March 2024</strong><a href="#march-2024" title="Direct link to march-2024">​</a></span></a></h2>
<h3 id="third-party-testing-as-a-key-ingredient-of-ai-policy​" tabindex="-1"><a class="header-anchor" href="#third-party-testing-as-a-key-ingredient-of-ai-policy​"><span><a href="https://www.anthropic.com/news/third-party-testing" target="_blank" rel="noopener noreferrer">Third-party testing as a key ingredient of AI policy</a><a href="#third-party-testing-as-a-key-ingredient-of-ai-policy" title="Direct link to third-party-testing-as-a-key-ingredient-of-ai-policy">​</a></span></a></h3>
<p>Anthropic published a policy position on <code v-pre>March 25, 2024</code>, advocating for third-party testing as essential for AI policy, arguing that frontier AI systems need independent oversight to validate safety claims and prevent misuse. The company outlined how such testing regimes should work, including automated initial screening followed by expert human evaluation, and emphasized the need for government funding of testing infrastructure and evaluation capabilities.</p>
<p>Mar 25, 2024 | Category: Policy</p>
<hr>
<h3 id="anthropic-aws-and-accenture-team-up-to-build-trusted-solutions-for-enterprises​" tabindex="-1"><a class="header-anchor" href="#anthropic-aws-and-accenture-team-up-to-build-trusted-solutions-for-enterprises​"><span><a href="https://www.anthropic.com/news/accenture-aws-anthropic" target="_blank" rel="noopener noreferrer">Anthropic, AWS, and Accenture team up to build trusted solutions for enterprises</a><a href="#anthropic-aws-and-accenture-team-up-to-build-trusted-solutions-for-enterprises" title="Direct link to anthropic-aws-and-accenture-team-up-to-build-trusted-solutions-for-enterprises">​</a></span></a></h3>
<p>Anthropic announced a collaboration with <code v-pre>AWS</code> and <code v-pre>Accenture</code> to help enterprises deploy generative AI solutions responsibly, particularly in regulated sectors. Over <code v-pre>1,400</code> Accenture engineers will be trained as specialists in using Anthropic's models on AWS, providing end-to-end support from concept to production while keeping customer data private and secure.</p>
<p>Mar 20, 2024 | Category: Announcements</p>
<hr>
<h3 id="claude-3-models-on-vertex-ai​" tabindex="-1"><a class="header-anchor" href="#claude-3-models-on-vertex-ai​"><span><a href="https://www.anthropic.com/news/google-vertex-general-availability" target="_blank" rel="noopener noreferrer">Claude 3 models on Vertex AI</a><a href="#claude-3-models-on-vertex-ai" title="Direct link to claude-3-models-on-vertex-ai">​</a></span></a></h3>
<p><code v-pre>Claude 3 Haiku</code> and <code v-pre>Claude 3 Sonnet</code> became generally available on <code v-pre>Google Cloud's Vertex AI</code> platform, enabling enterprises to use Anthropic's state-of-the-art models with Google Cloud's infrastructure and tools. This collaboration allows businesses to keep their data within their existing cloud environment while simplifying data governance and reducing operational costs.</p>
<p>Mar 19, 2024 | Category: Announcements</p>
<hr>
<h3 id="claude-3-haiku-our-fastest-model-yet​" tabindex="-1"><a class="header-anchor" href="#claude-3-haiku-our-fastest-model-yet​"><span><a href="https://www.anthropic.com/news/claude-3-haiku" target="_blank" rel="noopener noreferrer">Claude 3 Haiku: our fastest model yet</a><a href="#claude-3-haiku-our-fastest-model-yet" title="Direct link to claude-3-haiku-our-fastest-model-yet">​</a></span></a></h3>
<p>Anthropic released <code v-pre>Claude 3 Haiku</code>, the fastest and most affordable model in its intelligence class, processing <code v-pre>21K tokens per second</code> and featuring strong vision capabilities. <code v-pre>Haiku</code> is <code v-pre>three times faster</code> than its peers for most workloads and costs significantly less, enabling businesses to analyze large volumes of documents like quarterly filings or legal cases at <code v-pre>half the cost</code> of other models in its performance tier.</p>
<p>Mar 13, 2024 | Category: Announcements</p>
<hr>
<h3 id="introducing-the-next-generation-of-claude​" tabindex="-1"><a class="header-anchor" href="#introducing-the-next-generation-of-claude​"><span><a href="https://www.anthropic.com/news/claude-3-family" target="_blank" rel="noopener noreferrer">Introducing the next generation of Claude</a><a href="#introducing-the-next-generation-of-claude" title="Direct link to introducing-the-next-generation-of-claude">​</a></span></a></h3>
<p>Anthropic introduced the <code v-pre>Claude 3</code> model family, setting new industry benchmarks with three models: <code v-pre>Haiku</code>, <code v-pre>Sonnet</code>, and <code v-pre>Opus</code>, each offering different balances of intelligence, speed, and cost. <code v-pre>Claude 3 Opus</code> outperforms peers on most evaluation benchmarks and exhibits near-human comprehension, while all models feature sophisticated vision capabilities, <code v-pre>200K context windows</code>, improved accuracy with <code v-pre>2x fewer hallucinations</code>, and significantly fewer unnecessary refusals.</p>
<p>Mar 4, 2024 | Category: Announcements</p>
<hr>
<hr>
<h2 id="february-2024​" tabindex="-1"><a class="header-anchor" href="#february-2024​"><span><strong>February 2024</strong><a href="#february-2024" title="Direct link to february-2024">​</a></span></a></h2>
<h3 id="prompt-engineering-for-business-performance​" tabindex="-1"><a class="header-anchor" href="#prompt-engineering-for-business-performance​"><span><a href="https://www.anthropic.com/news/prompt-engineering-for-business-performance" target="_blank" rel="noopener noreferrer">Prompt engineering for business performance</a><a href="#prompt-engineering-for-business-performance" title="Direct link to prompt-engineering-for-business-performance">​</a></span></a></h3>
<p>Anthropic published guidance on prompt engineering for business performance, emphasizing how effective prompts improve Claude's accuracy, consistency, and cost-effectiveness while reducing hallucination rates. The article shares three key techniques: <code v-pre>step-by-step reasoning</code>, <code v-pre>few-shot prompting</code> with examples, and <code v-pre>prompt chaining</code> for complex tasks.</p>
<p>Feb 29, 2024 | Category: Product</p>
<hr>
<h3 id="preparing-for-global-elections-in-2024​" tabindex="-1"><a class="header-anchor" href="#preparing-for-global-elections-in-2024​"><span><a href="https://www.anthropic.com/news/preparing-for-global-elections-in-2024" target="_blank" rel="noopener noreferrer">Preparing for global elections in 2024</a><a href="#preparing-for-global-elections-in-2024" title="Direct link to preparing-for-global-elections-in-2024">​</a></span></a></h3>
<p>Anthropic outlined their preparation for global elections in <code v-pre>2024</code>, implementing policies that prohibit using Claude for political campaigning and lobbying, while conducting targeted red-teaming to test for election-related misuse. The company developed automated systems to detect misinformation and influence operations, and introduced a redirect system for US users asking voting questions to send them to authoritative sources like <code v-pre>TurboVote</code>.</p>
<p>Feb 16, 2024 | Category: Policy</p>
<hr>
<hr>
<h2 id="december-2023​" tabindex="-1"><a class="header-anchor" href="#december-2023​"><span><strong>December 2023</strong><a href="#december-2023" title="Direct link to december-2023">​</a></span></a></h2>
<h3 id="expanded-legal-protections-and-improvements-to-our-api​" tabindex="-1"><a class="header-anchor" href="#expanded-legal-protections-and-improvements-to-our-api​"><span><a href="https://www.anthropic.com/news/expanded-legal-protections-api-improvements" target="_blank" rel="noopener noreferrer">Expanded legal protections and improvements to our API</a><a href="#expanded-legal-protections-and-improvements-to-our-api" title="Direct link to expanded-legal-protections-and-improvements-to-our-api">​</a></span></a></h3>
<p>Anthropic introduced new Commercial Terms of Service with expanded copyright indemnity protection and launched the beta <code v-pre>Messages API</code> for improved developer experience. The updated terms allow customers to retain ownership of outputs and provide legal protection against copyright infringement claims, with Anthropic defending customers and paying for settlements or judgments.</p>
<p>Dec 19, 2023 | Category: Announcements</p>
<hr>
<h3 id="long-context-prompting-for-claude-2-1​" tabindex="-1"><a class="header-anchor" href="#long-context-prompting-for-claude-2-1​"><span><a href="https://www.anthropic.com/news/claude-2-1-prompting" target="_blank" rel="noopener noreferrer">Long context prompting for Claude 2.1</a><a href="#long-context-prompting-for-claude-21" title="Direct link to long-context-prompting-for-claude-21">​</a></span></a></h3>
<p>Anthropic published insights on long context prompting for <code v-pre>Claude 2.1</code>, revealing that while the model has excellent recall across its <code v-pre>200K token</code> context window, it can be reluctant to answer questions based on individual sentences that appear out of place in documents. Adding the simple prompt <code v-pre>Here is the most relevant sentence in the context:</code> improved <code v-pre>Claude 2.1</code>'s performance from <code v-pre>27%</code> to <code v-pre>98%</code> on retrieval tasks.</p>
<p>Dec 6, 2023 | Category: Product</p>
<hr>
<hr>
<h2 id="november-2023​" tabindex="-1"><a class="header-anchor" href="#november-2023​"><span><strong>November 2023</strong><a href="#november-2023" title="Direct link to november-2023">​</a></span></a></h2>
<h3 id="introducing-claude-2-1​" tabindex="-1"><a class="header-anchor" href="#introducing-claude-2-1​"><span><a href="https://www.anthropic.com/news/claude-2-1" target="_blank" rel="noopener noreferrer">Introducing Claude 2.1</a><a href="#introducing-claude-21" title="Direct link to introducing-claude-21">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Claude 2.1</code> with significant improvements including an industry-leading <code v-pre>200K token</code> context window (equivalent to <code v-pre>500 pages</code>), a <code v-pre>2x decrease</code> in hallucination rates, and new features like system prompts and beta tool use functionality. The model demonstrates <code v-pre>30%</code> fewer incorrect answers and <code v-pre>3-4x</code> lower rates of mistakenly concluding documents support particular claims.</p>
<p>Nov 21, 2023 | Category: Product</p>
<hr>
<h3 id="thoughts-on-the-us-executive-order-g7-code-of-conduct-and-bletchley-park-summit​" tabindex="-1"><a class="header-anchor" href="#thoughts-on-the-us-executive-order-g7-code-of-conduct-and-bletchley-park-summit​"><span><a href="https://www.anthropic.com/news/policy-recap-q4-2023" target="_blank" rel="noopener noreferrer">Thoughts on the US Executive Order, G7 Code of Conduct, and Bletchley Park Summit</a><a href="#thoughts-on-the-us-executive-order-g7-code-of-conduct-and-bletchley-park-summit" title="Direct link to thoughts-on-the-us-executive-order-g7-code-of-conduct-and-bletchley-park-summit">​</a></span></a></h3>
<p>Anthropic shared their perspective on three major AI policy developments: the <code v-pre>US Executive Order on AI</code>, the <code v-pre>G7 International Code of Conduct</code>, and the <code v-pre>UK's Bletchley Park AI Safety Summit</code>. The company praised the Executive Order's focus on <code v-pre>NIST</code> and the <code v-pre>National AI Research Resource</code>, supported the <code v-pre>G7 Code of Conduct</code> as setting important baselines for frontier AI companies, and welcomed the <code v-pre>Bletchley Declaration</code>'s international cooperation.</p>
<p>Nov 5, 2023 | Category: Policy</p>
<hr>
<h3 id="dario-amodei-s-prepared-remarks-from-the-ai-safety-summit-on-anthropic-s-responsible-scaling-policy​" tabindex="-1"><a class="header-anchor" href="#dario-amodei-s-prepared-remarks-from-the-ai-safety-summit-on-anthropic-s-responsible-scaling-policy​"><span><a href="https://www.anthropic.com/news/uk-ai-safety-summit" target="_blank" rel="noopener noreferrer">Dario Amodei’s prepared remarks from the AI Safety Summit on Anthropic’s Responsible Scaling Policy</a><a href="#dario-amodeis-prepared-remarks-from-the-ai-safety-summit-on-anthropics-responsible-scaling-policy" title="Direct link to dario-amodeis-prepared-remarks-from-the-ai-safety-summit-on-anthropics-responsible-scaling-policy">​</a></span></a></h3>
<p><code v-pre>Dario Amodei</code> presented Anthropic's <code v-pre>Responsible Scaling Policy (RSP)</code> at the <code v-pre>UK AI Safety Summit</code>, outlining their <code v-pre>AI Safety Levels (ASL)</code> system modeled after biological safety protocols. The RSP includes if-then commitments where dangerous AI capabilities trigger specific safety requirements, with <code v-pre>ASL-3</code> requiring strong security measures and perfect safety performance, and <code v-pre>ASL-4</code> addressing autonomous AI risks.</p>
<p>Nov 1, 2023 | Category: Policy</p>
<hr>
<hr>
<h2 id="september-2023​" tabindex="-1"><a class="header-anchor" href="#september-2023​"><span><strong>September 2023</strong><a href="#september-2023" title="Direct link to september-2023">​</a></span></a></h2>
<h3 id="claude-on-amazon-bedrock-now-available-to-every-aws-customer​" tabindex="-1"><a class="header-anchor" href="#claude-on-amazon-bedrock-now-available-to-every-aws-customer​"><span><a href="https://www.anthropic.com/news/amazon-bedrock-general-availability" target="_blank" rel="noopener noreferrer">Claude on Amazon Bedrock now available to every AWS customer</a><a href="#claude-on-amazon-bedrock-now-available-to-every-aws-customer" title="Direct link to claude-on-amazon-bedrock-now-available-to-every-aws-customer">​</a></span></a></h3>
<p>Claude became generally available on <code v-pre>Amazon Bedrock</code> for all AWS customers, providing secure cloud access to foundation models and enabling the development of generative AI applications. The announcement highlighted upcoming <code v-pre>Agents for Amazon Bedrock</code> functionality, which allows Claude to orchestrate API calls and perform complex multi-step tasks.</p>
<p>Sep 28, 2023 | Category: Announcements</p>
<hr>
<h3 id="expanding-access-to-safer-ai-with-amazon​" tabindex="-1"><a class="header-anchor" href="#expanding-access-to-safer-ai-with-amazon​"><span><a href="https://www.anthropic.com/news/anthropic-amazon" target="_blank" rel="noopener noreferrer">Expanding access to safer AI with Amazon</a><a href="#expanding-access-to-safer-ai-with-amazon" title="Direct link to expanding-access-to-safer-ai-with-amazon">​</a></span></a></h3>
<p>Anthropic announced a strategic partnership with <code v-pre>Amazon</code> involving up to <code v-pre>$4 billion</code> in investment, making <code v-pre>AWS</code> their primary cloud provider and expanding <code v-pre>Claude 2</code> availability on <code v-pre>Amazon Bedrock</code>. The collaboration includes access to <code v-pre>AWS Trainium</code> and <code v-pre>Inferentia</code> chips for model training, secure model customization capabilities for enterprises, and integration across Amazon's businesses while maintaining Anthropic's governance structure through the <code v-pre>Long-Term Benefit Trust</code>.</p>
<p>Sep 25, 2023 | Category: Announcements</p>
<hr>
<h3 id="prompt-engineering-for-claude-s-long-context-window​" tabindex="-1"><a class="header-anchor" href="#prompt-engineering-for-claude-s-long-context-window​"><span><a href="https://www.anthropic.com/news/prompting-long-context" target="_blank" rel="noopener noreferrer">Prompt engineering for Claude's long context window</a><a href="#prompt-engineering-for-claudes-long-context-window" title="Direct link to prompt-engineering-for-claudes-long-context-window">​</a></span></a></h3>
<p>Anthropic published research on prompt engineering techniques for Claude's <code v-pre>100,000 token</code> context window, demonstrating how to maximize information recall from long documents. The study found that using reference quote extraction and providing contextual examples significantly improved Claude's performance on multiple choice questions, with <code v-pre>Claude Instant 1.2</code> showing substantial gains when these techniques were applied to documents containing <code v-pre>70K-95K tokens</code>.</p>
<p>Sep 23, 2023 | Category: Product</p>
<hr>
<h3 id="anthropic-s-responsible-scaling-policy​" tabindex="-1"><a class="header-anchor" href="#anthropic-s-responsible-scaling-policy​"><span><a href="https://www.anthropic.com/news/anthropics-responsible-scaling-policy" target="_blank" rel="noopener noreferrer">Anthropic's Responsible Scaling Policy</a><a href="#anthropics-responsible-scaling-policy" title="Direct link to anthropics-responsible-scaling-policy">​</a></span></a></h3>
<p>Anthropic released their <code v-pre>Responsible Scaling Policy (RSP)</code>, establishing <code v-pre>AI Safety Levels (ASL)</code> framework modeled after biosafety standards to manage catastrophic risks from increasingly capable AI systems. The policy defines safety requirements for different capability levels, with <code v-pre>ASL-2</code> covering current models like <code v-pre>Claude</code>, <code v-pre>ASL-3</code> requiring enhanced security and red-teaming standards, and creates a framework that incentivizes solving safety problems to unlock further AI scaling.</p>
<p>Sep 19, 2023 | Category: Announcements</p>
<hr>
<h3 id="the-long-term-benefit-trust​" tabindex="-1"><a class="header-anchor" href="#the-long-term-benefit-trust​"><span><a href="https://www.anthropic.com/news/the-long-term-benefit-trust" target="_blank" rel="noopener noreferrer">The Long-Term Benefit Trust</a><a href="#the-long-term-benefit-trust" title="Direct link to the-long-term-benefit-trust">​</a></span></a></h3>
<p>Anthropic introduced the <code v-pre>Long-Term Benefit Trust (LTBT)</code>, a governance structure featuring <code v-pre>five</code> independent trustees who will gradually gain authority to elect a majority of Anthropic's board within <code v-pre>four years</code>. This experimental corporate governance model aims to balance stockholder interests with public benefit by ensuring board accountability to trustees with expertise in AI safety, national security, and public policy, while maintaining the company's mission of developing AI for humanity's long-term benefit.</p>
<p>Sep 19, 2023 | Category: Announcements</p>
<hr>
<h3 id="anthropic-partners-with-bcg​" tabindex="-1"><a class="header-anchor" href="#anthropic-partners-with-bcg​"><span><a href="https://www.anthropic.com/news/anthropic-bcg" target="_blank" rel="noopener noreferrer">Anthropic partners with BCG</a><a href="#anthropic-partners-with-bcg" title="Direct link to anthropic-partners-with-bcg">​</a></span></a></h3>
<p>Anthropic partnered with <code v-pre>Boston Consulting Group (BCG)</code> to bring Claude to enterprise customers worldwide, focusing on responsible AI deployment across use cases like knowledge management, market research, and business analysis. The collaboration leverages BCG's consulting expertise to help organizations strategically implement AI while maintaining ethical standards, with BCG also using Claude internally for research synthesis and client insights.</p>
<p>Sep 14, 2023 | Category: Announcements</p>
<hr>
<h3 id="introducing-claude-pro​" tabindex="-1"><a class="header-anchor" href="#introducing-claude-pro​"><span><a href="https://www.anthropic.com/news/claude-pro" target="_blank" rel="noopener noreferrer">Introducing Claude Pro</a><a href="#introducing-claude-pro" title="Direct link to introducing-claude-pro">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Claude Pro</code>, a paid subscription plan offering <code v-pre>5x</code> more usage of <code v-pre>Claude 2</code> for <code v-pre>$20/month</code> in the <code v-pre>US</code> and <code v-pre>£18/month</code> in the <code v-pre>UK</code>. The service provides priority access during high-traffic periods, early access to new features, and significantly expanded message limits, enabling users to handle more complex tasks like research paper summarization, contract analysis, and extended coding projects.</p>
<p>Sep 7, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="august-2023​" tabindex="-1"><a class="header-anchor" href="#august-2023​"><span><strong>August 2023</strong><a href="#august-2023" title="Direct link to august-2023">​</a></span></a></h2>
<h3 id="claude-2-on-amazon-bedrock​" tabindex="-1"><a class="header-anchor" href="#claude-2-on-amazon-bedrock​"><span><a href="https://www.anthropic.com/news/claude-2-amazon-bedrock" target="_blank" rel="noopener noreferrer">Claude 2 on Amazon Bedrock</a><a href="#claude-2-on-amazon-bedrock" title="Direct link to claude-2-on-amazon-bedrock">​</a></span></a></h3>
<p><code v-pre>Claude 2</code> became available on <code v-pre>Amazon Bedrock</code>, Amazon's fully managed foundation model service, enabling enterprises to build generative AI applications with enhanced security and scalability. Early adopters include <code v-pre>LexisNexis</code> using <code v-pre>Claude 2</code> for legal AI capabilities, <code v-pre>Lonely Planet</code> for travel planning with <code v-pre>80%</code> cost reduction in itinerary generation, and <code v-pre>Ricoh USA</code> for AI-driven operations while maintaining <code v-pre>HIPAA</code> and <code v-pre>SOC II</code> compliance.</p>
<p>Aug 23, 2023 | Category: Product</p>
<hr>
<h3 id="skt-partnership-announcement​" tabindex="-1"><a class="header-anchor" href="#skt-partnership-announcement​"><span><a href="https://www.anthropic.com/news/skt-partnership-announcement" target="_blank" rel="noopener noreferrer">SKT Partnership Announcement</a><a href="#skt-partnership-announcement" title="Direct link to skt-partnership-announcement">​</a></span></a></h3>
<p><code v-pre>SK Telecom (SKT)</code> became both a commercial partner and strategic investor in Anthropic with an additional <code v-pre>$100 million</code> investment, collaborating to develop a fine-tuned large language model optimized for telecommunications applications. The partnership will create a multilingual model supporting <code v-pre>Korean</code>, <code v-pre>English</code>, <code v-pre>Japanese</code>, and <code v-pre>Spanish</code> for telco use cases including customer service, marketing, and sales, leveraging SKT's domain expertise to customize Claude for the telecommunications industry.</p>
<p>Aug 15, 2023 | Category: Announcements</p>
<hr>
<h3 id="releasing-claude-instant-1-2​" tabindex="-1"><a class="header-anchor" href="#releasing-claude-instant-1-2​"><span><a href="https://www.anthropic.com/news/releasing-claude-instant-1-2" target="_blank" rel="noopener noreferrer">Releasing Claude Instant 1.2</a><a href="#releasing-claude-instant-12" title="Direct link to releasing-claude-instant-12">​</a></span></a></h3>
<p>Anthropic released <code v-pre>Claude Instant 1.2</code>, an updated version of their faster, lower-cost model that incorporates improvements from <code v-pre>Claude 2</code> while maintaining speed and affordability. The new version shows significant gains in math (<code v-pre>86.7%</code> vs <code v-pre>80.9%</code> on <code v-pre>GSM8K</code>), coding (<code v-pre>58.7%</code> vs <code v-pre>52.8%</code> on <code v-pre>Codex</code>), reasoning capabilities, and safety with reduced hallucinations and better resistance to jailbreaks, while generating longer and more structured responses.</p>
<p>Aug 9, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="july-2023​" tabindex="-1"><a class="header-anchor" href="#july-2023​"><span><strong>July 2023</strong><a href="#july-2023" title="Direct link to july-2023">​</a></span></a></h2>
<h3 id="frontier-threats-red-teaming-for-ai-safety​" tabindex="-1"><a class="header-anchor" href="#frontier-threats-red-teaming-for-ai-safety​"><span><a href="https://www.anthropic.com/news/frontier-threats-red-teaming-for-ai-safety" target="_blank" rel="noopener noreferrer">Frontier Threats Red Teaming for AI Safety</a><a href="#frontier-threats-red-teaming-for-ai-safety" title="Direct link to frontier-threats-red-teaming-for-ai-safety">​</a></span></a></h3>
<p>Anthropic conducted frontier threats red teaming research focusing on biological risks, spending <code v-pre>150+ hours</code> with biosecurity experts to evaluate Claude's potential for generating harmful biological information. The study found that current frontier models can produce expert-level knowledge that could accelerate bad actors' efforts, with risks potentially materializing in <code v-pre>2-3 years</code>, but also identified effective mitigations including <code v-pre>Constitutional AI</code> training and classifier-based filters that substantially reduce these risks.</p>
<p>Jul 26, 2023 | Category: Announcements</p>
<hr>
<h3 id="frontier-model-security​" tabindex="-1"><a class="header-anchor" href="#frontier-model-security​"><span><a href="https://www.anthropic.com/news/frontier-model-security" target="_blank" rel="noopener noreferrer">Frontier Model Security</a><a href="#frontier-model-security" title="Direct link to frontier-model-security">​</a></span></a></h3>
<p>Anthropic published their approach to frontier model security, recommending <code v-pre>two-party control systems</code> and secure software development practices (<code v-pre>NIST SSDF</code> and <code v-pre>SLSA</code> standards) for protecting advanced AI models. The company advocates treating frontier AI as critical infrastructure requiring enhanced cybersecurity measures, public-private cooperation similar to financial services, and government procurement requirements to ensure industry-wide adoption of robust security practices.</p>
<p>Jul 25, 2023 | Category: Announcements</p>
<hr>
<h3 id="claude-2​" tabindex="-1"><a class="header-anchor" href="#claude-2​"><span><a href="https://www.anthropic.com/news/claude-2" target="_blank" rel="noopener noreferrer">Claude 2</a><a href="#claude-2" title="Direct link to claude-2">​</a></span></a></h3>
<p>Anthropic launched <code v-pre>Claude 2</code>, their most advanced model featuring improved performance across coding (<code v-pre>71.2%</code> on <code v-pre>Codex HumanEval</code>), math (<code v-pre>88.0%</code> on <code v-pre>GSM8k</code>), and reasoning, with a <code v-pre>100,000 token</code> context window enabling processing of entire books or extensive documentation. The model scored <code v-pre>76.5%</code> on the <code v-pre>Bar exam</code> and above the <code v-pre>90th percentile</code> on <code v-pre>GRE</code> reading/writing, while being <code v-pre>2x better</code> at harmless responses, and is available via API and the new <code v-pre>claude.ai</code> chat interface in the <code v-pre>US</code> and <code v-pre>UK</code>.</p>
<p>Jul 11, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="june-2023​" tabindex="-1"><a class="header-anchor" href="#june-2023​"><span><strong>June 2023</strong><a href="#june-2023" title="Direct link to june-2023">​</a></span></a></h2>
<h3 id="charting-a-path-to-ai-accountability​" tabindex="-1"><a class="header-anchor" href="#charting-a-path-to-ai-accountability​"><span><a href="https://www.anthropic.com/news/charting-a-path-to-ai-accountability" target="_blank" rel="noopener noreferrer">Charting a Path to AI Accountability</a><a href="#charting-a-path-to-ai-accountability" title="Direct link to charting-a-path-to-ai-accountability">​</a></span></a></h3>
<p>Anthropic submitted recommendations to the <code v-pre>NTIA</code> on AI accountability, proposing a comprehensive framework for evaluating advanced AI systems. The recommendations include funding better evaluations, creating risk-responsive assessments based on model capabilities, establishing pre-registration for large AI training runs, empowering third-party auditors, mandating external red teaming, advancing interpretability research, and enabling industry collaboration on AI safety through antitrust clarity.</p>
<p>Jun 13, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="may-2023​" tabindex="-1"><a class="header-anchor" href="#may-2023​"><span><strong>May 2023</strong><a href="#may-2023" title="Direct link to may-2023">​</a></span></a></h2>
<h3 id="anthropic-raises-450-million-in-series-c-funding-to-scale-reliable-ai-products​" tabindex="-1"><a class="header-anchor" href="#anthropic-raises-450-million-in-series-c-funding-to-scale-reliable-ai-products​"><span><a href="https://www.anthropic.com/news/anthropic-series-c" target="_blank" rel="noopener noreferrer">Anthropic Raises $450 Million in Series C Funding to Scale Reliable AI Products</a><a href="#anthropic-raises-450-million-in-series-c-funding-to-scale-reliable-ai-products" title="Direct link to anthropic-raises-450-million-in-series-c-funding-to-scale-reliable-ai-products">​</a></span></a></h3>
<p>Anthropic raised <code v-pre>$450 million</code> in <code v-pre>Series C</code> funding led by <code v-pre>Spark Capital</code> with participation from <code v-pre>Google</code>, <code v-pre>Salesforce Ventures</code>, <code v-pre>Sound Ventures</code>, and <code v-pre>Zoom Ventures</code>. The funding will support continued development of Claude and AI safety research, including new features like <code v-pre>100K context windows</code>, while growing their product offerings and supporting businesses deploying Claude responsibly.</p>
<p>May 23, 2023 | Category: Announcements</p>
<hr>
<h3 id="zoom-partnership-and-investment-in-anthropic​" tabindex="-1"><a class="header-anchor" href="#zoom-partnership-and-investment-in-anthropic​"><span><a href="https://www.anthropic.com/news/zoom-partnership-and-investment" target="_blank" rel="noopener noreferrer">Zoom Partnership and Investment in Anthropic</a><a href="#zoom-partnership-and-investment-in-anthropic" title="Direct link to zoom-partnership-and-investment-in-anthropic">​</a></span></a></h3>
<p>Anthropic announced a partnership with <code v-pre>Zoom</code> where Claude will be integrated into Zoom's products, starting with the <code v-pre>Zoom Contact Center</code> portfolio to improve customer experience and agent performance. <code v-pre>Zoom Ventures</code> also made an investment in Anthropic as part of this collaboration, reflecting their shared vision of building customer-centric AI products with trust and security foundations.</p>
<p>May 16, 2023 | Category: Announcements</p>
<hr>
<h3 id="introducing-100k-context-windows​" tabindex="-1"><a class="header-anchor" href="#introducing-100k-context-windows​"><span><a href="https://www.anthropic.com/news/100k-context-windows" target="_blank" rel="noopener noreferrer">Introducing 100K Context Windows</a><a href="#introducing-100k-context-windows" title="Direct link to introducing-100k-context-windows">​</a></span></a></h3>
<p>Anthropic expanded Claude's context window from <code v-pre>9K</code> to <code v-pre>100K tokens</code> (approximately <code v-pre>75,000 words</code>), allowing users to submit hundreds of pages of documents for analysis. This breakthrough enables Claude to digest and analyze massive amounts of text in <code v-pre>under a minute</code>, supporting use cases like financial statement analysis, legal document review, and codebase modification.</p>
<p>May 11, 2023 | Category: Announcements</p>
<hr>
<h3 id="claude-s-constitution​" tabindex="-1"><a class="header-anchor" href="#claude-s-constitution​"><span><a href="https://www.anthropic.com/news/claudes-constitution" target="_blank" rel="noopener noreferrer">Claude’s Constitution</a><a href="#claudes-constitution" title="Direct link to claudes-constitution">​</a></span></a></h3>
<p>Anthropic published details about <code v-pre>Claude's Constitution</code>, explaining their <code v-pre>Constitutional AI</code> approach that uses explicit principles rather than implicit human feedback to guide AI behavior. The constitution draws from sources including the <code v-pre>UN Declaration of Human Rights</code>, platform guidelines, and AI safety research, with principles covering helpfulness, harmlessness, honesty, and respect for human values across different cultural perspectives.</p>
<p>May 9, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="april-2023​" tabindex="-1"><a class="header-anchor" href="#april-2023​"><span><strong>April 2023</strong><a href="#april-2023" title="Direct link to april-2023">​</a></span></a></h2>
<h3 id="partnering-with-scale-to-bring-generative-ai-to-enterprises​" tabindex="-1"><a class="header-anchor" href="#partnering-with-scale-to-bring-generative-ai-to-enterprises​"><span><a href="https://www.anthropic.com/news/partnering-with-scale" target="_blank" rel="noopener noreferrer">Partnering with Scale to Bring Generative AI to Enterprises</a><a href="#partnering-with-scale-to-bring-generative-ai-to-enterprises" title="Direct link to partnering-with-scale-to-bring-generative-ai-to-enterprises">​</a></span></a></h3>
<p>Anthropic partnered with <code v-pre>Scale</code> to bring Claude to enterprise customers through Scale's robust deployment and management platform. The partnership provides enterprise-grade security, expert prompt engineering, model validation services, and data connectors for proprietary sources, enabling businesses to build and deploy generative AI applications with Claude at scale.</p>
<p>Apr 26, 2023 | Category: Announcements</p>
<hr>
<h3 id="an-ai-policy-tool-for-today-ambitiously-invest-in-nist​" tabindex="-1"><a class="header-anchor" href="#an-ai-policy-tool-for-today-ambitiously-invest-in-nist​"><span><a href="https://www.anthropic.com/news/an-ai-policy-tool-for-today-ambitiously-invest-in-nist" target="_blank" rel="noopener noreferrer">An AI Policy Tool for Today: Ambitiously Invest in NIST</a><a href="#an-ai-policy-tool-for-today-ambitiously-invest-in-nist" title="Direct link to an-ai-policy-tool-for-today-ambitiously-invest-in-nist">​</a></span></a></h3>
<p>Anthropic advocated for ambitious federal investment in <code v-pre>NIST</code> to support AI measurement and standards efforts, proposing a <code v-pre>$15 million</code> funding increase. The company argues that NIST's century of measurement expertise makes it the natural choice to develop AI evaluation standards, which are essential prerequisites for effective AI regulation and public trust in AI systems.</p>
<p>Apr 20, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="march-2023​" tabindex="-1"><a class="header-anchor" href="#march-2023​"><span><strong>March 2023</strong><a href="#march-2023" title="Direct link to march-2023">​</a></span></a></h2>
<h3 id="claude-now-in-slack​" tabindex="-1"><a class="header-anchor" href="#claude-now-in-slack​"><span><a href="https://www.anthropic.com/news/claude-now-in-slack" target="_blank" rel="noopener noreferrer">Claude, now in Slack</a><a href="#claude-now-in-slack" title="Direct link to claude-now-in-slack">​</a></span></a></h3>
<p>Anthropic launched the <code v-pre>Claude App for Slack</code> in <code v-pre>beta</code>, allowing teams to use Claude as a virtual teammate for summarizing threads, answering questions, and various productivity tasks. Claude can be accessed through channel mentions or direct messages, with Anthropic emphasizing that it only sees messages where explicitly mentioned and doesn't use this data for model training.</p>
<p>Mar 30, 2023 | Category: Announcements</p>
<hr>
<h3 id="introducing-claude​" tabindex="-1"><a class="header-anchor" href="#introducing-claude​"><span><a href="https://www.anthropic.com/news/introducing-claude" target="_blank" rel="noopener noreferrer">Introducing Claude</a><a href="#introducing-claude" title="Direct link to introducing-claude">​</a></span></a></h3>
<p>Anthropic officially introduced <code v-pre>Claude</code>, their next-generation AI assistant based on <code v-pre>Constitutional AI</code> research, after testing with partners like <code v-pre>Notion</code>, <code v-pre>Quora</code>, and <code v-pre>DuckDuckGo</code>. Claude offers two versions (<code v-pre>Claude</code> and <code v-pre>Claude Instant</code>) and is designed to be helpful, honest, and harmless, with early customers reporting it's less likely to produce harmful outputs and easier to steer than alternatives.</p>
<p>Mar 14, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="february-2023​" tabindex="-1"><a class="header-anchor" href="#february-2023​"><span><strong>February 2023</strong><a href="#february-2023" title="Direct link to february-2023">​</a></span></a></h2>
<h3 id="anthropic-partners-with-google-cloud​" tabindex="-1"><a class="header-anchor" href="#anthropic-partners-with-google-cloud​"><span><a href="https://www.anthropic.com/news/anthropic-partners-with-google-cloud" target="_blank" rel="noopener noreferrer">Anthropic Partners with Google Cloud</a><a href="#anthropic-partners-with-google-cloud" title="Direct link to anthropic-partners-with-google-cloud">​</a></span></a></h3>
<p>Anthropic selected <code v-pre>Google Cloud</code> as its cloud provider to support the next phase of scaling and deploying Claude to larger audiences. The partnership enables Anthropic to leverage Google Cloud's <code v-pre>GPU</code> and <code v-pre>TPU</code> clusters for training, scaling, and deploying AI systems, providing the infrastructure performance needed for their reliable and interpretable AI development goals.</p>
<p>Feb 3, 2023 | Category: Announcements</p>
<hr>
<hr>
<h2 id="april-2022​" tabindex="-1"><a class="header-anchor" href="#april-2022​"><span><strong>April 2022</strong><a href="#april-2022" title="Direct link to april-2022">​</a></span></a></h2>
<h3 id="anthropic-raises-series-b-to-build-steerable-interpretable-robust-ai-systems​" tabindex="-1"><a class="header-anchor" href="#anthropic-raises-series-b-to-build-steerable-interpretable-robust-ai-systems​"><span><a href="https://www.anthropic.com/news/anthropic-raises-series-b-to-build-safe-reliable-ai" target="_blank" rel="noopener noreferrer">Anthropic Raises Series B to build steerable, interpretable, robust AI systems</a><a href="#anthropic-raises-series-b-to-build-steerable-interpretable-robust-ai-systems" title="Direct link to anthropic-raises-series-b-to-build-steerable-interpretable-robust-ai-systems">​</a></span></a></h3>
<p>Anthropic raised <code v-pre>$580 million</code> in <code v-pre>Series B</code> funding led by <code v-pre>Sam Bankman-Fried</code> to build large-scale experimental infrastructure for exploring AI safety properties. The funding supports research into making AI systems more steerable, interpretable, and robust, building on their previous work in language model interpretability and alignment with human preferences.</p>
<p>Apr 29, 2022 | Category: Announcements</p>
<hr>
<hr>
<h2 id="may-2021​" tabindex="-1"><a class="header-anchor" href="#may-2021​"><span><strong>May 2021</strong><a href="#may-2021" title="Direct link to may-2021">​</a></span></a></h2>
<h3 id="anthropic-raises-124-million-to-build-more-reliable-general-ai-systems​" tabindex="-1"><a class="header-anchor" href="#anthropic-raises-124-million-to-build-more-reliable-general-ai-systems​"><span><a href="https://www.anthropic.com/news/anthropic-raises-124-million-to-build-more-reliable-general-ai-systems" target="_blank" rel="noopener noreferrer">Anthropic raises $124 million to build more reliable, general AI systems</a><a href="#anthropic-raises-124-million-to-build-more-reliable-general-ai-systems" title="Direct link to anthropic-raises-124-million-to-build-more-reliable-general-ai-systems">​</a></span></a></h3>
<p>Anthropic raised <code v-pre>$124 million</code> in <code v-pre>Series A</code> funding led by <code v-pre>Jaan Tallinn</code> to support their research roadmap for building reliable and steerable AI systems. The founding team, led by siblings <code v-pre>Dario</code> and <code v-pre>Daniela Amodei</code>, planned to focus on computationally-intensive research to develop large-scale AI systems that are more interpretable, robust, and better integrated with human feedback.</p>
<p>May 28, 2021 | Category: Announcements</p>
<hr>
<hr>
<ul>
<li><a href="#september-2025"><strong>September 2025</strong></a>
<ul>
<li><a href="#claude-can-now-create-and-edit-files">Claude can now create and edit files</a></li>
<li><a href="#anthropic-is-endorsing-sb-53">Anthropic is endorsing SB 53</a></li>
<li><a href="#updating-restrictions-of-sales-to-unsupported-regions">Updating restrictions of sales to unsupported regions</a></li>
<li><a href="#anthropic-raises-13b-series-f-at-183b-post-money-valuation">Anthropic raises $13B Series F at $183B post-money valuation</a></li>
</ul>
</li>
<li><a href="#august-2025"><strong>August 2025</strong></a>
<ul>
<li><a href="#updates-to-consumer-terms-and-privacy-policy">Updates to Consumer Terms and Privacy Policy</a></li>
<li><a href="#introducing-the-anthropic-national-security-and-public-sector-advisory-council">Introducing the Anthropic National Security and Public Sector Advisory Council</a></li>
<li><a href="#detecting-and-countering-misuse-of-ai-august-2025">Detecting and countering misuse of AI: August 2025</a></li>
<li><a href="#claude-code-and-new-admin-controls-for-business-plans">Claude Code and new admin controls for business plans</a></li>
<li><a href="#anthropic-appoints-hidetoshi-tojo-as-head-of-japan-and-announces-hiring-plans">Anthropic appoints Hidetoshi Tojo as Head of Japan and announces hiring plans</a></li>
<li><a href="#automate-security-reviews-with-claude-code">Automate security reviews with Claude Code</a></li>
</ul>
</li>
<li><a href="#july-2025"><strong>July 2025</strong></a>
<ul>
<li><a href="#anthropic-to-sign-the-eu-code-of-practice">Anthropic to sign the EU Code of Practice</a></li>
<li><a href="#paul-smith-to-join-anthropic-as-chief-commercial-officer">Paul Smith to join Anthropic as Chief Commercial Officer</a></li>
<li><a href="#anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations">Anthropic and the Department of Defense to advance responsible AI in defense operations</a></li>
</ul>
</li>
<li><a href="#june-2025"><strong>June 2025</strong></a>
<ul>
<li><a href="#national-security-expert-richard-fontaine-appointed-to-anthropics-long-term-benefit-trust">National security expert Richard Fontaine appointed to Anthropic’s long-term benefit trust</a></li>
</ul>
</li>
<li><a href="#may-2025"><strong>May 2025</strong></a>
<ul>
<li><a href="#reed-hastings-appointed-to-anthropics-board-of-directors">Reed Hastings appointed to Anthropic’s board of directors</a></li>
<li><a href="#new-capabilities-for-building-agents-on-the-anthropic-api">New capabilities for building agents on the Anthropic API</a></li>
</ul>
</li>
<li><a href="#april-2025"><strong>April 2025</strong></a>
<ul>
<li><a href="#claude-takes-research-to-new-places">Claude takes research to new places</a></li>
<li><a href="#anthropic-appoints-guillaume-princen-as-head-of-emea-and-announces-100-new-roles-across-the-region">Anthropic appoints Guillaume Princen as Head of EMEA and announces 100+ new roles across the region</a></li>
<li><a href="#introducing-anthropics-first-developer-conference-code-with-claude">Introducing Anthropic's first developer conference: Code with Claude</a></li>
</ul>
</li>
<li><a href="#march-2025"><strong>March 2025</strong></a>
<ul>
<li><a href="#progress-from-our-frontier-red-team">Progress from our Frontier Red Team</a></li>
</ul>
</li>
<li><a href="#february-2025"><strong>February 2025</strong></a>
<ul>
<li><a href="#anthropic-partners-with-us-national-labs-for-first-1000-scientist-ai-jam">Anthropic partners with U.S. National Labs for first 1,000 Scientist AI Jam</a></li>
<li><a href="#introducing-anthropics-transparency-hub">Introducing Anthropic's Transparency Hub</a></li>
<li><a href="#claude-and-alexa">Claude and Alexa+</a></li>
<li><a href="#statement-from-dario-amodei-on-the-paris-ai-action-summit">Statement from Dario Amodei on the Paris AI Action Summit</a></li>
<li><a href="#lyft-to-bring-claude-to-more-than-40-million-riders-and-over-1-million-drivers">Lyft to bring Claude to more than 40 million riders and over 1 million drivers</a></li>
</ul>
</li>
<li><a href="#january-2025"><strong>January 2025</strong></a>
<ul>
<li><a href="#introducing-citations-on-the-anthropic-api">Introducing Citations on the Anthropic API</a></li>
<li><a href="#anthropic-achieves-iso-42001-certification-for-responsible-ai">Anthropic achieves ISO 42001 certification for responsible AI</a></li>
</ul>
</li>
<li><a href="#december-2024"><strong>December 2024</strong></a>
<ul>
<li><a href="#elections-and-ai-in-2024-observations-and-learnings">Elections and AI in 2024: observations and learnings</a></li>
<li><a href="#claude-35-haiku-on-aws-trainium2-and-model-distillation-in-amazon-bedrock">Claude 3.5 Haiku on AWS Trainium2 and model distillation in Amazon Bedrock</a></li>
</ul>
</li>
<li><a href="#november-2024"><strong>November 2024</strong></a>
<ul>
<li><a href="#tailor-claudes-responses-to-your-personal-style">Tailor Claude’s responses to your personal style</a></li>
<li><a href="#introducing-the-model-context-protocol">Introducing the Model Context Protocol</a></li>
<li><a href="#powering-the-next-generation-of-ai-development-with-aws">Powering the next generation of AI development with AWS</a></li>
<li><a href="#improve-your-prompts-in-the-developer-console">Improve your prompts in the developer console</a></li>
</ul>
</li>
<li><a href="#october-2024"><strong>October 2024</strong></a>
<ul>
<li><a href="#the-case-for-targeted-regulation">The case for targeted regulation</a></li>
<li><a href="#claude-35-sonnet-on-github-copilot">Claude 3.5 Sonnet on GitHub Copilot</a></li>
<li><a href="#introducing-the-analysis-tool-in-claudeai">Introducing the analysis tool in Claude.ai</a></li>
<li><a href="#developing-a-computer-use-model">Developing a computer use model</a></li>
<li><a href="#announcing-our-updated-responsible-scaling-policy">Announcing our updated Responsible Scaling Policy</a></li>
<li><a href="#us-elections-readiness">U.S. Elections Readiness</a></li>
<li><a href="#introducing-the-message-batches-api">Introducing the Message Batches API</a></li>
</ul>
</li>
<li><a href="#september-2024"><strong>September 2024</strong></a>
<ul>
<li><a href="#fine-tuning-for-claude-3-haiku-in-amazon-bedrock-is-now-generally-available">Fine-tuning for Claude 3 Haiku in Amazon Bedrock is now generally available</a></li>
<li><a href="#introducing-contextual-retrieval">Introducing Contextual Retrieval</a></li>
<li><a href="#workspaces-in-the-anthropic-api-console">Workspaces in the Anthropic API Console</a></li>
<li><a href="#claude-for-enterprise">Claude for Enterprise</a></li>
<li><a href="#salesforce-teams-up-with-anthropic-to-enhance-einstein-capabilities-with-claude">Salesforce teams up with Anthropic to enhance Einstein capabilities with Claude</a></li>
</ul>
</li>
<li><a href="#august-2024"><strong>August 2024</strong></a>
<ul>
<li><a href="#artifacts-are-now-generally-available">Artifacts are now generally available</a></li>
<li><a href="#prompt-caching-with-claude">Prompt caching with Claude</a></li>
<li><a href="#expanding-our-model-safety-bug-bounty-program">Expanding our model safety bug bounty program</a></li>
<li><a href="#claude-is-now-available-in-brazil">Claude is now available in Brazil</a></li>
</ul>
</li>
<li><a href="#july-2024"><strong>July 2024</strong></a>
<ul>
<li><a href="#anthropic-partners-with-menlo-ventures-to-launch-anthology-fund">Anthropic partners with Menlo Ventures to launch Anthology Fund</a></li>
<li><a href="#claude-android-app">Claude Android app</a></li>
<li><a href="#fine-tune-claude-3-haiku-in-amazon-bedrock">Fine-tune Claude 3 Haiku in Amazon Bedrock</a></li>
<li><a href="#evaluate-prompts-in-the-developer-console">Evaluate prompts in the developer console</a></li>
<li><a href="#a-new-initiative-for-developing-third-party-model-evaluations">A new initiative for developing third-party model evaluations</a></li>
</ul>
</li>
<li><a href="#june-2024"><strong>June 2024</strong></a>
<ul>
<li><a href="#expanding-access-to-claude-for-government">Expanding access to Claude for government</a></li>
<li><a href="#collaborate-with-claude-on-projects">Collaborate with Claude on Projects</a></li>
<li><a href="#claude-35-sonnet">Claude 3.5 Sonnet</a></li>
<li><a href="#challenges-in-red-teaming-ai-systems">Challenges in red teaming AI systems</a></li>
<li><a href="#testing-and-mitigating-elections-related-risks">Testing and mitigating elections-related risks</a></li>
<li><a href="#introducing-claude-to-canada">Introducing Claude to Canada</a></li>
</ul>
</li>
<li><a href="#may-2024"><strong>May 2024</strong></a>
<ul>
<li><a href="#claude-can-now-use-tools">Claude can now use tools</a></li>
<li><a href="#jay-kreps-appointed-to-anthropics-board-of-directors">Jay Kreps appointed to Anthropic's Board of Directors</a></li>
<li><a href="#golden-gate-claude">Golden Gate Claude</a></li>
<li><a href="#krishna-rao-joins-anthropic-as-chief-financial-officer">Krishna Rao joins Anthropic as Chief Financial Officer</a></li>
<li><a href="#generate-better-prompts-in-the-developer-console">Generate better prompts in the developer console</a></li>
<li><a href="#reflections-on-our-responsible-scaling-policy">Reflections on our Responsible Scaling Policy</a></li>
<li><a href="#mike-krieger-joins-anthropic-as-chief-product-officer">Mike Krieger joins Anthropic as Chief Product Officer</a></li>
<li><a href="#claude-is-now-available-in-europe">Claude is now available in Europe</a></li>
<li><a href="#updating-our-usage-policy">Updating our Usage Policy</a></li>
<li><a href="#introducing-the-claude-team-plan-and-ios-app">Introducing the Claude Team plan and iOS app</a></li>
</ul>
</li>
<li><a href="#april-2024"><strong>April 2024</strong></a>
<ul>
<li><a href="#aligning-on-child-safety-principles">Aligning on child safety principles</a></li>
</ul>
</li>
<li><a href="#march-2024"><strong>March 2024</strong></a>
<ul>
<li><a href="#third-party-testing-as-a-key-ingredient-of-ai-policy">Third-party testing as a key ingredient of AI policy</a></li>
<li><a href="#anthropic-aws-and-accenture-team-up-to-build-trusted-solutions-for-enterprises">Anthropic, AWS, and Accenture team up to build trusted solutions for enterprises</a></li>
<li><a href="#claude-3-models-on-vertex-ai">Claude 3 models on Vertex AI</a></li>
<li><a href="#claude-3-haiku-our-fastest-model-yet">Claude 3 Haiku: our fastest model yet</a></li>
<li><a href="#introducing-the-next-generation-of-claude">Introducing the next generation of Claude</a></li>
</ul>
</li>
<li><a href="#february-2024"><strong>February 2024</strong></a>
<ul>
<li><a href="#prompt-engineering-for-business-performance">Prompt engineering for business performance</a></li>
<li><a href="#preparing-for-global-elections-in-2024">Preparing for global elections in 2024</a></li>
</ul>
</li>
<li><a href="#december-2023"><strong>December 2023</strong></a>
<ul>
<li><a href="#expanded-legal-protections-and-improvements-to-our-api">Expanded legal protections and improvements to our API</a></li>
<li><a href="#long-context-prompting-for-claude-21">Long context prompting for Claude 2.1</a></li>
</ul>
</li>
<li><a href="#november-2023"><strong>November 2023</strong></a>
<ul>
<li><a href="#introducing-claude-21">Introducing Claude 2.1</a></li>
<li><a href="#thoughts-on-the-us-executive-order-g7-code-of-conduct-and-bletchley-park-summit">Thoughts on the US Executive Order, G7 Code of Conduct, and Bletchley Park Summit</a></li>
<li><a href="#dario-amodeis-prepared-remarks-from-the-ai-safety-summit-on-anthropics-responsible-scaling-policy">Dario Amodei’s prepared remarks from the AI Safety Summit on Anthropic’s Responsible Scaling Policy</a></li>
</ul>
</li>
<li><a href="#september-2023"><strong>September 2023</strong></a>
<ul>
<li><a href="#claude-on-amazon-bedrock-now-available-to-every-aws-customer">Claude on Amazon Bedrock now available to every AWS customer</a></li>
<li><a href="#expanding-access-to-safer-ai-with-amazon">Expanding access to safer AI with Amazon</a></li>
<li><a href="#prompt-engineering-for-claudes-long-context-window">Prompt engineering for Claude's long context window</a></li>
<li><a href="#anthropics-responsible-scaling-policy">Anthropic's Responsible Scaling Policy</a></li>
<li><a href="#the-long-term-benefit-trust">The Long-Term Benefit Trust</a></li>
<li><a href="#anthropic-partners-with-bcg">Anthropic partners with BCG</a></li>
<li><a href="#introducing-claude-pro">Introducing Claude Pro</a></li>
</ul>
</li>
<li><a href="#august-2023"><strong>August 2023</strong></a>
<ul>
<li><a href="#claude-2-on-amazon-bedrock">Claude 2 on Amazon Bedrock</a></li>
<li><a href="#skt-partnership-announcement">SKT Partnership Announcement</a></li>
<li><a href="#releasing-claude-instant-12">Releasing Claude Instant 1.2</a></li>
</ul>
</li>
<li><a href="#july-2023"><strong>July 2023</strong></a>
<ul>
<li><a href="#frontier-threats-red-teaming-for-ai-safety">Frontier Threats Red Teaming for AI Safety</a></li>
<li><a href="#frontier-model-security">Frontier Model Security</a></li>
<li><a href="#claude-2">Claude 2</a></li>
</ul>
</li>
<li><a href="#june-2023"><strong>June 2023</strong></a>
<ul>
<li><a href="#charting-a-path-to-ai-accountability">Charting a Path to AI Accountability</a></li>
</ul>
</li>
<li><a href="#may-2023"><strong>May 2023</strong></a>
<ul>
<li><a href="#anthropic-raises-450-million-in-series-c-funding-to-scale-reliable-ai-products">Anthropic Raises $450 Million in Series C Funding to Scale Reliable AI Products</a></li>
<li><a href="#zoom-partnership-and-investment-in-anthropic">Zoom Partnership and Investment in Anthropic</a></li>
<li><a href="#introducing-100k-context-windows">Introducing 100K Context Windows</a></li>
<li><a href="#claudes-constitution">Claude’s Constitution</a></li>
</ul>
</li>
<li><a href="#april-2023"><strong>April 2023</strong></a>
<ul>
<li><a href="#partnering-with-scale-to-bring-generative-ai-to-enterprises">Partnering with Scale to Bring Generative AI to Enterprises</a></li>
<li><a href="#an-ai-policy-tool-for-today-ambitiously-invest-in-nist">An AI Policy Tool for Today: Ambitiously Invest in NIST</a></li>
</ul>
</li>
<li><a href="#march-2023"><strong>March 2023</strong></a>
<ul>
<li><a href="#claude-now-in-slack">Claude, now in Slack</a></li>
<li><a href="#introducing-claude">Introducing Claude</a></li>
</ul>
</li>
<li><a href="#february-2023"><strong>February 2023</strong></a>
<ul>
<li><a href="#anthropic-partners-with-google-cloud">Anthropic Partners with Google Cloud</a></li>
</ul>
</li>
<li><a href="#april-2022"><strong>April 2022</strong></a>
<ul>
<li><a href="#anthropic-raises-series-b-to-build-steerable-interpretable-robust-ai-systems">Anthropic Raises Series B to build steerable, interpretable, robust AI systems</a></li>
</ul>
</li>
<li><a href="#may-2021"><strong>May 2021</strong></a>
<ul>
<li><a href="#anthropic-raises-124-million-to-build-more-reliable-general-ai-systems">Anthropic raises $124 million to build more reliable, general AI systems</a></li>
</ul>
</li>
</ul>
</div></template>


