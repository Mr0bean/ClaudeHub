<template><div><h1 id="github-mcp-server-claudelog" tabindex="-1"><a class="header-anchor" href="#github-mcp-server-claudelog"><span>GitHub MCP Server | ClaudeLog</span></a></h1>
<p><strong>Official MCP server providing seamless GitHub API integration for advanced automation and AI-powered development workflows.</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/github" target="_blank" rel="noopener noreferrer">GitHub</a>  |  <a href="https://github.com/github/github-mcp-server" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  21.6k Stars|2.2k Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>The GitHub MCP Server is the official Model Context Protocol implementation for GitHub integration, enabling AI models to interact directly with GitHub's ecosystem. It provides comprehensive access to repositories, issues, pull requests, actions, and security features through a standardized MCP interface, transforming how developers automate and manage GitHub workflows.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Comprehensive GitHub API Access</strong> - Extensive integration with GitHub's REST and GraphQL APIs through curated toolsets</li>
<li><strong>Flexible Deployment Options</strong> - Remote hosted server or local Docker installation</li>
<li><strong>Granular Permissions</strong> - Fine-grained control over tool access and capabilities</li>
<li><strong>Enterprise Support</strong> - GitHub Enterprise Server compatibility with custom configurations</li>
<li><strong>Dynamic Tool Discovery</strong> - Automatically adapts to available GitHub features</li>
<li><strong>Multi-Toolset Support</strong> - Actions, security, issues, PRs, repositories, notifications</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>VS Code 1.101+ (for remote server) or Docker (for local installation)</li>
<li>GitHub Personal Access Token with appropriate permissions</li>
</ul>
<p><strong>Method 1: Remote Server (Recommended)</strong></p>
<p>Install directly in VS Code with one-click buttons:</p>
<ul>
<li><a href="vscode:extension/modelcontextprotocol.servers" target="_blank" rel="noopener noreferrer">Install for Claude Desktop</a></li>
<li><a href="vscode:extension/modelcontextprotocol.servers" target="_blank" rel="noopener noreferrer">Install for Continue</a></li>
</ul>
<p><strong>Method 2: Claude Desktop Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"github"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"docker"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"run"</span>, <span class="token string">"-i"</span>, <span class="token string">"--rm"</span>, <span class="token string">"-e"</span>, <span class="token string">"GITHUB_PERSONAL_ACCESS_TOKEN"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"ghcr.io/github/github-mcp-server"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">]</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"env"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"GITHUB_PERSONAL_ACCESS_TOKEN"</span><span class="token builtin class-name">:</span> <span class="token string">"&amp;lt;YOUR_TOKEN&amp;gt;"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Method 3: Local Docker Installation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Run GitHub MCP server locally</span></span>
<span class="line"></span>
<span class="line"><span class="token function">docker</span> run <span class="token parameter variable">-i</span> <span class="token parameter variable">--rm</span> <span class="token punctuation">\</span></span>
<span class="line"></span>
<span class="line">  <span class="token parameter variable">-e</span> <span class="token assign-left variable">GITHUB_PERSONAL_ACCESS_TOKEN</span><span class="token operator">=</span><span class="token operator">&amp;</span>lt<span class="token punctuation">;</span>your-token<span class="token operator">&amp;</span>gt<span class="token punctuation">;</span> <span class="token punctuation">\</span></span>
<span class="line"></span>
<span class="line">  <span class="token parameter variable">-e</span> <span class="token assign-left variable">GITHUB_TOOLSETS</span><span class="token operator">=</span><span class="token string">"context,repos,issues,pull_requests"</span> <span class="token punctuation">\</span></span>
<span class="line"></span>
<span class="line">  ghcr.io/github/github-mcp-server</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Available GITHUB_TOOLSETS</strong></p>
<ul>
<li><strong><code v-pre>context</code></strong> - Repository context (recommended for most use cases)</li>
<li><strong><code v-pre>repos</code></strong> - Repository management and operations</li>
<li><strong><code v-pre>issues</code></strong> - GitHub Issues API access</li>
<li><strong><code v-pre>pull_requests</code></strong> - Pull request management</li>
<li><strong><code v-pre>actions</code></strong> - GitHub Actions workflow integration</li>
<li><strong><code v-pre>code_security</code></strong> - Security scanning and vulnerability management</li>
<li><strong><code v-pre>notifications</code></strong> - GitHub notifications management</li>
<li><strong><code v-pre>orgs</code></strong> - Organization management</li>
<li><strong><code v-pre>secret_protection</code></strong> - Secret scanning and protection</li>
<li><strong><code v-pre>users</code></strong> - User account operations</li>
<li><strong><code v-pre>experiments</code></strong> - Experimental GitHub features (optional)</li>
<li><strong><code v-pre>all</code></strong> - Enable all available toolsets</li>
</ul>
<p><strong>Note</strong>: The <code v-pre>context</code> toolset is recommended for most users. Specify only needed toolsets to help the LLM with tool choice and reduce context size. All toolsets are enabled by default if <code v-pre>GITHUB_TOOLSETS</code> is not specified.</p>
<hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Repository Management</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Example interactions through AI client:</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "List my repositories and their latest commits"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Create a new pull request for the feature branch"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Show me all open issues with bug labels"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Check the status of GitHub Actions runs"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The server enables natural language interaction with GitHub's complete feature set. You can manage repositories, automate issue tracking, review code changes, monitor CI/CD pipelines, and handle security alerts - all through conversational AI interfaces.</p>
<p><strong>Configuration Options</strong></p>
<ul>
<li><strong>Toolset Selection</strong>: Choose specific GitHub features to expose</li>
<li><strong>Read-Only Mode</strong>: Restrict to safe, non-modifying operations</li>
<li><strong>Custom Permissions</strong>: Configure OAuth scopes for security</li>
<li><strong>Enterprise Settings</strong>: Connect to GitHub Enterprise instances</li>
</ul>
<hr>
<h5 id="community-insight" tabindex="-1"><a class="header-anchor" href="#community-insight"><span>Community Insight</span></a></h5>
<p>The official MCP server has transformed developer workflows with users reporting: &quot;I use it to interact with issues and MRs, looking for related issues when editing code.&quot; The official nature ensures reliability that community alternatives often lack.</p>
<img src="/img/discovery/019.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>GitHub MCP Server is developed and maintained by the Model Context Protocol organization. For technical support, feature requests, and enterprise configurations, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


