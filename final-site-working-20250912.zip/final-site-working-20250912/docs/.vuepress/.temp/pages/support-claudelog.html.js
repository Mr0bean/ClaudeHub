import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/support-claudelog.html.vue"
const data = JSON.parse("{\"path\":\"/support-claudelog.html\",\"title\":\"Support ClaudeLog | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Support ClaudeLog | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"support-claudelog.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
