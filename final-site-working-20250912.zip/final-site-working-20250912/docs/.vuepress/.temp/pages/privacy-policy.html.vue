<template><div><h1 id="privacy-policy-claudelog" tabindex="-1"><a class="header-anchor" href="#privacy-policy-claudelog"><span>Privacy Policy | ClaudeLog</span></a></h1>
<p><strong>Effective Date</strong>: August 26, 2025 <strong>Last Updated</strong>: August 28, 2025</p>
<hr>
<h2 id="introduction​" tabindex="-1"><a class="header-anchor" href="#introduction​"><span>Introduction<a href="#introduction" title="Direct link to Introduction">​</a></span></a></h2>
<p>ClaudeLog (&quot;we,&quot; &quot;us,&quot; or &quot;our&quot;) operates the website <a href="https://www.claudelog.com" target="_blank" rel="noopener noreferrer">https://www.claudelog.com</a> (the &quot;Service&quot;). This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data.</p>
<hr>
<h2 id="information-we-collect​" tabindex="-1"><a class="header-anchor" href="#information-we-collect​"><span>Information We Collect<a href="#information-we-collect" title="Direct link to Information We Collect">​</a></span></a></h2>
<h3 id="personal-information​" tabindex="-1"><a class="header-anchor" href="#personal-information​"><span>Personal Information<a href="#personal-information" title="Direct link to Personal Information">​</a></span></a></h3>
<p>When you subscribe to our newsletter or contact us, we may collect personally identifiable information such as:</p>
<ul>
<li>Email address</li>
<li>Name (when provided)</li>
<li>Communication preferences</li>
</ul>
<h3 id="automatically-collected-information​" tabindex="-1"><a class="header-anchor" href="#automatically-collected-information​"><span>Automatically Collected Information<a href="#automatically-collected-information" title="Direct link to Automatically Collected Information">​</a></span></a></h3>
<p>When you visit our website, we automatically collect certain information about your device and usage, including:</p>
<ul>
<li>IP address</li>
<li>Browser type and version</li>
<li>Operating system</li>
<li>Pages visited and time spent</li>
<li>Referring websites</li>
<li>Device information (screen size, device type)</li>
</ul>
<hr>
<h2 id="how-we-use-your-information​" tabindex="-1"><a class="header-anchor" href="#how-we-use-your-information​"><span>How We Use Your Information<a href="#how-we-use-your-information" title="Direct link to How We Use Your Information">​</a></span></a></h2>
<p>We use the collected information for the following purposes, based on the legal grounds specified:</p>
<p><strong>Service Operation</strong> (Legal basis: Legitimate interest)</p>
<ul>
<li>Providing and maintaining our Service</li>
<li>Ensuring website functionality and security</li>
</ul>
<p><strong>Communications</strong> (Legal basis: Consent)</p>
<ul>
<li>Sending newsletters and updates (with your explicit consent)</li>
<li>Responding to your inquiries and requests</li>
</ul>
<p><strong>Analytics and Improvement</strong> (Legal basis: Legitimate interest)</p>
<ul>
<li>Analyzing website usage and improving our Service</li>
<li>Understanding user preferences and behavior</li>
</ul>
<p><strong>Legal Compliance</strong> (Legal basis: Legal obligation)</p>
<ul>
<li>Complying with applicable laws and regulations</li>
<li>Responding to legal requests from authorities</li>
</ul>
<hr>
<h2 id="cookies-and-tracking-technologies​" tabindex="-1"><a class="header-anchor" href="#cookies-and-tracking-technologies​"><span>Cookies and Tracking Technologies<a href="#cookies-and-tracking-technologies" title="Direct link to Cookies and Tracking Technologies">​</a></span></a></h2>
<p>We use cookies and similar tracking technologies on our website. Cookies are small text files stored on your device that help us provide and improve our services.</p>
<h3 id="cookie-categories​" tabindex="-1"><a class="header-anchor" href="#cookie-categories​"><span>Cookie Categories<a href="#cookie-categories" title="Direct link to Cookie Categories">​</a></span></a></h3>
<p><strong>Essential Cookies</strong> (Legal basis: Legitimate interest)</p>
<ul>
<li>Required for basic website functionality</li>
<li>Enable core features like navigation and access to secure areas</li>
<li>Cannot be disabled without affecting website operation</li>
</ul>
<p><strong>Functional Cookies</strong> (Legal basis: Consent)</p>
<ul>
<li>Remember your preferences and settings</li>
<li>Enhance user experience with personalized features</li>
<li>Include newsletter subscription preferences</li>
</ul>
<p><strong>Analytics Cookies</strong> (Legal basis: Legitimate interest)</p>
<ul>
<li>Help us understand how visitors interact with our website</li>
<li>Collect anonymous information about page views and user behavior</li>
<li>Used to improve website performance and content</li>
</ul>
<p><strong>Advertising Cookies</strong> (Legal basis: Consent)</p>
<ul>
<li>Enable personalized advertising through Google AdSense</li>
<li>Track your interests across websites for relevant ads</li>
<li>Allow measurement of advertising effectiveness</li>
</ul>
<h3 id="google-adsense​" tabindex="-1"><a class="header-anchor" href="#google-adsense​"><span>Google AdSense<a href="#google-adsense" title="Direct link to Google AdSense">​</a></span></a></h3>
<p>Third-party vendors, including Google, use cookies to serve ads based on a user's prior visits to your website or other websites. Google's use of advertising cookies enables it and its partners to serve ads to your users based on their visit to your sites and/or other sites on the Internet.</p>
<p>Users may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer">Google's Ads Settings</a>.</p>
<h3 id="google-analytics​" tabindex="-1"><a class="header-anchor" href="#google-analytics​"><span>Google Analytics<a href="#google-analytics" title="Direct link to Google Analytics">​</a></span></a></h3>
<p>We use Google Analytics to analyze website traffic and user behavior. Google Analytics uses cookies to collect information about how visitors use our site, including:</p>
<ul>
<li>Pages visited and time spent</li>
<li>Geographic location (country/region level)</li>
<li>Browser and device information</li>
<li>Traffic sources and referrers</li>
</ul>
<p><strong>IP Anonymization</strong>: We have enabled IP anonymization in Google Analytics, which means your IP address is truncated before storage to protect your privacy.</p>
<p>You can opt out of Google Analytics by installing the <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener noreferrer">Google Analytics Opt-out Browser Add-on</a>.</p>
<h3 id="newsletter-service-mailchimp-​" tabindex="-1"><a class="header-anchor" href="#newsletter-service-mailchimp-​"><span>Newsletter Service (MailChimp)<a href="#newsletter-service-mailchimp" title="Direct link to Newsletter Service (MailChimp)">​</a></span></a></h3>
<p>We use MailChimp to manage our newsletter subscriptions. When you subscribe to our newsletter, your email address and any additional information you provide is stored on MailChimp's servers. Please review <a href="https://mailchimp.com/legal/privacy/" target="_blank" rel="noopener noreferrer">MailChimp's Privacy Policy</a> for more information.</p>
<h3 id="support-platform-buy-me-a-coffee-​" tabindex="-1"><a class="header-anchor" href="#support-platform-buy-me-a-coffee-​"><span>Support Platform (Buy Me a Coffee)<a href="#support-platform-buy-me-a-coffee" title="Direct link to Support Platform (Buy Me a Coffee)">​</a></span></a></h3>
<p>We use Buy Me a Coffee to facilitate community support and contributions to ClaudeLog. When you support us through this platform:</p>
<ul>
<li>Your transaction data is processed by Buy Me a Coffee according to their privacy policy</li>
<li>We may receive basic supporter information (name, message, public profile details) as provided by the platform</li>
<li>Any images or personal information you voluntarily share in support messages are subject to our discretion regarding public display</li>
</ul>
<p>For more information, please review <a href="https://buymeacoffee.com/privacy" target="_blank" rel="noopener noreferrer">Buy Me a Coffee's Privacy Policy</a>.</p>
<hr>
<h2 id="data-sharing-and-third-parties​" tabindex="-1"><a class="header-anchor" href="#data-sharing-and-third-parties​"><span>Data Sharing and Third Parties<a href="#data-sharing-and-third-parties" title="Direct link to Data Sharing and Third Parties">​</a></span></a></h2>
<p>We may share your information with third-party service providers who assist us in operating our website and conducting our business, including:</p>
<ul>
<li><strong>Google AdSense</strong> (for advertising) - <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>
<li><strong>Google Analytics</strong> (for website analytics) - <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>
<li><strong>MailChimp</strong> (for newsletter services) - <a href="https://mailchimp.com/legal/privacy/" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>
<li><strong>GitHub Pages</strong> (for website hosting) - <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement" target="_blank" rel="noopener noreferrer">Privacy Statement</a></li>
<li><strong>Buy Me a Coffee</strong> (for community support) - <a href="https://buymeacoffee.com/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>
<li>Other web service providers as necessary for website operation</li>
</ul>
<p>We do not sell, trade, or otherwise transfer your personal information to third parties for their marketing purposes without your consent.</p>
<h3 id="anthropic-s-updated-consumer-terms-august-2025-​" tabindex="-1"><a class="header-anchor" href="#anthropic-s-updated-consumer-terms-august-2025-​"><span>Anthropic's Updated Consumer Terms (August 2025)<a href="#anthropics-updated-consumer-terms-august-2025" title="Direct link to Anthropic's Updated Consumer Terms (August 2025)">​</a></span></a></h3>
<p><strong>Important Notice for Claude Code Users</strong></p>
<p>If you use Claude Code through consumer Anthropic accounts (Free, Pro, or Max subscriptions), please be aware that Anthropic has updated their consumer terms and privacy policy regarding data usage for model training.</p>
<p><strong>Consumer Account Policy Changes:</strong></p>
<ul>
<li>Anthropic now requests permission to use chats and coding sessions for AI model training and improvement</li>
<li>This applies to Claude Free, Pro, and Max subscription accounts when used with Claude Code</li>
<li>You maintain full control and can opt-in, opt-out, or change your preference at any time</li>
<li>Only new or resumed sessions would be used for training (not historical data)</li>
</ul>
<p><strong>Commercial Accounts Unaffected:</strong></p>
<ul>
<li>Anthropic API users are not subject to these consumer policy changes</li>
<li>Claude for Work, Education, and enterprise accounts operate under different terms</li>
<li>These accounts continue under existing commercial data processing agreements</li>
</ul>
<p><strong>Your Choices:</strong> When using Claude Code, you can make informed decisions about data usage based on your privacy preferences and project requirements. For complete details about Anthropic's data policies, privacy protections, and your choices, please review <a href="https://www.anthropic.com/privacy" target="_blank" rel="noopener noreferrer">Anthropic's Privacy Policy</a> and <a href="https://privacy.anthropic.com/" target="_blank" rel="noopener noreferrer">Privacy Center</a>.</p>
<p><strong>ClaudeLog's Role:</strong> ClaudeLog serves as a documentation resource and does not process your Claude Code interactions. Your data handling is governed by your relationship with Anthropic based on your chosen authentication method (consumer subscription vs. API).</p>
<hr>
<h2 id="international-data-transfers​" tabindex="-1"><a class="header-anchor" href="#international-data-transfers​"><span>International Data Transfers<a href="#international-data-transfers" title="Direct link to International Data Transfers">​</a></span></a></h2>
<p>Your information may be transferred to and processed in countries other than your country of residence. These countries may have data protection laws that are different from the laws of your country.</p>
<hr>
<h2 id="your-rights-under-privacy-laws​" tabindex="-1"><a class="header-anchor" href="#your-rights-under-privacy-laws​"><span>Your Rights Under Privacy Laws<a href="#your-rights-under-privacy-laws" title="Direct link to Your Rights Under Privacy Laws">​</a></span></a></h2>
<h3 id="general-rights​" tabindex="-1"><a class="header-anchor" href="#general-rights​"><span>General Rights<a href="#general-rights" title="Direct link to General Rights">​</a></span></a></h3>
<p>Depending on your location, you may have the following rights regarding your personal information:</p>
<ul>
<li>Right to access your personal data</li>
<li>Right to rectification of inaccurate data</li>
<li>Right to erasure (&quot;right to be forgotten&quot;)</li>
<li>Right to restrict processing</li>
<li>Right to data portability</li>
<li>Right to object to processing</li>
</ul>
<h3 id="gdpr-rights-eu-residents-​" tabindex="-1"><a class="header-anchor" href="#gdpr-rights-eu-residents-​"><span>GDPR Rights (EU Residents)<a href="#gdpr-rights-eu-residents" title="Direct link to GDPR Rights (EU Residents)">​</a></span></a></h3>
<p>If you are located in the European Union, you have additional rights under the General Data Protection Regulation (GDPR), including the right to lodge a complaint with a supervisory authority.</p>
<h3 id="ccpa-rights-california-residents-​" tabindex="-1"><a class="header-anchor" href="#ccpa-rights-california-residents-​"><span>CCPA Rights (California Residents)<a href="#ccpa-rights-california-residents" title="Direct link to CCPA Rights (California Residents)">​</a></span></a></h3>
<p>If you are a California resident, you have rights under the California Consumer Privacy Act (CCPA), including:</p>
<ul>
<li>Right to know what personal information is collected</li>
<li>Right to delete personal information</li>
<li>Right to opt-out of the sale of personal information</li>
<li>Right to non-discrimination</li>
</ul>
<hr>
<h2 id="data-retention​" tabindex="-1"><a class="header-anchor" href="#data-retention​"><span>Data Retention<a href="#data-retention" title="Direct link to Data Retention">​</a></span></a></h2>
<p>We retain your personal information only for as long as necessary to fulfill the purposes for which it was collected, comply with legal obligations, resolve disputes, and enforce our agreements.</p>
<ul>
<li>Newsletter subscriptions: Until you unsubscribe</li>
<li>Contact form submissions: 2 years</li>
<li>Analytics data: As per Google Analytics retention settings (default 26 months)</li>
<li>Cookies: As specified in individual cookie settings</li>
</ul>
<hr>
<h2 id="security​" tabindex="-1"><a class="header-anchor" href="#security​"><span>Security<a href="#security" title="Direct link to Security">​</a></span></a></h2>
<p>We implement appropriate technical and organizational security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure.</p>
<hr>
<h2 id="data-breach-notification​" tabindex="-1"><a class="header-anchor" href="#data-breach-notification​"><span>Data Breach Notification<a href="#data-breach-notification" title="Direct link to Data Breach Notification">​</a></span></a></h2>
<p>In the event of a data breach that poses a risk to your rights and freedoms, we will:</p>
<ul>
<li><strong>Notify authorities</strong>: Report the breach to relevant supervisory authorities within 72 hours where required by law</li>
<li><strong>Inform affected users</strong>: Notify you via email or prominent website notice without undue delay if the breach poses a high risk to your rights</li>
<li><strong>Provide clear information</strong>: Include details about the nature of the breach, potential consequences, and measures we're taking to address it</li>
<li><strong>Offer guidance</strong>: Recommend steps you can take to protect yourself from potential harm</li>
</ul>
<hr>
<h2 id="automated-decision-making-and-profiling​" tabindex="-1"><a class="header-anchor" href="#automated-decision-making-and-profiling​"><span>Automated Decision-Making and Profiling<a href="#automated-decision-making-and-profiling" title="Direct link to Automated Decision-Making and Profiling">​</a></span></a></h2>
<p>We do not engage in automated decision-making or profiling that produces legal effects or significantly affects you. Any automated processing we conduct (such as analytics) is solely for the purposes of:</p>
<ul>
<li>Improving website performance and user experience</li>
<li>Understanding aggregate user behavior patterns</li>
<li>Providing relevant content recommendations</li>
</ul>
<p>You are not subject to automated decisions that could impact your rights, and human oversight is maintained for all significant processing activities.</p>
<hr>
<h2 id="children-s-privacy​" tabindex="-1"><a class="header-anchor" href="#children-s-privacy​"><span>Children's Privacy<a href="#childrens-privacy" title="Direct link to Children's Privacy">​</a></span></a></h2>
<p>Our Service is not intended for children under 13 years of age. We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us so we can delete such information.</p>
<hr>
<h2 id="updates-to-this-privacy-policy​" tabindex="-1"><a class="header-anchor" href="#updates-to-this-privacy-policy​"><span>Updates to This Privacy Policy<a href="#updates-to-this-privacy-policy" title="Direct link to Updates to This Privacy Policy">​</a></span></a></h2>
<p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the &quot;Last Updated&quot; date.</p>
<hr>
<h2 id="contact-information​" tabindex="-1"><a class="header-anchor" href="#contact-information​"><span>Contact Information<a href="#contact-information" title="Direct link to Contact Information">​</a></span></a></h2>
<p>If you have any questions about this Privacy Policy or our privacy practices, please contact us at:</p>
<p><strong>Email</strong>: <a href="mailto:hello@claudelog.com" target="_blank" rel="noopener noreferrer">hello@claudelog.com</a></p>
<hr>
<h2 id="cookie-consent​" tabindex="-1"><a class="header-anchor" href="#cookie-consent​"><span>Cookie Consent<a href="#cookie-consent" title="Direct link to Cookie Consent">​</a></span></a></h2>
<p>By continuing to use our website, you consent to our use of cookies as described in this Privacy Policy. You can manage your cookie preferences through your browser settings.</p>
<hr>
<ul>
<li><a href="#introduction">Introduction</a></li>
<li><a href="#information-we-collect">Information We Collect</a>
<ul>
<li><a href="#personal-information">Personal Information</a></li>
<li><a href="#automatically-collected-information">Automatically Collected Information</a></li>
</ul>
</li>
<li><a href="#how-we-use-your-information">How We Use Your Information</a></li>
<li><a href="#cookies-and-tracking-technologies">Cookies and Tracking Technologies</a>
<ul>
<li><a href="#cookie-categories">Cookie Categories</a></li>
<li><a href="#google-adsense">Google AdSense</a></li>
<li><a href="#google-analytics">Google Analytics</a></li>
<li><a href="#newsletter-service-mailchimp">Newsletter Service (MailChimp)</a></li>
<li><a href="#support-platform-buy-me-a-coffee">Support Platform (Buy Me a Coffee)</a></li>
</ul>
</li>
<li><a href="#data-sharing-and-third-parties">Data Sharing and Third Parties</a>
<ul>
<li><a href="#anthropics-updated-consumer-terms-august-2025">Anthropic's Updated Consumer Terms (August 2025)</a></li>
</ul>
</li>
<li><a href="#international-data-transfers">International Data Transfers</a></li>
<li><a href="#your-rights-under-privacy-laws">Your Rights Under Privacy Laws</a>
<ul>
<li><a href="#general-rights">General Rights</a></li>
<li><a href="#gdpr-rights-eu-residents">GDPR Rights (EU Residents)</a></li>
<li><a href="#ccpa-rights-california-residents">CCPA Rights (California Residents)</a></li>
</ul>
</li>
<li><a href="#data-retention">Data Retention</a></li>
<li><a href="#security">Security</a></li>
<li><a href="#data-breach-notification">Data Breach Notification</a></li>
<li><a href="#automated-decision-making-and-profiling">Automated Decision-Making and Profiling</a></li>
<li><a href="#childrens-privacy">Children's Privacy</a></li>
<li><a href="#updates-to-this-privacy-policy">Updates to This Privacy Policy</a></li>
<li><a href="#contact-information">Contact Information</a></li>
<li><a href="#cookie-consent">Cookie Consent</a></li>
</ul>
</div></template>


