<template><div><h1 id="reddit-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#reddit-mcp-claudelog"><span>Reddit MCP | ClaudeLog</span></a></h1>
<p><strong>Reddit content access and analysis for Claude Code workflows</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/Hawstein" target="_blank" rel="noopener noreferrer">Hawstein</a>  |  <a href="https://github.com/Hawstein/mcp-server-reddit" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  93 Stars|15 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Reddit MCP provides access to Reddit's public API for Claude Code, enabling content analysis, community research, and social media insights through the Model Context Protocol. Browse subreddits, read posts and comments, and analyze Reddit discussions seamlessly.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Frontpage Access</strong> - Browse Reddit's frontpage and trending posts</li>
<li><strong>Subreddit Browsing</strong> - Access posts, comments, and community data from any subreddit</li>
<li><strong>Hot Posts Retrieval</strong> - Get the most popular posts from specific communities</li>
<li><strong>Post Details</strong> - Fetch detailed information about specific posts and their metadata</li>
<li><strong>Comment Trees</strong> - Access comment threads and discussion hierarchies</li>
<li><strong>Public API Access</strong> - No authentication required for public content</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Python environment for the MCP server</li>
</ul>
<p><strong>Setup MCP Server</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Install via Python</span></span>
<span class="line"></span>
<span class="line">python <span class="token parameter variable">-m</span> pip <span class="token function">install</span> mcp-server-reddit</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Or clone and install from source</span></span>
<span class="line"></span>
<span class="line"><span class="token function">git</span> clone https://github.com/Hawstein/mcp-server-reddit.git</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">cd</span> mcp-server-reddit</span>
<span class="line"></span>
<span class="line">pip <span class="token function">install</span> <span class="token parameter variable">-e</span> <span class="token builtin class-name">.</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude Code Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"projects"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"/path/to/your/project"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"reddit"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"type"</span><span class="token builtin class-name">:</span> <span class="token string">"stdio"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"node"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">            <span class="token string">"/path/to/reddit-mcp-server/build/index.js"</span></span>
<span class="line"></span>
<span class="line">          <span class="token punctuation">]</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"env"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Content Discovery</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Browse Reddit frontpage</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Show me the current top posts on Reddit's frontpage"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Access specific subreddit content</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Get the top 10 posts from r/programming today"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Community Analysis</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Analyze post engagement</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Analyze the comment patterns in r/MachineLearning posts"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Track technology discussions</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Find discussions about AI coding tools across relevant subreddits"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Research and Monitoring</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Competitive research</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Research what developers are saying about different code editors"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Trend analysis</span></span>
<span class="line"></span>
<span class="line">claude <span class="token string">"Analyze recent trends in web development discussions"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>For complete API reference and advanced usage patterns, see the <a href="https://github.com/Hawstein/mcp-server-reddit" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<h5 id="extensibility" tabindex="-1"><a class="header-anchor" href="#extensibility"><span>Extensibility</span></a></h5>
<p>Reddit MCP provides a great foundation for additional functionality. The repository can be easily extended to accommodate custom functionality beyond the default API methods.</p>
<img src="/img/discovery/003.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Reddit MCP is developed by Hawstein as a community project. For technical support and updates, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


