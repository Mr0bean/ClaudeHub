<template><div><h1 id="tutorial-claudelog" tabindex="-1"><a class="header-anchor" href="#tutorial-claudelog"><span>Tutorial | ClaudeLog</span></a></h1>
<p>Now that you have Claude Code installed, let's set up your project and learn the basics of using Claude Code to enhance your development workflow. This beginner-friendly Claude Code tutorial covers essential commands, examples, best practices, and workflow optimization for new users.</p>
<hr>
<hr>
<h2 id="claude-code-project-setup-and-configuration​" tabindex="-1"><a class="header-anchor" href="#claude-code-project-setup-and-configuration​"><span>Claude Code Project Setup and Configuration<a href="#claude-code-project-setup-and-configuration" title="Direct link to Claude Code Project Setup and Configuration">​</a></span></a></h2>
<p>Before diving into commands and examples, let's configure your project to work optimally with Claude Code. Proper setup ensures Claude understands your project structure, coding standards, and development workflow from the start.</p>
<h3 id="claude-md-configuration​" tabindex="-1"><a class="header-anchor" href="#claude-md-configuration​"><span>CLAUDE.md Configuration<a href="#claudemd-configuration" title="Direct link to CLAUDE.md Configuration">​</a></span></a></h3>
<p>Create a <code v-pre>CLAUDE.md</code> file in your project root to help Claude understand your project. This is one of the most important Claude Code best practices:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># CLAUDE.md</span></span>
<span class="line"></span>
<span class="line"><span class="token comment">## Project Overview</span></span>
<span class="line"></span>
<span class="line">Brief description of your project, its purpose, and main technologies.</span>
<span class="line"></span>
<span class="line"><span class="token comment">## Development Guidelines</span></span>
<span class="line"></span>
<span class="line">- Coding standards and conventions</span>
<span class="line"></span>
<span class="line">- File structure preferences</span>
<span class="line"></span>
<span class="line">- Testing approaches</span>
<span class="line"></span>
<span class="line"><span class="token comment">## Important Commands</span></span>
<span class="line"></span>
<span class="line">- Build commands</span>
<span class="line"></span>
<span class="line">- Test commands</span>
<span class="line"></span>
<span class="line">- Development server commands</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude Code automatically reads this file when it starts to provide project context.</p>
<hr>
<hr>
<h2 id="your-first-claude-code-session-step-by-step-tutorial​" tabindex="-1"><a class="header-anchor" href="#your-first-claude-code-session-step-by-step-tutorial​"><span>Your First Claude Code Session: Step-by-Step Tutorial<a href="#your-first-claude-code-session-step-by-step-tutorial" title="Direct link to Your First Claude Code Session: Step-by-Step Tutorial">​</a></span></a></h2>
<p>Claude Code provides two main ways to interact:</p>
<p><strong>Interactive mode:</strong> Run <code v-pre>claude</code> to start a REPL session <strong>One-shot mode:</strong> Use <code v-pre>claude -p &quot;query&quot;</code> for quick commands</p>
<h3 id="interactive-mode​" tabindex="-1"><a class="header-anchor" href="#interactive-mode​"><span>Interactive Mode<a href="#interactive-mode" title="Direct link to Interactive Mode">​</a></span></a></h3>
<p>Start Claude Code in your project directory:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">cd</span> your-project</span>
<span class="line"></span>
<span class="line">claude</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>You'll see the Claude Code prompt, ready to assist with your development tasks.</p>
<h3 id="one-shot-mode​" tabindex="-1"><a class="header-anchor" href="#one-shot-mode​"><span>One-shot Mode<a href="#one-shot-mode" title="Direct link to One-shot Mode">​</a></span></a></h3>
<p>For quick queries without starting a full session:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude <span class="token parameter variable">-p</span> <span class="token string">"Show me the files in this directory"</span></span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">-p</span> <span class="token string">"What kind of project is this?"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>This mode is perfect for quick questions or when you need fast answers without entering an interactive session.</p>
<hr>
<hr>
<h2 id="claude-code-examples-quick-wins-for-beginners​" tabindex="-1"><a class="header-anchor" href="#claude-code-examples-quick-wins-for-beginners​"><span>Claude Code Examples: Quick Wins for Beginners<a href="#claude-code-examples-quick-wins-for-beginners" title="Direct link to Claude Code Examples: Quick Wins for Beginners">​</a></span></a></h2>
<p>Here are some simple requests to get you comfortable with Claude Code:</p>
<h3 id="understanding-your-project​" tabindex="-1"><a class="header-anchor" href="#understanding-your-project​"><span>Understanding Your Project<a href="#understanding-your-project" title="Direct link to Understanding Your Project">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Show me the files <span class="token keyword">in</span> this directory</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude Code will list your project files and explain what it found.</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">What kind of project is this?</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude will analyze your project structure and tell you what type of application it is.</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Explain what this project does</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Based on your files and documentation, Claude will summarize the project's purpose.</p>
<h3 id="quick-analysis​" tabindex="-1"><a class="header-anchor" href="#quick-analysis​"><span>Quick Analysis<a href="#quick-analysis" title="Direct link to Quick Analysis">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Show me the main entry point</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude will identify and show you the primary file that starts your application.</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">What dependencies does this project have?</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude will read your package.json, requirements.txt, or similar files and list dependencies.</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">How <span class="token keyword">do</span> I run this project?</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude will look for scripts and documentation to tell you how to start the project.</p>
<h3 id="your-first-file-creation​" tabindex="-1"><a class="header-anchor" href="#your-first-file-creation​"><span>Your First File Creation<a href="#your-first-file-creation" title="Direct link to Your First File Creation">​</a></span></a></h3>
<p>Let's create your first file with Claude Code:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Create a hello_world.txt <span class="token function">file</span> with a greeting message</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Claude Code will create the file, show you what it wrote, and confirm the creation. This demonstrates Claude's ability to understand natural language and take real actions in your project.</p>
<hr>
<hr>
<h2 id="essential-claude-code-commands-and-examples​" tabindex="-1"><a class="header-anchor" href="#essential-claude-code-commands-and-examples​"><span>Essential Claude Code Commands and Examples<a href="#essential-claude-code-commands-and-examples" title="Direct link to Essential Claude Code Commands and Examples">​</a></span></a></h2>
<h3 id="file-operations​" tabindex="-1"><a class="header-anchor" href="#file-operations​"><span>File Operations<a href="#file-operations" title="Direct link to File Operations">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Read a file</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">read</span> src/components/Button.js</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Edit a file</span></span>
<span class="line"></span>
<span class="line">edit src/components/Button.js</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Create a new file</span></span>
<span class="line"></span>
<span class="line"><span class="token function">write</span> src/components/NewComponent.js</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="code-analysis​" tabindex="-1"><a class="header-anchor" href="#code-analysis​"><span>Code Analysis<a href="#code-analysis" title="Direct link to Code Analysis">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Analyze code structure</span></span>
<span class="line"></span>
<span class="line">analyze this codebase</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Find specific patterns</span></span>
<span class="line"></span>
<span class="line"><span class="token function">find</span> all React components</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Explain code</span></span>
<span class="line"></span>
<span class="line">explain how authentication works</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="development-tasks​" tabindex="-1"><a class="header-anchor" href="#development-tasks​"><span>Development Tasks<a href="#development-tasks" title="Direct link to Development Tasks">​</a></span></a></h3>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Add new features</span></span>
<span class="line"></span>
<span class="line"><span class="token function">add</span> a dark mode toggle to the app</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Fix bugs</span></span>
<span class="line"></span>
<span class="line">fix the memory leak <span class="token keyword">in</span> the data fetcher</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Refactor code</span></span>
<span class="line"></span>
<span class="line">refactor the user <span class="token function">service</span> to use TypeScript</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Write tests</span></span>
<span class="line"></span>
<span class="line"><span class="token function">write</span> unit tests <span class="token keyword">for</span> the Button component</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h2 id="how-to-use-claude-code-natural-language-commands​" tabindex="-1"><a class="header-anchor" href="#how-to-use-claude-code-natural-language-commands​"><span>How to Use Claude Code: Natural Language Commands<a href="#how-to-use-claude-code-natural-language-commands" title="Direct link to How to Use Claude Code: Natural Language Commands">​</a></span></a></h2>
<p>Claude Code understands natural language requests, making it easier than traditional development tools:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Instead of complex git commands</span></span>
<span class="line"></span>
<span class="line"><span class="token string">"Create a commit with all the changes I made to the user authentication"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Instead of manual file operations</span></span>
<span class="line"></span>
<span class="line"><span class="token string">"Update all components to use the new theme system"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Instead of searching through documentation</span></span>
<span class="line"></span>
<span class="line"><span class="token string">"How do I set up database migrations in this project?"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h5 id="welcome-to-the-future" tabindex="-1"><a class="header-anchor" href="#welcome-to-the-future"><span>Welcome to the Future</span></a></h5>
<p>You've just taken your first steps into AI-powered development with Claude Code. The journey ahead leads to unprecedented productivity and creativity in software development.</p>
<img src="/img/discovery/022_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/claude-code-pricing/">Pricing Plans</RouteLink>|<RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<RouteLink to="/claude-code-mcps/">MCPs &amp; Add-ons</RouteLink>|<RouteLink to="/faq/">FAQs</RouteLink></p>
<ul>
<li><a href="#claude-code-project-setup-and-configuration">Claude Code Project Setup and Configuration</a>
<ul>
<li><a href="#claudemd-configuration">CLAUDE.md Configuration</a></li>
</ul>
</li>
<li><a href="#your-first-claude-code-session-step-by-step-tutorial">Your First Claude Code Session: Step-by-Step Tutorial</a>
<ul>
<li><a href="#interactive-mode">Interactive Mode</a></li>
<li><a href="#one-shot-mode">One-shot Mode</a></li>
</ul>
</li>
<li><a href="#claude-code-examples-quick-wins-for-beginners">Claude Code Examples: Quick Wins for Beginners</a>
<ul>
<li><a href="#understanding-your-project">Understanding Your Project</a></li>
<li><a href="#quick-analysis">Quick Analysis</a></li>
<li><a href="#your-first-file-creation">Your First File Creation</a></li>
</ul>
</li>
<li><a href="#essential-claude-code-commands-and-examples">Essential Claude Code Commands and Examples</a>
<ul>
<li><a href="#file-operations">File Operations</a></li>
<li><a href="#code-analysis">Code Analysis</a></li>
<li><a href="#development-tasks">Development Tasks</a></li>
</ul>
</li>
<li><a href="#how-to-use-claude-code-natural-language-commands">How to Use Claude Code: Natural Language Commands</a></li>
</ul>
</div></template>


