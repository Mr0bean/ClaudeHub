<template><div><h1 id="claude-code-changelog-claudelog" tabindex="-1"><a class="header-anchor" href="#claude-code-changelog-claudelog"><span>Claude Code Changelog | ClaudeLog</span></a></h1>
<p>Complete version history of Claude Code releases, from early beta versions to the latest stable release. Each version includes feature additions, bug fixes, and links to relevant documentation. <strong>Need to downgrade?</strong> See our <RouteLink to="/faqs/revert-claude-code-version/">Revert Claude Code Version</RouteLink> guide.</p>
<hr>
<hr>
<h3 id="v1-0-111​" tabindex="-1"><a class="header-anchor" href="#v1-0-111​"><span>v1.0.111<a href="#v10111" title="Direct link to v1.0.111">​</a></span></a></h3>
<ul>
<li><code v-pre>/model</code> now validates provided model names</li>
<li>Fixed Bash tool crashes caused by malformed shell syntax parsing</li>
</ul>
<p>Sep 11, 2025</p>
<hr>
<h3 id="v1-0-110​" tabindex="-1"><a class="header-anchor" href="#v1-0-110​"><span>v1.0.110<a href="#v10110" title="Direct link to v1.0.110">​</a></span></a></h3>
<ul>
<li><code v-pre>/terminal-setup</code> command now supports WezTerm</li>
<li>MCP: OAuth tokens now proactively refresh before expiration</li>
<li>Fixed reliability issues with background Bash processes</li>
</ul>
<p>Sep 10, 2025</p>
<hr>
<h3 id="v1-0-109​" tabindex="-1"><a class="header-anchor" href="#v1-0-109​"><span>v1.0.109<a href="#v10109" title="Direct link to v1.0.109">​</a></span></a></h3>
<ul>
<li>SDK: Added partial message streaming support via --include-partial-messages CLI flag</li>
</ul>
<p>Sep 10, 2025</p>
<hr>
<h3 id="v1-0-106​" tabindex="-1"><a class="header-anchor" href="#v1-0-106​"><span>v1.0.106<a href="#v10106" title="Direct link to v1.0.106">​</a></span></a></h3>
<ul>
<li>Windows: Fixed path permission matching to consistently use POSIX format (e.g., Read(//c/Users/...))</li>
</ul>
<p>Sep 5, 2025</p>
<hr>
<h3 id="v1-0-97​" tabindex="-1"><a class="header-anchor" href="#v1-0-97​"><span>v1.0.97<a href="#v1097" title="Direct link to v1.0.97">​</a></span></a></h3>
<ul>
<li>Settings: <code v-pre>/doctor</code> now validates permission rule syntax and suggests corrections</li>
</ul>
<p>Aug 29, 2025</p>
<hr>
<h3 id="v1-0-94​" tabindex="-1"><a class="header-anchor" href="#v1-0-94​"><span>v1.0.94<a href="#v1094" title="Direct link to v1.0.94">​</a></span></a></h3>
<ul>
<li>Vertex: add support for global endpoints for supported models</li>
<li><code v-pre>/memory</code> command now allows direct editing of all imported memory files</li>
<li>SDK: Add custom tools as callbacks</li>
<li>Added <code v-pre>/todos</code> command to list current todo items</li>
</ul>
<p>Aug 28, 2025</p>
<hr>
<h3 id="v1-0-93​" tabindex="-1"><a class="header-anchor" href="#v1-0-93​"><span>v1.0.93<a href="#v1093" title="Direct link to v1.0.93">​</a></span></a></h3>
<ul>
<li>Windows: Add alt + v shortcut for pasting images from clipboard</li>
<li>Support NO_PROXY environment variable to bypass proxy for specified hostnames and IPs</li>
</ul>
<p>Aug 26, 2025</p>
<hr>
<h3 id="v1-0-90​" tabindex="-1"><a class="header-anchor" href="#v1-0-90​"><span>v1.0.90<a href="#v1090" title="Direct link to v1.0.90">​</a></span></a></h3>
<ul>
<li>Settings file changes take effect immediately - no restart required</li>
</ul>
<p>Aug 25, 2025</p>
<hr>
<hr>
<h3 id="v1-0-88​" tabindex="-1"><a class="header-anchor" href="#v1-0-88​"><span>v1.0.88<a href="#v1088" title="Direct link to v1.0.88">​</a></span></a></h3>
<ul>
<li>Fixed issue causing &quot;OAuth authentication is currently not supported&quot;</li>
<li>Status line input now includes <code v-pre>exceeds_200k_tokens</code></li>
<li>Fixed incorrect usage tracking in /cost.</li>
<li>Introduced <code v-pre>ANTHROPIC_DEFAULT_SONNET_MODEL</code> and <code v-pre>ANTHROPIC_DEFAULT_OPUS_MODEL</code> for controlling model aliases opusplan, opus, and sonnet.</li>
<li>Bedrock: Updated default Sonnet model to Sonnet 4</li>
</ul>
<p>Aug 22, 2025</p>
<hr>
<h3 id="v1-0-86​" tabindex="-1"><a class="header-anchor" href="#v1-0-86​"><span>v1.0.86<a href="#v1086" title="Direct link to v1.0.86">​</a></span></a></h3>
<ul>
<li>Added /context to help users self-serve debug context issues</li>
<li>SDK: Added UUID support for all SDK messages</li>
<li>SDK: Added <code v-pre>--replay-user-messages</code> to replay user messages back to stdout</li>
</ul>
<p>Aug 21, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-85​" tabindex="-1"><a class="header-anchor" href="#v1-0-85​"><span>v1.0.85<a href="#v1085" title="Direct link to v1.0.85">​</a></span></a></h3>
<ul>
<li>Status line input now includes session cost info</li>
</ul>
<p>Aug 20, 2025</p>
<hr>
<h3 id="v1-0-84​" tabindex="-1"><a class="header-anchor" href="#v1-0-84​"><span>v1.0.84<a href="#v1084" title="Direct link to v1.0.84">​</a></span></a></h3>
<ul>
<li>Fix tool_use/tool_result id mismatch error when network is unstable</li>
<li>Fix Claude sometimes ignoring real-time steering when wrapping up a task</li>
<li>@-mention: Add ~/.claude/* files to suggestions for easier agent, output style, and slash command editing</li>
<li>Use built-in ripgrep by default; to opt out of this behavior, set USE_BUILTIN_RIPGREP=0</li>
</ul>
<p>Aug 19, 2025</p>
<hr>
<h3 id="v1-0-83​" tabindex="-1"><a class="header-anchor" href="#v1-0-83​"><span>v1.0.83<a href="#v1083" title="Direct link to v1.0.83">​</a></span></a></h3>
<ul>
<li>Auto-complete: allow mentioning ~/.claude/* files</li>
<li>New shimmering spinner</li>
</ul>
<p>Aug 18, 2025</p>
<hr>
<h3 id="v1-0-82​" tabindex="-1"><a class="header-anchor" href="#v1-0-82​"><span>v1.0.82<a href="#v1082" title="Direct link to v1.0.82">​</a></span></a></h3>
<ul>
<li>SDK: Add request cancellation support</li>
<li>SDK: New additionalDirectories option to search custom paths, improved slash command processing</li>
<li>Settings: Validation prevents invalid fields in .claude/settings.json files</li>
<li>MCP: Improve tool name consistency</li>
<li>Bash: Fix crash when Claude tries to automatically read large files</li>
</ul>
<p>Aug 16, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a>|<RouteLink to="/configuration/">Configuration</RouteLink>|<RouteLink to="/faqs/what-is-mcp-server-in-claude-code/">MCP Servers</RouteLink></p>
<hr>
<h3 id="v1-0-81​" tabindex="-1"><a class="header-anchor" href="#v1-0-81​"><span>v1.0.81<a href="#v1081" title="Direct link to v1.0.81">​</a></span></a></h3>
<ul>
<li>Released output styles, including new built-in educational output styles &quot;Explanatory&quot; and &quot;Learning&quot;</li>
<li>Agents: Fix custom agent loading when agent files are unparsable</li>
</ul>
<p>Aug 14, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/output-styles" target="_blank" rel="noopener noreferrer">Output Styles</a></p>
<hr>
<h3 id="v1-0-80​" tabindex="-1"><a class="header-anchor" href="#v1-0-80​"><span>v1.0.80<a href="#v1080" title="Direct link to v1.0.80">​</a></span></a></h3>
<ul>
<li>UI improvements: Fix text contrast for custom subagent colors and spinner rendering issues</li>
</ul>
<p>Aug 14, 2025</p>
<hr>
<hr>
<h3 id="v1-0-77​" tabindex="-1"><a class="header-anchor" href="#v1-0-77​"><span>v1.0.77<a href="#v1077" title="Direct link to v1.0.77">​</a></span></a></h3>
<ul>
<li>Bash tool: Fix heredoc and multiline string escaping, improve stderr redirection handling</li>
<li>SDK: Add session support and permission denial tracking</li>
<li>Fix token limit errors in conversation summarization</li>
<li>Opus Plan Mode: New setting in <code v-pre>/model</code> to run Opus only in plan mode, Sonnet otherwise</li>
</ul>
<p>Aug 13, 2025|See Also: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-73​" tabindex="-1"><a class="header-anchor" href="#v1-0-73​"><span>v1.0.73<a href="#v1073" title="Direct link to v1.0.73">​</a></span></a></h3>
<ul>
<li>MCP: Support multiple config files with <code v-pre>--mcp-config file1.json file2.json</code></li>
<li>MCP: Press Esc to cancel OAuth authentication flows</li>
<li>Bash: Improved command validation and reduced false security warnings</li>
<li>UI: Enhanced spinner animations and status line visual hierarchy</li>
<li>Linux: Added support for Alpine and musl-based distributions (requires separate ripgrep installation)</li>
</ul>
<p>Aug 12, 2025|See Also: <RouteLink to="/faqs/what-is-mcp-server-in-claude-code/">MCP Servers</RouteLink></p>
<hr>
<h3 id="v1-0-72​" tabindex="-1"><a class="header-anchor" href="#v1-0-72​"><span>v1.0.72<a href="#v1072" title="Direct link to v1.0.72">​</a></span></a></h3>
<ul>
<li>Ask permissions: have Claude Code always ask for confirmation to use specific tools with <code v-pre>/permissions</code></li>
</ul>
<p>Aug 12, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-71​" tabindex="-1"><a class="header-anchor" href="#v1-0-71​"><span>v1.0.71<a href="#v1071" title="Direct link to v1.0.71">​</a></span></a></h3>
<ul>
<li>Background commands: (Ctrl-b) to run any Bash command in the background so Claude can keep working (great for dev servers, tailing logs, etc.)</li>
<li>Customizable status line: add your terminal prompt to Claude Code with <code v-pre>/statusline</code></li>
</ul>
<p>Aug 8, 2025|See Also: <RouteLink to="/faqs/what-are-background-commands/">Background Commands</RouteLink>|<RouteLink to="/faqs/status-line-claude-code/">Customizable Status Line</RouteLink></p>
<hr>
<h3 id="v1-0-70​" tabindex="-1"><a class="header-anchor" href="#v1-0-70​"><span>v1.0.70<a href="#v1070" title="Direct link to v1.0.70">​</a></span></a></h3>
<ul>
<li>Performance: Optimized message rendering for better performance with large contexts</li>
<li>Windows: Fixed native file search, ripgrep, and subagent functionality</li>
<li>Added support for @-mentions in slash command arguments</li>
</ul>
<p>Aug 7, 2025|See Also: <RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink>|<RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink></p>
<hr>
<hr>
<h3 id="v1-0-69​" tabindex="-1"><a class="header-anchor" href="#v1-0-69​"><span>v1.0.69<a href="#v1069" title="Direct link to v1.0.69">​</a></span></a></h3>
<ul>
<li>Upgraded Opus to version 4.1</li>
</ul>
<p>05/08/2025|See Also: <RouteLink to="/faqs/what-is-claude-4-1-opus/">Claude 4.1 Opus</RouteLink></p>
<hr>
<h3 id="v1-0-68​" tabindex="-1"><a class="header-anchor" href="#v1-0-68​"><span>v1.0.68<a href="#v1068" title="Direct link to v1.0.68">​</a></span></a></h3>
<ul>
<li>Fix incorrect model names being used for certain commands like <code v-pre>/pr-comments</code></li>
<li>Windows: improve permissions checks for allow / deny tools and project trust. This may create a new project entry in <code v-pre>.claude.json</code> - manually merge the history field if desired.</li>
<li>Windows: improve sub-process spawning to eliminate &quot;No such file or directory&quot; when running commands like pnpm</li>
<li>Enhanced <code v-pre>/doctor</code> command with CLAUDE.md and MCP tool context for self-serve debugging</li>
<li>SDK: Added canUseTool callback support for tool confirmation</li>
<li>Added <code v-pre>disableAllHooks</code> setting</li>
<li>Improved file suggestions performance in large repos</li>
</ul>
<p>05/08/2025|See Also: <RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<RouteLink to="/mechanics/hooks/">Hooks</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-65​" tabindex="-1"><a class="header-anchor" href="#v1-0-65​"><span>v1.0.65<a href="#v1065" title="Direct link to v1.0.65">​</a></span></a></h3>
<ul>
<li>IDE: Fixed connection stability issues and error handling for diagnostics</li>
<li>Windows: Fixed shell environment setup for users without .bashrc files</li>
</ul>
<p>01/08/25|See Also: <RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink></p>
<hr>
<h3 id="v1-0-64​" tabindex="-1"><a class="header-anchor" href="#v1-0-64​"><span>v1.0.64<a href="#v1064" title="Direct link to v1.0.64">​</a></span></a></h3>
<ul>
<li>Agents: Added model customization support - you can now specify which model an agent should use</li>
<li>Agents: Fixed unintended access to the recursive agent tool</li>
<li>Hooks: Added systemMessage field to hook JSON output for displaying warnings and context</li>
<li>SDK: Fixed user input tracking across multi-turn conversations</li>
<li>Added hidden files to file search and @-mention suggestions</li>
</ul>
<p>July 30, 2025|See Also: <RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink>|<RouteLink to="/mechanics/hooks/">Hooks</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-63​" tabindex="-1"><a class="header-anchor" href="#v1-0-63​"><span>v1.0.63<a href="#v1063" title="Direct link to v1.0.63">​</a></span></a></h3>
<ul>
<li>Windows: Fixed file search, @agent mentions, and custom slash commands functionality</li>
</ul>
<p>July 29, 2025|See Also: <RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink>|<RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink></p>
<hr>
<h3 id="v1-0-62​" tabindex="-1"><a class="header-anchor" href="#v1-0-62​"><span>v1.0.62<a href="#v1062" title="Direct link to v1.0.62">​</a></span></a></h3>
<ul>
<li>Added @-mention support with typeahead for custom agents. @&lt;your-custom-agent&gt; to invoke it</li>
<li>Hooks: Added SessionStart hook for new session initialization</li>
<li>/add-dir command now supports typeahead for directory paths</li>
<li>Improved network connectivity check reliability</li>
</ul>
<p>July 28, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/subagents" target="_blank" rel="noopener noreferrer">Custom Subagents</a>|<RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-61​" tabindex="-1"><a class="header-anchor" href="#v1-0-61​"><span>v1.0.61<a href="#v1061" title="Direct link to v1.0.61">​</a></span></a></h3>
<ul>
<li>Transcript mode (Ctrl+R): Changed Esc to exit transcript mode rather than interrupt</li>
<li>Settings: Added <code v-pre>--settings</code> flag to load settings from a JSON file</li>
<li>Settings: Fixed resolution of settings files paths that are symlinks</li>
<li>OTEL: Fixed reporting of wrong organization after authentication changes</li>
<li>Slash commands: Fixed permissions checking for allowed-tools with Bash</li>
<li>IDE: Added support for pasting images in VSCode MacOS using ⌘+V</li>
<li>IDE: Added <code v-pre>CLAUDE_CODE_AUTO_CONNECT_IDE=false</code> for disabling IDE auto-connection</li>
<li>Added <code v-pre>CLAUDE_CODE_SHELL_PREFIX</code> for wrapping Claude and user-provided shell commands run by Claude Code</li>
</ul>
<p>July 25, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink>|<RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink></p>
<hr>
<h3 id="v1-0-60​" tabindex="-1"><a class="header-anchor" href="#v1-0-60​"><span>v1.0.60<a href="#v1060" title="Direct link to v1.0.60">​</a></span></a></h3>
<ul>
<li>You can now create custom subagents for specialized tasks! Run /agents to get started</li>
</ul>
<p>July 24, 2025|See Also: <RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/subagents" target="_blank" rel="noopener noreferrer">Custom Subagents</a></p>
<hr>
<hr>
<h3 id="v1-0-59​" tabindex="-1"><a class="header-anchor" href="#v1-0-59​"><span>v1.0.59<a href="#v1059" title="Direct link to v1.0.59">​</a></span></a></h3>
<ul>
<li>SDK: Added tool confirmation support with canUseTool callback</li>
<li>SDK: Allow specifying env for spawned process</li>
<li>Hooks: Exposed PermissionDecision to hooks (including &quot;ask&quot;)</li>
<li>Hooks: UserPromptSubmit now supports additionalContext in advanced JSON output</li>
<li>Fixed issue where some Max users that specified Opus would still see fallback to Sonnet</li>
</ul>
<p>July 23, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a>|<RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-58​" tabindex="-1"><a class="header-anchor" href="#v1-0-58​"><span>v1.0.58<a href="#v1058" title="Direct link to v1.0.58">​</a></span></a></h3>
<ul>
<li>Added support for reading PDFs</li>
<li>MCP: Improved server health status display in 'claude mcp list'</li>
<li>Hooks: Added CLAUDE_PROJECT_DIR env var for hook commands</li>
</ul>
<p>July 23, 2025|See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink>|<RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-57​" tabindex="-1"><a class="header-anchor" href="#v1-0-57​"><span>v1.0.57<a href="#v1057" title="Direct link to v1.0.57">​</a></span></a></h3>
<ul>
<li>Added support for specifying a model in slash commands</li>
<li>Improved permission messages to help Claude understand allowed tools</li>
<li>Fix: Remove trailing newlines from bash output in terminal wrapping</li>
</ul>
<p>July 23, 2025|See Also: <RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink>|<RouteLink to="/mechanics/auto-accept-permissions/">Auto-Accept Permissions</RouteLink></p>
<hr>
<h3 id="v1-0-56​" tabindex="-1"><a class="header-anchor" href="#v1-0-56​"><span>v1.0.56<a href="#v1056" title="Direct link to v1.0.56">​</a></span></a></h3>
<ul>
<li>Windows: Enabled shift+tab for mode switching on versions of Node.js that support terminal VT mode</li>
<li>Fixes for WSL IDE detection</li>
<li>Fix an issue causing awsRefreshHelper changes to .aws directory not to be picked up</li>
</ul>
<p>July 23, 2025|See Also: <RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-55​" tabindex="-1"><a class="header-anchor" href="#v1-0-55​"><span>v1.0.55<a href="#v1055" title="Direct link to v1.0.55">​</a></span></a></h3>
<ul>
<li>Clarified knowledge cutoff for Opus 4 and Sonnet 4 models</li>
<li>Windows: fixed Ctrl+Z crash</li>
<li>SDK: Added ability to capture error logging</li>
<li>Add --system-prompt-file option to override system prompt in print mode</li>
</ul>
<p>July 23, 2025|See Also: <RouteLink to="/model-comparison/">Model Comparison</RouteLink>|<RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-54​" tabindex="-1"><a class="header-anchor" href="#v1-0-54​"><span>v1.0.54<a href="#v1054" title="Direct link to v1.0.54">​</a></span></a></h3>
<ul>
<li>Hooks: Added UserPromptSubmit hook and the current working directory to hook inputs</li>
<li>Custom slash commands: Added argument-hint to frontmatter</li>
<li>Windows: OAuth uses port 45454 and properly constructs browser URL</li>
<li>Windows: mode switching now uses alt + m, and plan mode renders properly</li>
<li>Shell: Switch to in-memory shell snapshot to file-related errors</li>
</ul>
<p>July 19, 2025|See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink>|<RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink>|<RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink></p>
<hr>
<h3 id="v1-0-53​" tabindex="-1"><a class="header-anchor" href="#v1-0-53​"><span>v1.0.53<a href="#v1053" title="Direct link to v1.0.53">​</a></span></a></h3>
<ul>
<li>Updated @-mention file truncation from 100 lines to 2000 lines</li>
<li>Add helper script settings for AWS token refresh: awsAuthRefresh (for foreground operations like aws sso login) and awsCredentialExport (for background operation with STS-like response).</li>
</ul>
<p>July 18, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-52​" tabindex="-1"><a class="header-anchor" href="#v1-0-52​"><span>v1.0.52<a href="#v1052" title="Direct link to v1.0.52">​</a></span></a></h3>
<ul>
<li>Added support for MCP server instructions</li>
</ul>
<p>July 18, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-51​" tabindex="-1"><a class="header-anchor" href="#v1-0-51​"><span>v1.0.51<a href="#v1051" title="Direct link to v1.0.51">​</a></span></a></h3>
<ul>
<li>Added support for native Windows (requires Git for Windows)</li>
<li>Added support for Bedrock API keys through environment variable AWS_BEARER_TOKEN_BEDROCK</li>
<li>Settings: /doctor can now help you identify and fix invalid setting files</li>
<li><code v-pre>--append-system-prompt</code> can now be used in interactive mode, not just --print/-p.</li>
<li>Increased auto-compact warning threshold from 60% to 80%</li>
<li>Fixed an issue with handling user directories with spaces for shell snapshots</li>
<li>OTEL resource now includes os.type, os.version, host.arch, and wsl.version (if running on Windows Subsystem for Linux)</li>
<li>Custom slash commands: Fixed user-level commands in subdirectories</li>
<li>Plan mode: Fixed issue where rejected plan from sub-task would get discarded</li>
</ul>
<p>July 11, 2025|See Also: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<RouteLink to="/faqs/how-to-install-claude-code-on-windows/">Windows Installation</RouteLink>|<RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink></p>
<hr>
<hr>
<h3 id="v1-0-48​" tabindex="-1"><a class="header-anchor" href="#v1-0-48​"><span>v1.0.48<a href="#v1048" title="Direct link to v1.0.48">​</a></span></a></h3>
<ul>
<li>Fixed a bug in <a href="#v1045">v1.0.45</a> where the app would sometimes freeze on launch</li>
<li>Added progress messages to Bash tool based on the last 5 lines of command output</li>
<li>Added expanding variables support for MCP server configuration</li>
<li>Moved shell snapshots from /tmp to ~/.claude for more reliable Bash tool calls</li>
<li>Improved IDE extension path handling when Claude Code runs in WSL</li>
<li>Hooks: Added a PreCompact hook</li>
<li>Vim mode: Added c, f/F, t/T</li>
</ul>
<p>July 10, 2025|See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-45​" tabindex="-1"><a class="header-anchor" href="#v1-0-45​"><span>v1.0.45<a href="#v1045" title="Direct link to v1.0.45">​</a></span></a></h3>
<ul>
<li>Redesigned Search (Grep) tool with new tool input parameters and features</li>
<li>Disabled IDE diffs for notebook files, fixing &quot;Timeout waiting after 1000ms&quot; error</li>
<li>Fixed config file corruption issue by enforcing atomic writes</li>
<li>Updated prompt input undo to Ctrl+_ to avoid breaking existing Ctrl+U behavior, matching zsh's undo shortcut</li>
<li>Stop Hooks: Fixed transcript path after /clear and fixed triggering when loop ends with tool call</li>
<li>Custom slash commands: Restored namespacing in command names based on subdirectories. For example, .claude/frontend/component.md is now /frontend:component, not /component.</li>
</ul>
<p>July 9, 2025|See Also: <RouteLink to="/faqs/what-is-slash-commands-in-claude-code/">Custom Slash Commands</RouteLink>|<RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-44​" tabindex="-1"><a class="header-anchor" href="#v1-0-44​"><span>v1.0.44<a href="#v1044" title="Direct link to v1.0.44">​</a></span></a></h3>
<ul>
<li>New <code v-pre>/export</code> command lets you quickly export a conversation for sharing</li>
<li>MCP: resource_link tool results are now supported</li>
<li>MCP: tool annotations and tool titles now display in /mcp view</li>
<li>Changed Ctrl+Z to suspend Claude Code. Resume by running <code v-pre>fg</code>. Prompt input undo is now Ctrl+U.</li>
</ul>
<p>July 7, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs</RouteLink>|<RouteLink to="/faqs/how-to-suspend-claude-code/">Suspend/Resume</RouteLink></p>
<hr>
<h3 id="v1-0-43​" tabindex="-1"><a class="header-anchor" href="#v1-0-43​"><span>v1.0.43<a href="#v1043" title="Direct link to v1.0.43">​</a></span></a></h3>
<ul>
<li>Fixed a bug where the theme selector was saving excessively</li>
<li>Hooks: Added EPIPE system error handling</li>
</ul>
<p>July 3, 2025|See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-42​" tabindex="-1"><a class="header-anchor" href="#v1-0-42​"><span>v1.0.42<a href="#v1042" title="Direct link to v1.0.42">​</a></span></a></h3>
<ul>
<li>Added tilde (<code v-pre>~</code>) expansion support to <code v-pre>/add-dir</code> command</li>
</ul>
<p>July 3, 2025|See Also: <RouteLink to="/faqs/--add-dir/">/add-dir FAQ</RouteLink></p>
<hr>
<h3 id="v1-0-41​" tabindex="-1"><a class="header-anchor" href="#v1-0-41​"><span>v1.0.41<a href="#v1041" title="Direct link to v1.0.41">​</a></span></a></h3>
<ul>
<li>Hooks: Split Stop hook triggering into Stop and SubagentStop</li>
<li>Hooks: Enabled optional timeout configuration for each command</li>
<li>Hooks: Added &quot;hook_event_name&quot; to hook input</li>
<li>Fixed a bug where MCP tools would display twice in tool list</li>
<li>New tool parameters JSON for Bash tool in <code v-pre>tool_decision</code> event</li>
</ul>
<p>See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-40​" tabindex="-1"><a class="header-anchor" href="#v1-0-40​"><span>v1.0.40<a href="#v1040" title="Direct link to v1.0.40">​</a></span></a></h3>
<ul>
<li>Fixed a bug causing API connection errors with UNABLE_TO_GET_ISSUER_CERT_LOCALLY if <code v-pre>NODE_EXTRA_CA_CERTS</code> was set</li>
</ul>
<hr>
<hr>
<h3 id="v1-0-39​" tabindex="-1"><a class="header-anchor" href="#v1-0-39​"><span>v1.0.39<a href="#v1039" title="Direct link to v1.0.39">​</a></span></a></h3>
<ul>
<li>New Active Time metric in OpenTelemetry logging</li>
</ul>
<p>July 2, 2025</p>
<hr>
<h3 id="v1-0-38​" tabindex="-1"><a class="header-anchor" href="#v1-0-38​"><span>v1.0.38<a href="#v1038" title="Direct link to v1.0.38">​</a></span></a></h3>
<ul>
<li>Released <a href="https://docs.anthropic.com/en/docs/claude-code/hooks" target="_blank" rel="noopener noreferrer">hooks</a>. Special thanks to community input in <a href="https://github.com/anthropics/claude-code/issues/712" target="_blank" rel="noopener noreferrer">Github Issues</a></li>
</ul>
<p>July 2, 2025|See Also: <RouteLink to="/mechanics/hooks/">Hooks</RouteLink></p>
<hr>
<h3 id="v1-0-37​" tabindex="-1"><a class="header-anchor" href="#v1-0-37​"><span>v1.0.37<a href="#v1037" title="Direct link to v1.0.37">​</a></span></a></h3>
<ul>
<li>Remove ability to set <code v-pre>Proxy-Authorization</code> header via ANTHROPIC_AUTH_TOKEN or apiKeyHelper</li>
</ul>
<p>July 2, 2025</p>
<hr>
<h3 id="v1-0-36​" tabindex="-1"><a class="header-anchor" href="#v1-0-36​"><span>v1.0.36<a href="#v1036" title="Direct link to v1.0.36">​</a></span></a></h3>
<ul>
<li>Web search now takes today's date into context</li>
<li>Fixed a bug where stdio MCP servers were not terminating properly on exit</li>
</ul>
<p>July 2, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-35​" tabindex="-1"><a class="header-anchor" href="#v1-0-35​"><span>v1.0.35<a href="#v1035" title="Direct link to v1.0.35">​</a></span></a></h3>
<ul>
<li>Added support for MCP OAuth Authorization Server discovery</li>
</ul>
<p>June 25, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-34​" tabindex="-1"><a class="header-anchor" href="#v1-0-34​"><span>v1.0.34<a href="#v1034" title="Direct link to v1.0.34">​</a></span></a></h3>
<ul>
<li>Fixed a memory leak causing a MaxListenersExceededWarning message to appear</li>
</ul>
<p>June 24, 2025</p>
<hr>
<h3 id="v1-0-33​" tabindex="-1"><a class="header-anchor" href="#v1-0-33​"><span>v1.0.33<a href="#v1033" title="Direct link to v1.0.33">​</a></span></a></h3>
<ul>
<li>Improved logging functionality with session ID support</li>
<li>Added undo functionality (Ctrl+Z and vim 'u' command)</li>
<li>Improvements to plan mode</li>
</ul>
<p>June 24, 2025|See Also: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink></p>
<hr>
<h3 id="v1-0-32​" tabindex="-1"><a class="header-anchor" href="#v1-0-32​"><span>v1.0.32<a href="#v1032" title="Direct link to v1.0.32">​</a></span></a></h3>
<ul>
<li>Updated loopback config for litellm</li>
<li>Added forceLoginMethod setting to bypass login selection screen</li>
</ul>
<p>June 24, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-31​" tabindex="-1"><a class="header-anchor" href="#v1-0-31​"><span>v1.0.31<a href="#v1031" title="Direct link to v1.0.31">​</a></span></a></h3>
<ul>
<li>Fixed a bug where ~/.claude.json would get reset when file contained invalid JSON</li>
</ul>
<p>June 24, 2025</p>
<hr>
<h3 id="v1-0-30​" tabindex="-1"><a class="header-anchor" href="#v1-0-30​"><span>v1.0.30<a href="#v1030" title="Direct link to v1.0.30">​</a></span></a></h3>
<ul>
<li>Custom slash commands: Run bash output, @-mention files, enable thinking with thinking keywords</li>
<li>Improved file path autocomplete with filename matching</li>
<li>Added timestamps in Ctrl-r mode and fixed Ctrl-c handling</li>
<li>Enhanced jq regex support for complex filters with pipes and select</li>
</ul>
<p>June 24, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/slash-commands" target="_blank" rel="noopener noreferrer">Slash Commands</a></p>
<hr>
<hr>
<h3 id="v1-0-29​" tabindex="-1"><a class="header-anchor" href="#v1-0-29​"><span>v1.0.29<a href="#v1029" title="Direct link to v1.0.29">​</a></span></a></h3>
<ul>
<li>Improved CJK character support in cursor navigation and rendering</li>
</ul>
<p>June 24, 2025</p>
<hr>
<h3 id="v1-0-28​" tabindex="-1"><a class="header-anchor" href="#v1-0-28​"><span>v1.0.28<a href="#v1028" title="Direct link to v1.0.28">​</a></span></a></h3>
<ul>
<li>Slash commands: Fix selector display during history navigation</li>
<li>Resizes images before upload to prevent API size limit errors</li>
<li>Added XDG_CONFIG_HOME support to configuration directory</li>
<li>Performance optimizations for memory usage</li>
<li>New attributes (terminal.type, language) in OpenTelemetry logging</li>
</ul>
<p>June 24, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/settings" target="_blank" rel="noopener noreferrer">Configuration</a></p>
<hr>
<h3 id="v1-0-27​" tabindex="-1"><a class="header-anchor" href="#v1-0-27​"><span>v1.0.27<a href="#v1027" title="Direct link to v1.0.27">​</a></span></a></h3>
<ul>
<li>Streamable HTTP MCP servers are now supported</li>
<li>Remote MCP servers (SSE and HTTP) now support OAuth</li>
<li>MCP resources can now be @-mentioned</li>
</ul>
<p>June 18, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/mcp#use-mcp-resources" target="_blank" rel="noopener noreferrer">MCP Resources</a></p>
<hr>
<h3 id="v1-0-25​" tabindex="-1"><a class="header-anchor" href="#v1-0-25​"><span>v1.0.25<a href="#v1025" title="Direct link to v1.0.25">​</a></span></a></h3>
<ul>
<li>Slash commands: moved &quot;project&quot; and &quot;user&quot; prefixes to descriptions</li>
<li>Slash commands: improved reliability for command discovery</li>
<li>Improved support for Ghostty</li>
<li>Improved web search reliability</li>
</ul>
<p>June 16, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/slash-commands" target="_blank" rel="noopener noreferrer">Slash Commands</a></p>
<hr>
<h3 id="v1-0-24​" tabindex="-1"><a class="header-anchor" href="#v1-0-24​"><span>v1.0.24<a href="#v1024" title="Direct link to v1.0.24">​</a></span></a></h3>
<ul>
<li>Improved <code v-pre>/mcp</code> output</li>
<li>Fixed a bug where settings arrays got overwritten instead of merged</li>
</ul>
<p>June 16, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-23​" tabindex="-1"><a class="header-anchor" href="#v1-0-23​"><span>v1.0.23<a href="#v1023" title="Direct link to v1.0.23">​</a></span></a></h3>
<ul>
<li>Released TypeScript SDK: <code v-pre>import @anthropic-ai/claude-code</code> to get started</li>
<li>Released Python SDK: <code v-pre>pip install claude-code-sdk</code> to get started</li>
</ul>
<p>June 16, 2025|See Also: <a href="https://docs.anthropic.com/en/docs/claude-code/sdk" target="_blank" rel="noopener noreferrer">Claude Code SDK</a></p>
<hr>
<h3 id="v1-0-22​" tabindex="-1"><a class="header-anchor" href="#v1-0-22​"><span>v1.0.22<a href="#v1022" title="Direct link to v1.0.22">​</a></span></a></h3>
<ul>
<li>SDK: Renamed <code v-pre>total_cost</code> to <code v-pre>total_cost_usd</code></li>
</ul>
<p>June 12, 2025|See Also: <RouteLink to="/claude-code-mcps/cc-usage/">CC Usage</RouteLink></p>
<hr>
<h3 id="v1-0-21​" tabindex="-1"><a class="header-anchor" href="#v1-0-21​"><span>v1.0.21<a href="#v1021" title="Direct link to v1.0.21">​</a></span></a></h3>
<ul>
<li>Improved editing of files with tab-based indentation</li>
<li>Fix for <code v-pre>tool_use</code> without matching <code v-pre>tool_result</code> errors</li>
<li>Fixed a bug where stdio MCP server processes would linger after quitting Claude Code</li>
</ul>
<p>June 12, 2025</p>
<hr>
<hr>
<h3 id="v1-0-18​" tabindex="-1"><a class="header-anchor" href="#v1-0-18​"><span>v1.0.18<a href="#v1018" title="Direct link to v1.0.18">​</a></span></a></h3>
<ul>
<li>Added <code v-pre>--add-dir</code> CLI argument for specifying additional working directories</li>
<li>Added streaming input support without require <code v-pre>-p</code> flag</li>
<li>Improved startup performance and session storage performance</li>
<li>Added <code v-pre>CLAUDE_BASH_MAINTAIN_PROJECT_WORKING_DIR</code> environment variable to freeze working directory for bash commands</li>
<li>Added detailed MCP server tools display (<code v-pre>/mcp</code>)</li>
<li>MCP authentication and permission improvements</li>
<li>Added auto-reconnection for MCP SSE connections on disconnect</li>
<li>Fixed issue where pasted content was lost when dialogs appeared</li>
</ul>
<p>June 10, 2025|See Also: <RouteLink to="/configuration/#mcp-configuration">Configuration</RouteLink>|<a href="https://docs.anthropic.com/en/docs/claude-code/common-workflows#additional-working-directories" target="_blank" rel="noopener noreferrer">Additional Working Directories</a>|<RouteLink to="/claude-code-mcps/">MCPs</RouteLink></p>
<hr>
<h3 id="v1-0-17​" tabindex="-1"><a class="header-anchor" href="#v1-0-17​"><span>v1.0.17<a href="#v1017" title="Direct link to v1.0.17">​</a></span></a></h3>
<ul>
<li>We now emit messages from sub-tasks in <code v-pre>-p</code> mode</li>
</ul>
<p>June 10, 2025</p>
<hr>
<h3 id="v1-0-16​" tabindex="-1"><a class="header-anchor" href="#v1-0-16​"><span>v1.0.16<a href="#v1016" title="Direct link to v1.0.16">​</a></span></a></h3>
<ul>
<li>Additional improvements and bug fixes (look for the <code v-pre>parent_tool_use_id</code> property)</li>
<li>Fixed crashes when the VS Code diff tool is invoked multiple times quickly</li>
<li>MCP server list UI improvements</li>
<li>Update Claude Code process title to display <code v-pre>claude</code> instead of <code v-pre>node</code></li>
</ul>
<p>June 6, 2025</p>
<hr>
<h3 id="v1-0-11​" tabindex="-1"><a class="header-anchor" href="#v1-0-11​"><span>v1.0.11<a href="#v1011" title="Direct link to v1.0.11">​</a></span></a></h3>
<ul>
<li>Claude Code can now also be used with a Claude Pro subscription</li>
<li>Added <code v-pre>/upgrade</code> for smoother switching to Claude Max plans</li>
<li>Improved UI for authentication from API keys and Bedrock/Vertex/external auth tokens</li>
<li>Improved shell configuration error handling</li>
<li>Improved todo list handling during compaction</li>
</ul>
<p>June 4, 2025|See Also: <RouteLink to="/claude-code-pricing/">Pricing</RouteLink>|<RouteLink to="/model-comparison/">Model Comparison</RouteLink>|<RouteLink to="/install-claude-code/">Installation</RouteLink></p>
<hr>
<h3 id="v1-0-10​" tabindex="-1"><a class="header-anchor" href="#v1-0-10​"><span>v1.0.10<a href="#v1010" title="Direct link to v1.0.10">​</a></span></a></h3>
<ul>
<li>Added markdown table support</li>
<li>Improved streaming performance</li>
</ul>
<p>June 3, 2025</p>
<hr>
<h3 id="v1-0-8​" tabindex="-1"><a class="header-anchor" href="#v1-0-8​"><span>v1.0.8<a href="#v108" title="Direct link to v1.0.8">​</a></span></a></h3>
<ul>
<li>Fixed Vertex AI region fallback when using <code v-pre>CLOUD_ML_REGION</code></li>
<li>Increased default otel interval from 1s -&gt; 5s</li>
<li>Fixed edge cases where <code v-pre>MCP_TIMEOUT</code> and <code v-pre>MCP_TOOL_TIMEOUT</code> weren't being respected</li>
<li>Fixed a regression where search tools unnecessarily asked for permissions</li>
<li>Added support for triggering thinking non-English languages</li>
<li>Improved compacting UI</li>
</ul>
<p>June 2, 2025|See Also: <RouteLink to="/faqs/restarting-claude-code/">Restarting Claude Code</RouteLink>|<RouteLink to="/mechanics/context-window-depletion/">Context Window Depletion</RouteLink></p>
<hr>
<h3 id="v1-0-7​" tabindex="-1"><a class="header-anchor" href="#v1-0-7​"><span>v1.0.7<a href="#v107" title="Direct link to v1.0.7">​</a></span></a></h3>
<ul>
<li>Renamed <code v-pre>/allowed-tools</code> -&gt; <code v-pre>/permissions</code></li>
<li>Migrated <code v-pre>allowedTools</code> and <code v-pre>ignorePatterns</code> from <code v-pre>.claude.json</code> -&gt; <code v-pre>settings.json</code></li>
<li>Deprecated <code v-pre>claude config</code> commands in favor of editing <code v-pre>settings.json</code></li>
<li>Fixed a bug where <code v-pre>--dangerously-skip-permissions</code> sometimes didn't work in <code v-pre>--print</code> mode</li>
<li>Improved error handling for <code v-pre>/install-github-app</code></li>
<li>Bugfixes, UI polish, and tool reliability improvements</li>
</ul>
<p>June 2, 2025|See Also: <RouteLink to="/mechanics/auto-accept-permissions/">Auto-Accept Permissions</RouteLink>|<RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-6​" tabindex="-1"><a class="header-anchor" href="#v1-0-6​"><span>v1.0.6<a href="#v106" title="Direct link to v1.0.6">​</a></span></a></h3>
<ul>
<li>Improved edit reliability for tab-indented files</li>
<li>Respect <code v-pre>CLAUDE_CONFIG_DIR</code> everywhere</li>
<li>Reduced unnecessary tool permission prompts</li>
<li>Added support for symlinks in <code v-pre>@file</code> typeahead</li>
<li>Bugfixes, UI polish, and tool reliability improvements</li>
</ul>
<p>June 2, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v1-0-4​" tabindex="-1"><a class="header-anchor" href="#v1-0-4​"><span>v1.0.4<a href="#v104" title="Direct link to v1.0.4">​</a></span></a></h3>
<ul>
<li>Fixed a bug where MCP tool errors weren't being parsed correctly</li>
</ul>
<p>May 28, 2025</p>
<hr>
<h3 id="v1-0-1​" tabindex="-1"><a class="header-anchor" href="#v1-0-1​"><span>v1.0.1<a href="#v101" title="Direct link to v1.0.1">​</a></span></a></h3>
<ul>
<li>Added <code v-pre>DISABLE_INTERLEAVED_THINKING</code> to give users the option to opt out of interleaved thinking</li>
<li>Improved model references to show provider-specific names (Sonnet 3.7 for Bedrock, Sonnet 4 for Console)</li>
<li>Updated documentation links and OAuth process descriptions</li>
</ul>
<p>May 22, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<hr>
<h3 id="v1-0-0​" tabindex="-1"><a class="header-anchor" href="#v1-0-0​"><span>v1.0.0<a href="#v100" title="Direct link to v1.0.0">​</a></span></a></h3>
<ul>
<li>Claude Code is now generally available</li>
<li>Introducing Sonnet 4 and Opus 4 models</li>
</ul>
<p>May 22, 2025|See Also: <RouteLink to="/model-comparison/">Model Comparison</RouteLink>|<RouteLink to="/install-claude-code/">Installation</RouteLink>|<RouteLink to="/claude-code-tutorial/">Getting Started</RouteLink></p>
<hr>
<h3 id="v0-2-125​" tabindex="-1"><a class="header-anchor" href="#v0-2-125​"><span>v0.2.125<a href="#v02125" title="Direct link to v0.2.125">​</a></span></a></h3>
<ul>
<li>Breaking change: Bedrock ARN passed to <code v-pre>ANTHROPIC_MODEL</code> or <code v-pre>ANTHROPIC_SMALL_FAST_MODEL</code> should no longer contain an escaped slash (specify / instead of %2F)</li>
<li>Removed <code v-pre>DEBUG=true</code> in favor of <code v-pre>ANTHROPIC_LOG=debug</code>, to log all requests</li>
</ul>
<p>May 21, 2025|See Also: <RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v0-2-117​" tabindex="-1"><a class="header-anchor" href="#v0-2-117​"><span>v0.2.117<a href="#v02117" title="Direct link to v0.2.117">​</a></span></a></h3>
<ul>
<li>Breaking change: <code v-pre>--print</code> JSON output now returns nested message objects, for forwards-compatibility as we introduce new metadata fields</li>
<li>Introduced <code v-pre>settings.cleanupPeriodDays</code></li>
<li>Introduced <code v-pre>CLAUDE_CODE_API_KEY_HELPER_TTL_MS</code> env var</li>
<li>Introduced <code v-pre>--debug</code> mode</li>
</ul>
<p>May 18, 2025</p>
<hr>
<h3 id="v0-2-108​" tabindex="-1"><a class="header-anchor" href="#v0-2-108​"><span>v0.2.108<a href="#v02108" title="Direct link to v0.2.108">​</a></span></a></h3>
<ul>
<li>You can now send messages to Claude while it works to steer Claude in real-time</li>
<li>Introduced <code v-pre>BASH_DEFAULT_TIMEOUT_MS</code> and <code v-pre>BASH_MAX_TIMEOUT_MS</code> env vars</li>
<li>Fixed a bug where thinking was not working in <code v-pre>-p</code> mode</li>
<li>Fixed a regression in <code v-pre>/cost</code> reporting</li>
<li>Deprecated MCP wizard interface in favor of other MCP commands</li>
<li>Lots of other bugfixes and improvements</li>
</ul>
<p>May 13, 2025</p>
<hr>
<h3 id="v0-2-107​" tabindex="-1"><a class="header-anchor" href="#v0-2-107​"><span>v0.2.107<a href="#v02107" title="Direct link to v0.2.107">​</a></span></a></h3>
<ul>
<li><code v-pre>CLAUDE.md</code> files can now import other files. Add <code v-pre>@path/to/file.md</code> to <code v-pre>./CLAUDE.md</code> to load additional files on launch</li>
</ul>
<p>May 9, 2025|See Also: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink></p>
<hr>
<h3 id="v0-2-106​" tabindex="-1"><a class="header-anchor" href="#v0-2-106​"><span>v0.2.106<a href="#v02106" title="Direct link to v0.2.106">​</a></span></a></h3>
<ul>
<li>MCP SSE server configs can now specify custom headers</li>
<li>Fixed a bug where MCP permission prompt didn't always show correctly</li>
</ul>
<p>May 9, 2025</p>
<hr>
<h3 id="v0-2-105​" tabindex="-1"><a class="header-anchor" href="#v0-2-105​"><span>v0.2.105<a href="#v02105" title="Direct link to v0.2.105">​</a></span></a></h3>
<ul>
<li>Claude can now search the web</li>
<li>Moved system &amp; account status to <code v-pre>/status</code></li>
<li>Added word movement keybindings for Vim</li>
<li>Improved latency for startup, todo tool, and file edits</li>
</ul>
<p>May 8, 2025</p>
<hr>
<h3 id="v0-2-102​" tabindex="-1"><a class="header-anchor" href="#v0-2-102​"><span>v0.2.102<a href="#v02102" title="Direct link to v0.2.102">​</a></span></a></h3>
<ul>
<li>Improved thinking triggering reliability</li>
<li>Improved <code v-pre>@mention</code> reliability for images and folders</li>
<li>You can now paste multiple large chunks into one prompt</li>
</ul>
<p>May 5, 2025</p>
<hr>
<h3 id="v0-2-100​" tabindex="-1"><a class="header-anchor" href="#v0-2-100​"><span>v0.2.100<a href="#v02100" title="Direct link to v0.2.100">​</a></span></a></h3>
<ul>
<li>Fixed a crash caused by a stack overflow error</li>
<li>Made db storage optional; missing db support disables <code v-pre>--continue</code> and <code v-pre>--resume</code></li>
</ul>
<hr>
<h3 id="v0-2-98​" tabindex="-1"><a class="header-anchor" href="#v0-2-98​"><span>v0.2.98<a href="#v0298" title="Direct link to v0.2.98">​</a></span></a></h3>
<ul>
<li>Fixed an issue where auto-compact was running twice</li>
</ul>
<p>May 2, 2025</p>
<hr>
<h3 id="v0-2-95​" tabindex="-1"><a class="header-anchor" href="#v0-2-95​"><span>v0.2.95<a href="#v0295" title="Direct link to v0.2.95">​</a></span></a></h3>
<ul>
<li>Claude Code can now also be used with a <a href="https://claude.ai/upgrade" target="_blank" rel="noopener noreferrer">Claude Max subscription</a></li>
<li>Claude Code can now also be used with a <a href="https://claude.ai/upgrade" target="_blank" rel="noopener noreferrer">Claude Max subscription</a></li>
</ul>
<p>May 1, 2025</p>
<hr>
<h3 id="v0-2-93​" tabindex="-1"><a class="header-anchor" href="#v0-2-93​"><span>v0.2.93<a href="#v0293" title="Direct link to v0.2.93">​</a></span></a></h3>
<ul>
<li>Resume conversations from where you left off from with <code v-pre>claude --continue</code> and <code v-pre>claude --resume</code></li>
<li>Claude now has access to a Todo list that helps it stay on track and be more organized</li>
</ul>
<p>April 30, 2025</p>
<hr>
<h3 id="v0-2-82​" tabindex="-1"><a class="header-anchor" href="#v0-2-82​"><span>v0.2.82<a href="#v0282" title="Direct link to v0.2.82">​</a></span></a></h3>
<ul>
<li>Added support for <code v-pre>--disallowedTools</code></li>
<li>Renamed tools for consistency: <code v-pre>LSTool</code> -&gt; <code v-pre>LS</code>, <code v-pre>View</code> -&gt; <code v-pre>Read</code>, etc.</li>
</ul>
<p>April 25, 2025|See Also: <RouteLink to="/mechanics/auto-accept-permissions/">Auto-Accept Permissions</RouteLink>|<RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v0-2-75​" tabindex="-1"><a class="header-anchor" href="#v0-2-75​"><span>v0.2.75<a href="#v0275" title="Direct link to v0.2.75">​</a></span></a></h3>
<ul>
<li>Hit Enter to queue up additional messages while Claude is working</li>
<li>Drag in or copy/paste image files directly into the prompt</li>
<li><code v-pre>@-mention</code> files to directly add them to context</li>
<li>Run one-off MCP servers with <code v-pre>claude --mcp-config &amp;lt;path-to-file&amp;gt;</code></li>
<li>Improved performance for filename auto-complete</li>
</ul>
<p>April 21, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs &amp; Add-ons</RouteLink>|<RouteLink to="/configuration/#mcp-configuration">Configuration</RouteLink></p>
<hr>
<h3 id="v0-2-7​" tabindex="-1"><a class="header-anchor" href="#v0-2-7​"><span>v0.2.7<a href="#v027" title="Direct link to v0.2.7">​</a></span></a></h3>
<ul>
<li>Additional updates and fixes</li>
<li>Added support for refreshing dynamically generated API keys (via <code v-pre>apiKeyHelper</code>), with a 5 minute TTL</li>
<li>Task tool can now perform writes and run bash commands</li>
</ul>
<p>April 17, 2025</p>
<hr>
<h3 id="v0-2-72​" tabindex="-1"><a class="header-anchor" href="#v0-2-72​"><span>v0.2.72<a href="#v0272" title="Direct link to v0.2.72">​</a></span></a></h3>
<ul>
<li>Updated spinner to indicate tokens loaded and tool usage</li>
</ul>
<p>April 18, 2025</p>
<hr>
<h3 id="v0-2-70​" tabindex="-1"><a class="header-anchor" href="#v0-2-70​"><span>v0.2.70<a href="#v0270" title="Direct link to v0.2.70">​</a></span></a></h3>
<ul>
<li>Network commands like <code v-pre>curl</code> are now available for Claude to use</li>
<li>Claude can now run multiple web queries in parallel</li>
<li>Pressing ESC once immediately interrupts Claude in Auto-accept mode</li>
</ul>
<hr>
<h3 id="v0-2-69​" tabindex="-1"><a class="header-anchor" href="#v0-2-69​"><span>v0.2.69<a href="#v0269" title="Direct link to v0.2.69">​</a></span></a></h3>
<ul>
<li>Fixed UI glitches with improved Select component behavior</li>
<li>Enhanced terminal output display with better text truncation logic</li>
</ul>
<hr>
<h3 id="v0-2-67​" tabindex="-1"><a class="header-anchor" href="#v0-2-67​"><span>v0.2.67<a href="#v0267" title="Direct link to v0.2.67">​</a></span></a></h3>
<ul>
<li>Shared project permission rules can be saved in <code v-pre>.claude/settings.json</code></li>
</ul>
<hr>
<h3 id="v0-2-66​" tabindex="-1"><a class="header-anchor" href="#v0-2-66​"><span>v0.2.66<a href="#v0266" title="Direct link to v0.2.66">​</a></span></a></h3>
<ul>
<li>Print mode (<code v-pre>-p</code>) now supports streaming output via <code v-pre>--output-format=stream-json</code></li>
<li>Fixed issue where pasting could trigger memory or bash mode unexpectedly</li>
</ul>
<hr>
<h3 id="v0-2-63​" tabindex="-1"><a class="header-anchor" href="#v0-2-63​"><span>v0.2.63<a href="#v0263" title="Direct link to v0.2.63">​</a></span></a></h3>
<ul>
<li>Fixed an issue where MCP tools were loaded twice, which caused tool call errors</li>
</ul>
<hr>
<h3 id="v0-2-61​" tabindex="-1"><a class="header-anchor" href="#v0-2-61​"><span>v0.2.61<a href="#v0261" title="Direct link to v0.2.61">​</a></span></a></h3>
<ul>
<li>Navigate menus with vim-style keys (<code v-pre>j</code>/<code v-pre>k</code>) or bash/emacs shortcuts (<code v-pre>Ctrl+n</code>/<code v-pre>p</code>) for faster interaction</li>
<li>Enhanced image detection for more reliable clipboard paste functionality</li>
<li>Fixed an issue where ESC key could crash the conversation history selector</li>
</ul>
<hr>
<h3 id="v0-2-59​" tabindex="-1"><a class="header-anchor" href="#v0-2-59​"><span>v0.2.59<a href="#v0259" title="Direct link to v0.2.59">​</a></span></a></h3>
<ul>
<li>Copy+paste images directly into your prompt</li>
<li>Improved progress indicators for bash and fetch tools</li>
<li>Bugfixes for non-interactive mode (<code v-pre>-p</code>)</li>
</ul>
<hr>
<h3 id="v0-2-54​" tabindex="-1"><a class="header-anchor" href="#v0-2-54​"><span>v0.2.54<a href="#v0254" title="Direct link to v0.2.54">​</a></span></a></h3>
<ul>
<li>Quickly add to Memory by starting your message with <code v-pre>#</code></li>
<li>Press <code v-pre>ctrl+r</code> to see full output for long tool results</li>
<li>Added support for MCP SSE transport</li>
</ul>
<hr>
<h3 id="v0-2-53​" tabindex="-1"><a class="header-anchor" href="#v0-2-53​"><span>v0.2.53<a href="#v0253" title="Direct link to v0.2.53">​</a></span></a></h3>
<ul>
<li>New web fetch tool lets Claude view URLs that you paste in</li>
<li>Fixed a bug with JPEG detection</li>
</ul>
<hr>
<h3 id="v0-2-50​" tabindex="-1"><a class="header-anchor" href="#v0-2-50​"><span>v0.2.50<a href="#v0250" title="Direct link to v0.2.50">​</a></span></a></h3>
<ul>
<li>New MCP &quot;project&quot; scope now allows you to add MCP servers to <code v-pre>.mcp.json</code> files and commit them to your repository</li>
</ul>
<hr>
<h3 id="v0-2-49​" tabindex="-1"><a class="header-anchor" href="#v0-2-49​"><span>v0.2.49<a href="#v0249" title="Direct link to v0.2.49">​</a></span></a></h3>
<ul>
<li>Previous MCP server scopes have been renamed: previous &quot;project&quot; scope is now &quot;local&quot; and &quot;global&quot; scope is now &quot;user&quot;</li>
</ul>
<hr>
<h3 id="v0-2-47​" tabindex="-1"><a class="header-anchor" href="#v0-2-47​"><span>v0.2.47<a href="#v0247" title="Direct link to v0.2.47">​</a></span></a></h3>
<ul>
<li>Press Tab to auto-complete file and folder names</li>
<li>Press Shift + Tab to toggle auto-accept for file edits</li>
<li>Automatic conversation compaction for infinite conversation length (toggle with <code v-pre>/config</code>)</li>
</ul>
<p>See Also: <RouteLink to="/mechanics/auto-accept-permissions/">Auto-Accept Permissions</RouteLink></p>
<hr>
<h3 id="v0-2-44​" tabindex="-1"><a class="header-anchor" href="#v0-2-44​"><span>v0.2.44<a href="#v0244" title="Direct link to v0.2.44">​</a></span></a></h3>
<ul>
<li>Ask Claude to make a plan with thinking mode: just say 'think' or 'think harder' or even 'ultrathink'</li>
</ul>
<hr>
<h3 id="v0-2-41​" tabindex="-1"><a class="header-anchor" href="#v0-2-41​"><span>v0.2.41<a href="#v0241" title="Direct link to v0.2.41">​</a></span></a></h3>
<ul>
<li>MCP server startup timeout can now be configured via <code v-pre>MCP_TIMEOUT</code> environment variable</li>
<li>MCP server startup no longer blocks the app from starting up</li>
</ul>
<hr>
<h3 id="v0-2-37​" tabindex="-1"><a class="header-anchor" href="#v0-2-37​"><span>v0.2.37<a href="#v0237" title="Direct link to v0.2.37">​</a></span></a></h3>
<ul>
<li>New <code v-pre>/release-notes</code> command lets you view release notes at any time</li>
<li><code v-pre>claude config add/remove</code> commands now accept multiple values separated by commas or spaces</li>
</ul>
<hr>
<h3 id="v0-2-36​" tabindex="-1"><a class="header-anchor" href="#v0-2-36​"><span>v0.2.36<a href="#v0236" title="Direct link to v0.2.36">​</a></span></a></h3>
<ul>
<li>Import MCP servers from Claude Desktop with <code v-pre>claude mcp add-from-claude-desktop</code></li>
<li>Add MCP servers as JSON strings with <code v-pre>claude mcp add-json &amp;lt;n&amp;gt; &amp;lt;json&amp;gt;</code></li>
</ul>
<p>April 21, 2025|See Also: <RouteLink to="/claude-code-mcps/">MCPs &amp; Add-ons</RouteLink>|<RouteLink to="/configuration/#mcp-configuration">Configuration</RouteLink></p>
<hr>
<h3 id="v0-2-34​" tabindex="-1"><a class="header-anchor" href="#v0-2-34​"><span>v0.2.34<a href="#v0234" title="Direct link to v0.2.34">​</a></span></a></h3>
<ul>
<li>Vim bindings for text input - enable with <code v-pre>/vim</code> or <code v-pre>/config</code></li>
</ul>
<hr>
<h3 id="v0-2-32​" tabindex="-1"><a class="header-anchor" href="#v0-2-32​"><span>v0.2.32<a href="#v0232" title="Direct link to v0.2.32">​</a></span></a></h3>
<ul>
<li>Interactive MCP setup wizard: Run <code v-pre>claude mcp add</code> to add MCP servers with a step-by-step interface</li>
<li>Fix for some PersistentShell issues</li>
</ul>
<hr>
<h3 id="v0-2-31​" tabindex="-1"><a class="header-anchor" href="#v0-2-31​"><span>v0.2.31<a href="#v0231" title="Direct link to v0.2.31">​</a></span></a></h3>
<ul>
<li>Custom slash commands: Markdown files in <code v-pre>.claude/commands/</code> directories now appear as custom slash commands to insert prompts into your conversation</li>
<li>MCP debug mode: Run with <code v-pre>--mcp-debug</code> flag to get more information about MCP server errors</li>
</ul>
<p>See Also: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink> | <a href="https://docs.anthropic.com/en/docs/claude-code/slash-commands" target="_blank" rel="noopener noreferrer">Slash Commands</a></p>
<hr>
<h3 id="v0-2-30​" tabindex="-1"><a class="header-anchor" href="#v0-2-30​"><span>v0.2.30<a href="#v0230" title="Direct link to v0.2.30">​</a></span></a></h3>
<ul>
<li>Added ANSI color theme for better terminal compatibility</li>
<li>Fixed issue where slash command arguments weren't being sent properly</li>
<li>(Mac-only) API keys are now stored in macOS Keychain</li>
</ul>
<hr>
<h3 id="v0-2-26​" tabindex="-1"><a class="header-anchor" href="#v0-2-26​"><span>v0.2.26<a href="#v0226" title="Direct link to v0.2.26">​</a></span></a></h3>
<ul>
<li>New <code v-pre>/approved-tools</code> command for managing tool permissions</li>
<li>Word-level diff display for improved code readability</li>
<li>Fuzzy matching for slash commands</li>
</ul>
<p>April 21, 2025|See Also: <RouteLink to="/mechanics/auto-accept-permissions/">Auto-Accept Permissions</RouteLink>|<RouteLink to="/configuration/">Configuration</RouteLink></p>
<hr>
<h3 id="v0-2-21​" tabindex="-1"><a class="header-anchor" href="#v0-2-21​"><span>v0.2.21<a href="#v0221" title="Direct link to v0.2.21">​</a></span></a></h3>
<ul>
<li>Fuzzy matching for <code v-pre>/commands</code></li>
</ul>
<hr>
<h5 id="remarkable-progress" tabindex="-1"><a class="header-anchor" href="#remarkable-progress"><span>Remarkable Progress</span></a></h5>
<p>It's amazing how far Claude Code has come in such a short period of time. From early beta versions to a comprehensive development platform with MCPs, auto-permissions, plan mode, real-time steering, and sophisticated workflows - the pace of innovation has been extraordinary.</p>
<img src="/img/discovery/023_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<ul>
<li><a href="#v10111">v1.0.111</a></li>
<li><a href="#v10110">v1.0.110</a></li>
<li><a href="#v10109">v1.0.109</a></li>
<li><a href="#v10106">v1.0.106</a></li>
<li><a href="#v1097">v1.0.97</a></li>
<li><a href="#v1094">v1.0.94</a></li>
<li><a href="#v1093">v1.0.93</a></li>
<li><a href="#v1090">v1.0.90</a></li>
<li><a href="#v1088">v1.0.88</a></li>
<li><a href="#v1086">v1.0.86</a></li>
<li><a href="#v1085">v1.0.85</a></li>
<li><a href="#v1084">v1.0.84</a></li>
<li><a href="#v1083">v1.0.83</a></li>
<li><a href="#v1082">v1.0.82</a></li>
<li><a href="#v1081">v1.0.81</a></li>
<li><a href="#v1080">v1.0.80</a></li>
<li><a href="#v1077">v1.0.77</a></li>
<li><a href="#v1073">v1.0.73</a></li>
<li><a href="#v1072">v1.0.72</a></li>
<li><a href="#v1071">v1.0.71</a></li>
<li><a href="#v1070">v1.0.70</a></li>
<li><a href="#v1069">v1.0.69</a></li>
<li><a href="#v1068">v1.0.68</a></li>
<li><a href="#v1065">v1.0.65</a></li>
<li><a href="#v1064">v1.0.64</a></li>
<li><a href="#v1063">v1.0.63</a></li>
<li><a href="#v1062">v1.0.62</a></li>
<li><a href="#v1061">v1.0.61</a></li>
<li><a href="#v1060">v1.0.60</a></li>
<li><a href="#v1059">v1.0.59</a></li>
<li><a href="#v1058">v1.0.58</a></li>
<li><a href="#v1057">v1.0.57</a></li>
<li><a href="#v1056">v1.0.56</a></li>
<li><a href="#v1055">v1.0.55</a></li>
<li><a href="#v1054">v1.0.54</a></li>
<li><a href="#v1053">v1.0.53</a></li>
<li><a href="#v1052">v1.0.52</a></li>
<li><a href="#v1051">v1.0.51</a></li>
<li><a href="#v1048">v1.0.48</a></li>
<li><a href="#v1045">v1.0.45</a></li>
<li><a href="#v1044">v1.0.44</a></li>
<li><a href="#v1043">v1.0.43</a></li>
<li><a href="#v1042">v1.0.42</a></li>
<li><a href="#v1041">v1.0.41</a></li>
<li><a href="#v1040">v1.0.40</a></li>
<li><a href="#v1039">v1.0.39</a></li>
<li><a href="#v1038">v1.0.38</a></li>
<li><a href="#v1037">v1.0.37</a></li>
<li><a href="#v1036">v1.0.36</a></li>
<li><a href="#v1035">v1.0.35</a></li>
<li><a href="#v1034">v1.0.34</a></li>
<li><a href="#v1033">v1.0.33</a></li>
<li><a href="#v1032">v1.0.32</a></li>
<li><a href="#v1031">v1.0.31</a></li>
<li><a href="#v1030">v1.0.30</a></li>
<li><a href="#v1029">v1.0.29</a></li>
<li><a href="#v1028">v1.0.28</a></li>
<li><a href="#v1027">v1.0.27</a></li>
<li><a href="#v1025">v1.0.25</a></li>
<li><a href="#v1024">v1.0.24</a></li>
<li><a href="#v1023">v1.0.23</a></li>
<li><a href="#v1022">v1.0.22</a></li>
<li><a href="#v1021">v1.0.21</a></li>
<li><a href="#v1018">v1.0.18</a></li>
<li><a href="#v1017">v1.0.17</a></li>
<li><a href="#v1016">v1.0.16</a></li>
<li><a href="#v1011">v1.0.11</a></li>
<li><a href="#v1010">v1.0.10</a></li>
<li><a href="#v108">v1.0.8</a></li>
<li><a href="#v107">v1.0.7</a></li>
<li><a href="#v106">v1.0.6</a></li>
<li><a href="#v104">v1.0.4</a></li>
<li><a href="#v101">v1.0.1</a></li>
<li><a href="#v100">v1.0.0</a></li>
<li><a href="#v02125">v0.2.125</a></li>
<li><a href="#v02117">v0.2.117</a></li>
<li><a href="#v02108">v0.2.108</a></li>
<li><a href="#v02107">v0.2.107</a></li>
<li><a href="#v02106">v0.2.106</a></li>
<li><a href="#v02105">v0.2.105</a></li>
<li><a href="#v02102">v0.2.102</a></li>
<li><a href="#v02100">v0.2.100</a></li>
<li><a href="#v0298">v0.2.98</a></li>
<li><a href="#v0295">v0.2.95</a></li>
<li><a href="#v0293">v0.2.93</a></li>
<li><a href="#v0282">v0.2.82</a></li>
<li><a href="#v0275">v0.2.75</a></li>
<li><a href="#v027">v0.2.7</a></li>
<li><a href="#v0272">v0.2.72</a></li>
<li><a href="#v0270">v0.2.70</a></li>
<li><a href="#v0269">v0.2.69</a></li>
<li><a href="#v0267">v0.2.67</a></li>
<li><a href="#v0266">v0.2.66</a></li>
<li><a href="#v0263">v0.2.63</a></li>
<li><a href="#v0261">v0.2.61</a></li>
<li><a href="#v0259">v0.2.59</a></li>
<li><a href="#v0254">v0.2.54</a></li>
<li><a href="#v0253">v0.2.53</a></li>
<li><a href="#v0250">v0.2.50</a></li>
<li><a href="#v0249">v0.2.49</a></li>
<li><a href="#v0247">v0.2.47</a></li>
<li><a href="#v0244">v0.2.44</a></li>
<li><a href="#v0241">v0.2.41</a></li>
<li><a href="#v0237">v0.2.37</a></li>
<li><a href="#v0236">v0.2.36</a></li>
<li><a href="#v0234">v0.2.34</a></li>
<li><a href="#v0232">v0.2.32</a></li>
<li><a href="#v0231">v0.2.31</a></li>
<li><a href="#v0230">v0.2.30</a></li>
<li><a href="#v0226">v0.2.26</a></li>
<li><a href="#v0221">v0.2.21</a></li>
</ul>
</div></template>


