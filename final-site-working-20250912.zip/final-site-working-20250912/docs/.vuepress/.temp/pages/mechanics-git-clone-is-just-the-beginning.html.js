import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/mechanics-git-clone-is-just-the-beginning.html.vue"
const data = JSON.parse("{\"path\":\"/mechanics-git-clone-is-just-the-beginning.html\",\"title\":\"Git Clone Is Just The Beginning | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"Git Clone Is Just The Beginning | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"mechanics-git-clone-is-just-the-beginning.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
