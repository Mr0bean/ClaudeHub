<template><div><h1 id="blender-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#blender-mcp-claudelog"><span>Blender MCP | ClaudeLog</span></a></h1>
<p><strong>Revolutionary AI-powered 3D modeling that connects Blender to Claude AI for natural language scene creation and object manipulation.</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/ahujasid" target="_blank" rel="noopener noreferrer">ahujasid</a>  |  <a href="https://github.com/ahujasid/blender-mcp" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  13k Stars|1.2k Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Blender MCP creates a bidirectional bridge between Blender and Claude AI through the Model Context Protocol, enabling prompt-assisted 3D modeling and scene creation. This integration allows users to create, modify, and manipulate 3D objects using natural language instructions, democratizing 3D design for users of all skill levels.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Natural Language 3D Modeling</strong> - Create and modify 3D objects using conversational prompts</li>
<li><strong>Two-Way Communication</strong> - Socket-based server enabling real-time interaction with Blender</li>
<li><strong>Scene Management</strong> - Comprehensive control over lighting, cameras, and scene properties</li>
<li><strong>Asset Integration</strong> - Direct access to Poly Haven HDRIs, textures, and 3D models</li>
<li><strong>Python Code Execution</strong> - Run arbitrary Python scripts in Blender through AI prompts</li>
<li><strong>Material Control</strong> - Apply and modify materials, colors, and textures with AI assistance</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Blender 3.0 or newer (3.6+ recommended for full functionality)</li>
<li>Python 3.10 or newer</li>
<li>uv package manager</li>
</ul>
<p><strong>Setup Commands</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Install uv package manager (macOS)</span></span>
<span class="line"></span>
<span class="line"><span class="token function">curl</span> <span class="token parameter variable">-LsSf</span> https://astral.sh/uv/install.sh <span class="token operator">|</span> <span class="token function">sh</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Install uv package manager (Windows)</span></span>
<span class="line"></span>
<span class="line">powershell <span class="token parameter variable">-ExecutionPolicy</span> ByPass <span class="token parameter variable">-c</span> <span class="token string">"irm https://astral.sh/uv/install.ps1 | iex"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Install uv package manager (Linux)</span></span>
<span class="line"></span>
<span class="line"><span class="token function">curl</span> <span class="token parameter variable">-LsSf</span> https://astral.sh/uv/install.sh <span class="token operator">|</span> <span class="token function">sh</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Blender Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># 1. Download addon.py from the repository</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># 2. Open Blender → Edit → Preferences → Add-ons</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># 3. Click "Install..." and select addon.py</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># 4. Enable "MCP Blender Bridge" addon</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude Desktop Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"blender"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"uvx"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"blender-mcp"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Scene Creation Examples</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Natural language commands through Claude:</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Create a beach scene with palm trees and rocks"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Add a sunset HDRI and adjust the lighting"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Generate a low-poly character model"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Apply ocean materials to the water plane"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The integration supports complex 3D workflows through conversational interaction. Users can describe scenes, modify object properties, download assets from integrated libraries, and execute advanced modeling operations without deep Blender knowledge.</p>
<p><strong>Advanced Capabilities</strong></p>
<ul>
<li><strong>Asset Download</strong>: Automatic integration with Poly Haven and Hyper3D libraries</li>
<li><strong>Scene Analysis</strong>: AI can inspect and describe current Blender scenes</li>
<li><strong>Code Generation</strong>: Python scripts generated and executed for complex operations</li>
<li><strong>Reference-Based Creation</strong>: Generate 3D scenes from reference images</li>
</ul>
<hr>
<h5 id="community-insight" tabindex="-1"><a class="header-anchor" href="#community-insight"><span>Community Insight</span></a></h5>
<p>Blender MCP has been called &quot;a game-changer for 3D artists&quot; with users reporting &quot;amateur users who barely know Blender can use natural language to describe models.&quot; The integration represents &quot;text-to-3D workflow playing out in real time&quot; as similar servers emerge for Unity and Unreal Engine.</p>
<img src="/img/discovery/021_happy.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Blender MCP is developed by ahujasid and sponsored by Warp. For technical support, contributions, and community discussions, please refer to the official GitHub repository and Discord community.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


