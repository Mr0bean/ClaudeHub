<template><div><h1 id="claude-code-mcps-add-ons-claudelog" tabindex="-1"><a class="header-anchor" href="#claude-code-mcps-add-ons-claudelog"><span>Claude Code MCPs &amp; Add-ons | ClaudeLog</span></a></h1>
<p>Discover curated Claude Code MCPs, extensions, and add-ons to supercharge your development workflow.</p>
<h2 id="cc-usage" tabindex="-1"><a class="header-anchor" href="#cc-usage"><span><RouteLink to="/claude-code-mcps-cc-usage.html">CC Usage</RouteLink></span></a></h2>
<p>CC Usage: Monitor Claude Code API costs and token usage with detailed analytics. Track daily/monthly consumption, optimize spending &amp; workflows.</p>
<h2 id="tdd-guard" tabindex="-1"><a class="header-anchor" href="#tdd-guard"><span><RouteLink to="/claude-code-mcps-tdd-guard.html">TDD Guard</RouteLink></span></a></h2>
<p>TDD Guard: Automated Test-Driven Development enforcement for Claude Code with multi-language support and customizable validation rules.</p>
<h2 id="tweakcc" tabindex="-1"><a class="header-anchor" href="#tweakcc"><span><RouteLink to="/claude-code-mcps-tweakcc.html">TweakCC</RouteLink></span></a></h2>
<p>TweakCC: Lightweight CLI tool for personalizing Claude Code interface with custom themes, animations, thinking verbs, and visual styling.</p>
<h2 id="claude-code-router" tabindex="-1"><a class="header-anchor" href="#claude-code-router"><span><RouteLink to="/claude-code-mcps-claude-code-router.html">Claude Code Router</RouteLink></span></a></h2>
<p>Claude Code Router: Use Claude Code without an Anthropic account by routing requests to alternative AI providers like OpenRouter, DeepSeek, and Ollama.</p>
<h2 id="claudia" tabindex="-1"><a class="header-anchor" href="#claudia"><span><RouteLink to="/claude-code-mcps-claudia.html">Claudia</RouteLink></span></a></h2>
<p>Claudia: Powerful GUI toolkit for Claude Code with custom AI agents, session management, usage analytics, and MCP server integration.</p>
<h2 id="context7-mcp" tabindex="-1"><a class="header-anchor" href="#context7-mcp"><span><RouteLink to="/claude-code-mcps-context7-mcp.html">Context7 MCP</RouteLink></span></a></h2>
<p>Context7 MCP: Up-to-date code documentation for Claude Code through Model Context Protocol. Inject current library docs and examples into prompts.</p>
<h2 id="puppeteer-mcp" tabindex="-1"><a class="header-anchor" href="#puppeteer-mcp"><span><RouteLink to="/claude-code-mcps-puppeteer-mcp.html">Puppeteer MCP</RouteLink></span></a></h2>
<p>Puppeteer MCP: Web automation with AI vision for Claude Code through Model Context Protocol. Control Chrome, extract data, and automate web workflows.</p>
<h2 id="reddit-mcp" tabindex="-1"><a class="header-anchor" href="#reddit-mcp"><span><RouteLink to="/claude-code-mcps-reddit-mcp.html">Reddit MCP</RouteLink></span></a></h2>
<p>Reddit MCP: Reddit API integration for Claude Code through Model Context Protocol. Browse, search, and analyze Reddit content seamlessly.</p>
<h2 id="whatsapp-mcp" tabindex="-1"><a class="header-anchor" href="#whatsapp-mcp"><span><RouteLink to="/claude-code-mcps-whatsapp-mcp.html">WhatsApp MCP</RouteLink></span></a></h2>
<p>WhatsApp MCP: Personal WhatsApp integration for Claude Code through Model Context Protocol. Search messages, manage contacts, and send messages.</p>
<h2 id="awesome-mcp-servers" tabindex="-1"><a class="header-anchor" href="#awesome-mcp-servers"><span><RouteLink to="/claude-code-mcps-awesome-mcp-servers.html">Awesome MCP Servers</RouteLink></span></a></h2>
<p>Curated directory of Model Context Protocol servers for AI models to interact with databases, developer tools, cloud services, and more.</p>
<h2 id="awesome-claude-code" tabindex="-1"><a class="header-anchor" href="#awesome-claude-code"><span><RouteLink to="/claude-code-mcps-awesome-claude-code.html">Awesome Claude Code</RouteLink></span></a></h2>
<p>Curated collection of Claude Code slash commands, CLAUDE.md files, workflows, CLI tools, and productivity resources for enhanced development workflows.</p>
<h2 id="github-mcp-server" tabindex="-1"><a class="header-anchor" href="#github-mcp-server"><span><RouteLink to="/claude-code-mcps-github-mcp-server.html">GitHub MCP Server</RouteLink></span></a></h2>
<p>Official GitHub MCP server enabling seamless GitHub API integration for automated workflows, repository management, and AI-powered development tasks.</p>
<h2 id="blender-mcp" tabindex="-1"><a class="header-anchor" href="#blender-mcp"><span><RouteLink to="/claude-code-mcps-blender-mcp.html">Blender MCP</RouteLink></span></a></h2>
<p>AI-powered 3D modeling connecting Blender to Claude AI for natural language 3D scene creation, object manipulation, and automated workflows.</p>
<h2 id="browser-tools-mcp" tabindex="-1"><a class="header-anchor" href="#browser-tools-mcp"><span><RouteLink to="/claude-code-mcps-browser-tools-mcp.html">Browser Tools MCP</RouteLink></span></a></h2>
<p>Browser automation MCP server for real-time web debugging, performance analysis, and automated testing in development workflows.</p>
<h2 id="desktop-commander-mcp" tabindex="-1"><a class="header-anchor" href="#desktop-commander-mcp"><span><RouteLink to="/claude-code-mcps-desktop-commander-mcp.html">Desktop Commander MCP</RouteLink></span></a></h2>
<p>System control MCP server for terminal commands, file operations, and cross-platform development automation capabilities.</p>
<h2 id="zen-mcp-server" tabindex="-1"><a class="header-anchor" href="#zen-mcp-server"><span><RouteLink to="/claude-code-mcps-zen-mcp-server.html">Zen MCP Server</RouteLink></span></a></h2>
<p>Multi-AI orchestration platform enabling Claude Code to collaborate with Gemini, OpenAI, Grok, and other models for enhanced development workflows.</p>
<h2 id="serena" tabindex="-1"><a class="header-anchor" href="#serena"><span><RouteLink to="/claude-code-mcps-serena.html">Serena</RouteLink></span></a></h2>
<p>Free AI coding agent toolkit providing semantic code retrieval, intelligent editing, and language server integration for enhanced development workflows.</p>
<h2 id="awesome-claude-prompts" tabindex="-1"><a class="header-anchor" href="#awesome-claude-prompts"><span><RouteLink to="/claude-code-mcps-awesome-claude-prompts.html">Awesome Claude Prompts</RouteLink></span></a></h2>
<p>Curated collection of optimized Claude prompts for development, business, and creative workflows with proven prompt engineering techniques.</p>
</div></template>


