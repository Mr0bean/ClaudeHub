import comp from "/Users/ruanchuhao/Downloads/Codes/其他/claudelogTranslate/final-site/docs/.vuepress/.temp/pages/claude-code-mcps-github-mcp-server.html.vue"
const data = JSON.parse("{\"path\":\"/claude-code-mcps-github-mcp-server.html\",\"title\":\"GitHub MCP Server | ClaudeLog\",\"lang\":\"en\",\"frontmatter\":{\"title\":\"GitHub MCP Server | ClaudeLog\"},\"git\":{},\"filePathRelative\":\"claude-code-mcps-github-mcp-server.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
