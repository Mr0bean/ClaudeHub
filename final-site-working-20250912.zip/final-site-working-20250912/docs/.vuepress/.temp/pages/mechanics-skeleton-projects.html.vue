<template><div><h1 id="skeleton-projects-claudelog" tabindex="-1"><a class="header-anchor" href="#skeleton-projects-claudelog"><span>Skeleton Projects | ClaudeLog</span></a></h1>
<p>When looking to implement a piece of functionality or vibe coding a full project, I have found nothing beats the efficiency of providing Claude with a great skeleton project which defines a battle proven structure for him to iterate from. This approach is particularly powerful when working in languages where you're not proficient, as the skeleton provides the architectural foundation and best practices that you might otherwise lack.</p>
<hr>
<hr>
<h3 id="the-skeleton-strategy​" tabindex="-1"><a class="header-anchor" href="#the-skeleton-strategy​"><span>The Skeleton Strategy<a href="#the-skeleton-strategy" title="Direct link to The Skeleton Strategy">​</a></span></a></h3>
<p>The process of identifying GitHub skeleton projects can be taken on by Claude and an army of <RouteLink to="/mechanics/split-role-sub-agents/">sub-agents</RouteLink> to further improve the process efficiency. I tend to approach it in one of two ways:</p>
<h3 id="method-1-parallel-source-research​" tabindex="-1"><a class="header-anchor" href="#method-1-parallel-source-research​"><span>Method 1: Parallel Source Research<a href="#method-1-parallel-source-research" title="Direct link to Method 1: Parallel Source Research">​</a></span></a></h3>
<p>Get the <RouteLink to="/mechanics/split-role-sub-agents/">sub-agents</RouteLink> to find resources in parallel from different sources:</p>
<ul>
<li><strong>Agent 1</strong> - utilise the Reddit MCP</li>
<li><strong>Agent 2</strong> - search with Brave</li>
<li><strong>Agent 3</strong> - search with Bing</li>
<li><strong>Agent 4</strong> - search GitHub directly</li>
</ul>
<h3 id="method-2-evaluation-sub-agents​" tabindex="-1"><a class="header-anchor" href="#method-2-evaluation-sub-agents​"><span>Method 2: Evaluation Sub-agents<a href="#method-2-evaluation-sub-agents" title="Direct link to Method 2: Evaluation Sub-agents">​</a></span></a></h3>
<p>Have a singular Claude perform the research and then assign multiple <RouteLink to="/mechanics/split-role-sub-agents/">sub-agents</RouteLink> different roles to evaluate all the discovered repositories:</p>
<ul>
<li><strong>Security role</strong> - vulnerability assessment</li>
<li><strong>Extensibility role</strong> - how easy to modify and extend</li>
<li><strong>Relevance role</strong> - how well it fits the use case</li>
<li><strong>Implementation role</strong> - how the desired functionality would be added</li>
<li><strong>Language choice role</strong> - optimal technology stack</li>
<li><strong>Documentation role</strong> - quality of guides and examples</li>
</ul>
<hr>
<hr>
<h3 id="the-efficiency-multiplier​" tabindex="-1"><a class="header-anchor" href="#the-efficiency-multiplier​"><span>The Efficiency Multiplier<a href="#the-efficiency-multiplier" title="Direct link to The Efficiency Multiplier">​</a></span></a></h3>
<p>The above tactic allows me to fly through research tasks and provide Claude with a thoroughly tested skeleton to work within which has been reviewed and simultaneously jump starts him with a <RouteLink to="/mechanics/plan-mode/">plan</RouteLink> for implementing your requested functionality.</p>
<p>If Claude is unable to produce the desired functionality given a specific skeleton project, you can try one of the alternative repositories or if you're feeling ambitious clone the best two repos and build them both in parallel.</p>
<p>Our imaginations are the limiting factor.</p>
<h3 id="skeleton-selection-criteria​" tabindex="-1"><a class="header-anchor" href="#skeleton-selection-criteria​"><span>Skeleton Selection Criteria<a href="#skeleton-selection-criteria" title="Direct link to Skeleton Selection Criteria">​</a></span></a></h3>
<p>When evaluating potential skeleton projects, consider:</p>
<ul>
<li><strong>Battle-tested</strong> - proven in production environments</li>
<li><strong>Well-documented</strong> - clear setup and usage instructions</li>
<li><strong>Active maintenance</strong> - recent commits and responsive maintainers</li>
<li><strong>Modular structure</strong> - easy to understand and modify</li>
<li><strong>Technology alignment</strong> - matches your tech stack preferences</li>
</ul>
<h5 id="foundation-strategy" tabindex="-1"><a class="header-anchor" href="#foundation-strategy"><span>Foundation Strategy</span></a></h5>
<p>A great skeleton project is worth its weight in development time. Instead of starting from scratch, Claude can iterate within proven structures, dramatically reducing setup overhead and focusing on core value delivery.</p>
<img src="/img/discovery/018_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/git-clone-is-just-the-beginning/">Git Clone is Just the Beginning</RouteLink>|<RouteLink to="/mechanics/split-role-sub-agents/">Split Role Sub-agents</RouteLink>|<RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#the-skeleton-strategy">The Skeleton Strategy</a></li>
<li><a href="#method-1-parallel-source-research">Method 1: Parallel Source Research</a></li>
<li><a href="#method-2-evaluation-sub-agents">Method 2: Evaluation Sub-agents</a></li>
<li><a href="#the-efficiency-multiplier">The Efficiency Multiplier</a></li>
<li><a href="#skeleton-selection-criteria">Skeleton Selection Criteria</a></li>
</ul>
</div></template>


