<template><div><h1 id="permutation-frameworks-claudelog" tabindex="-1"><a class="header-anchor" href="#permutation-frameworks-claudelog"><span>Permutation Frameworks | ClaudeLog</span></a></h1>
<p>A <code v-pre>permutation framework</code> is when you build an array of similar features with shared function signatures by hand (for example, 10+ features), then design a <code v-pre>CLAUDE.md</code> that lets Claude generate subsequent variations reliably. Instead of coding each feature manually, you create an array of patterns which covers a broad range of possibilities whilst also guiding Claude on aspects which must not be changed.</p>
<p>After confirming that Claude <code v-pre>reliable</code>, I began to wonder how far could this scale? How could you push a product to the limits and extract as much value as possible whilst working within the limitations of the kind of tasks that can be autonomously completed and <code v-pre>evaluated</code>.</p>
<hr>
<hr>
<h3 id="understanding-claude-s-strengths​" tabindex="-1"><a class="header-anchor" href="#understanding-claude-s-strengths​"><span>Understanding Claude's Strengths<a href="#understanding-claudes-strengths" title="Direct link to Understanding Claude's Strengths">​</a></span></a></h3>
<p>The first thing I had to acknowledge is what works and what does not work.</p>
<p>Claude Code appears to be incredibly good at completing tasks where it has decent inherent knowledge or where you provide it with sufficient context including examples of what to do and what not to do.</p>
<p>I have observed that the more strict examples, steps, files to edit and not edit you can provide, the less adherence variance you have on a task. But the issue then becomes that this kind of setup is tedious to do for tasks which are bespoke and <code v-pre>one-off</code>.</p>
<h3 id="from-one-off-tasks-to-systematic-permutations​" tabindex="-1"><a class="header-anchor" href="#from-one-off-tasks-to-systematic-permutations​"><span>From One-Off Tasks to Systematic Permutations<a href="#from-one-off-tasks-to-systematic-permutations" title="Direct link to From One-Off Tasks to Systematic Permutations">​</a></span></a></h3>
<p>This is why you should identify how and where to implement <code v-pre>permutations of functionality</code> within your product and offer them to the market as valuable add-ons.</p>
<p>This requires you to design a system or <code v-pre>permutation framework</code> which Claude can work within, allowing you to create example permutations of functionality that follow similar patterns but provide different kinds of value to end users. See <RouteLink to="/tool-maker/">Tool Maker</RouteLink> as an example permutation <code v-pre>CLAUDE.md</code>.</p>
<hr>
<hr>
<h3 id="building-your-framework-foundation​" tabindex="-1"><a class="header-anchor" href="#building-your-framework-foundation​"><span>Building Your Framework Foundation<a href="#building-your-framework-foundation" title="Direct link to Building Your Framework Foundation">​</a></span></a></h3>
<p>At <a href="https://www.commandstick.com" target="_blank" rel="noopener noreferrer">CommandStick™</a> for our upcoming Android app, we have units of functionality which are accessed by a novel HCI (human computer interface). After you have completed 10 or so differing units of functionality within a <code v-pre>permutation framework</code>, it can be further fleshed out to allow for defining a wide range of functionality. After fleshing out your <code v-pre>permutation framework</code> scope, you can then begin experimenting to get an agent to generate functionality within the confines of your <code v-pre>permutation framework</code>.</p>
<h3 id="iterative-framework-refinement​" tabindex="-1"><a class="header-anchor" href="#iterative-framework-refinement​"><span>Iterative Framework Refinement<a href="#iterative-framework-refinement" title="Direct link to Iterative Framework Refinement">​</a></span></a></h3>
<p>Initially, Claude will struggle and fail frequently. However, as you refine your <code v-pre>CLAUDE.md</code> to provide clearer guidance for implementing permutations, the adherence and reward gradually improves.</p>
<p>Once Claude began successfully implementing functionality, I repeated the process ~90 times while adjusting various aspects of my <code v-pre>CLAUDE.md</code> to understand what affects instruction adherence and what affects the degree of code variance.</p>
<p>I would not say it is necessary to run 90 tests but it is paramount to have a solid idea of the degree of variance amongst the generated code within a <code v-pre>permutation framework</code>, otherwise you are <code v-pre>creating permutations of slop</code>.</p>
<p>I then explored creating a system for reviewing the permutations which are frivolously generated, so my job goes from implementation to live review at scale! This iterative process builds both your Claude Code expertise and a reliable system for generating permutations.</p>
<hr>
<hr>
<p><strong>Mechanic Benefits:</strong></p>
<ul>
<li><strong>Scalable value creation</strong>: Transform one framework into multiple valuable feature variations instead of building individual features</li>
<li><strong>Reduced variance through constraints</strong>: Well-defined <code v-pre>permutation frameworks</code> limit Claude's creative variance while maintaining useful output diversity</li>
<li><strong>Implementation to review workflow</strong>: Shift from manual coding to reviewing and orchestrating AI-generated permutations at scale</li>
<li><strong>Expertise compounding</strong>: Each iteration improves both your Claude Code skills and framework reliability</li>
</ul>
<h5 id="systematic-scaling" tabindex="-1"><a class="header-anchor" href="#systematic-scaling"><span>Systematic Scaling</span></a></h5>
<p><code v-pre>Permutation frameworks</code> transform development from linear to exponential scaling. Your role shifts from implementation to orchestration, reviewing Ai-generated feature permutations rather than building each feature manually.</p>
<img src="/img/discovery/031_cell.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink>|<RouteLink to="/mechanics/agent-first-design/">Agent First Design</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#understanding-claudes-strengths">Understanding Claude's Strengths</a></li>
<li><a href="#from-one-off-tasks-to-systematic-permutations">From One-Off Tasks to Systematic Permutations</a></li>
<li><a href="#building-your-framework-foundation">Building Your Framework Foundation</a></li>
<li><a href="#iterative-framework-refinement">Iterative Framework Refinement</a></li>
</ul>
</div></template>


