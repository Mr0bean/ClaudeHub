<template><div><h1 id="cc-usage-claudelog" tabindex="-1"><a class="header-anchor" href="#cc-usage-claudelog"><span>CC Usage | ClaudeLog</span></a></h1>
<p><strong>Monitor your Claude Code API usage and costs with detailed analytics</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/ryoppippi" target="_blank" rel="noopener noreferrer">@ryoppippi</a>  |  <a href="https://github.com/ryoppippi/ccusage" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  7.2k Stars|215 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>CC Usage is a command-line tool that helps you track and analyze your Claude Code API consumption. Get detailed insights into your usage patterns, costs, and optimize your Claude Code workflows.</p>
<hr>
<hr>
<!-- Screenshot temporarily removed due to missing asset -->
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Daily &amp; Monthly Reports</strong> - View token usage and costs aggregated by date or month</li>
<li><strong>5-Hour Block Monitoring</strong> - Track usage within Claude's billing windows with active block monitoring</li>
<li><strong>Live Dashboard</strong> - Real-time monitoring showing active session progress and token burn rate</li>
<li><strong>Model Tracking</strong> - See which Claude models you're using with per-model cost breakdown</li>
<li><strong>Date Filtering</strong> - Filter reports by date range and export data in JSON format</li>
<li><strong>MCP Integration</strong> - Built-in Model Context Protocol server for integration with other tools</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Quick Start (Recommended)</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">npx ccusage@latest  <span class="token comment"># or: bunx ccusage  # or: pnpm dlx ccusage</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Global Installation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token function">npm</span> <span class="token function">install</span> <span class="token parameter variable">-g</span> ccusage <span class="token operator">&amp;&amp;</span> ccusage daily</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Daily Usage Report</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># View daily token usage and costs</span></span>
<span class="line"></span>
<span class="line">ccusage daily</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Monthly Reports</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Monthly usage summary</span></span>
<span class="line"></span>
<span class="line">ccusage monthly</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>For additional options and advanced usage, read the <a href="https://github.com/ryoppippi/ccusage" target="_blank" rel="noopener noreferrer">official documentation</a>.</p>
<hr>
<h3 id="integration-with-claude-code​" tabindex="-1"><a class="header-anchor" href="#integration-with-claude-code​"><span>Integration with Claude Code<a href="#integration-with-claude-code" title="Direct link to Integration with Claude Code">​</a></span></a></h3>
<p>CC Usage works alongside your existing Claude Code setup to provide transparency into your API consumption patterns.</p>
<p><strong>Workflow Integration</strong></p>
<ul>
<li>Track usage during development sessions</li>
<li>Optimize prompt efficiency based on usage data</li>
<li>See how much money you saved with Claude Max or Pro</li>
</ul>
<h5 id="community-need" tabindex="-1"><a class="header-anchor" href="#community-need"><span>Community Need</span></a></h5>
<p>Developers on Claude Pro and Max subscriptions frequently express frustration about hitting usage limits without understanding consumption patterns. CC Usage provides visibility into subscription usage, helping optimize workflows and track value.</p>
<img src="/img/discovery/013.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>CC Usage is an independent community project. For technical support and updates, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
<li><a href="#integration-with-claude-code">Integration with Claude Code</a></li>
</ul>
</div></template>


