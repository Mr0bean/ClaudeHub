<template><div><h1 id="desktop-commander-mcp-claudelog" tabindex="-1"><a class="header-anchor" href="#desktop-commander-mcp-claudelog"><span>Desktop Commander MCP | ClaudeLog</span></a></h1>
<p><strong>Comprehensive system control and development automation server enabling terminal commands, file operations, and cross-platform workflow management through MCP integration.</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/wonderwhy-er" target="_blank" rel="noopener noreferrer">wonderwhy-er</a>  |  <a href="https://github.com/wonderwhy-er/DesktopCommanderMCP" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  4.3k Stars|475 Forks|MIT License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Desktop Commander MCP provides comprehensive system-level control and development automation through the Model Context Protocol. It enables AI models to execute terminal commands, perform file operations, analyze data, and manage development workflows across Windows, macOS, and Linux platforms. This server transforms AI assistants into powerful system automation tools while maintaining security boundaries.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Terminal Command Execution</strong> - Run shell commands, scripts, and system utilities directly from AI conversations</li>
<li><strong>Cross-Platform File Operations</strong> - File reading, writing, searching, and manipulation across operating systems</li>
<li><strong>Multi-Language Code Execution</strong> - Support for Python, JavaScript, shell scripts, and other languages</li>
<li><strong>Data Analysis Capabilities</strong> - CSV processing, statistical analysis, and data transformation tools</li>
<li><strong>Development Workflow Automation</strong> - Git operations, build processes, and deployment scripts</li>
<li><strong>Security Controls</strong> - Configurable permission system and command validation</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Node.js 18.0.0+ for MCP server functionality</li>
<li>npm package manager</li>
<li>Compatible MCP client (Claude Desktop, VS Code, Cursor)</li>
</ul>
<p><strong>Recommended Installation (Auto-Updates)</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Quick setup with npx (recommended)</span></span>
<span class="line"></span>
<span class="line">npx @wonderwhy-er/desktop-commander@latest setup</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Debug mode (if needed)</span></span>
<span class="line"></span>
<span class="line">npx @wonderwhy-er/desktop-commander@latest setup <span class="token parameter variable">--debug</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Manual Configuration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"desktop-commander"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"-y"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"@wonderwhy-er/desktop-commander"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Alternative Installation Methods</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># macOS bash script installation</span></span>
<span class="line"></span>
<span class="line"><span class="token function">curl</span> <span class="token parameter variable">-fsSL</span> https://raw.githubusercontent.com/wonderwhy-er/DesktopCommanderMCP/refs/heads/main/install.sh <span class="token operator">|</span> <span class="token function">bash</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Smithery CLI installation</span></span>
<span class="line"></span>
<span class="line">npx <span class="token parameter variable">-y</span> @smithery/cli <span class="token function">install</span> @wonderwhy-er/desktop-commander <span class="token parameter variable">--client</span> claude</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Local development setup</span></span>
<span class="line"></span>
<span class="line"><span class="token function">git</span> clone https://github.com/wonderwhy-er/DesktopCommanderMCP.git</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">cd</span> DesktopCommanderMCP</span>
<span class="line"></span>
<span class="line"><span class="token function">npm</span> run setup</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Configuration Locations</strong></p>
<ul>
<li><strong>macOS</strong>: <code v-pre>~/Library/Application\ Support/Claude/claude_desktop_config.json</code></li>
<li><strong>Windows</strong>: <code v-pre>%APPDATA%\Claude\claude_desktop_config.json</code></li>
<li><strong>Linux</strong>: <code v-pre>~/.config/Claude/claude_desktop_config.json</code></li>
</ul>
<p><strong>Note</strong>: Restart Claude Desktop after installation. Configuration persists between server restarts.</p>
<hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>System Administration</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Example AI interactions:</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Check system disk usage and clean up temporary files"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Monitor running processes and identify high CPU usage"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Create a backup script for the project directory"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Update system packages and restart services"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The server enables natural language system administration and development automation. You can manage files, execute complex workflows, analyze system performance, and automate repetitive tasks through conversational AI interfaces.</p>
<p><strong>Development Workflows</strong></p>
<ul>
<li><strong>Code Analysis</strong>: Analyze codebases, generate reports, and identify patterns</li>
<li><strong>Build Automation</strong>: Execute build scripts, run tests, and deploy applications</li>
<li><strong>Git Operations</strong>: Commit changes, manage branches, and handle merge conflicts</li>
<li><strong>Data Processing</strong>: Parse logs, process CSV files, and generate insights</li>
</ul>
<hr>
<h5 id="community-insight" tabindex="-1"><a class="header-anchor" href="#community-insight"><span>Community Insight</span></a></h5>
<p>Desktop Commander MCP provides cost-effective system automation for developers. Users report &quot;Claude Code-like capabilities for a fraction of the price&quot; with excellent cross-platform support.</p>
<img src="/img/discovery/023_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Desktop Commander MCP is developed by wonderwhy-er and is open-source. For technical support, feature requests, and community contributions, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


