<template><div><h1 id="claude-code-configuration-guide-claudelog" tabindex="-1"><a class="header-anchor" href="#claude-code-configuration-guide-claudelog"><span>Claude Code Configuration Guide | ClaudeLog</span></a></h1>
<p>Complete Claude Code configuration with comprehensive setup guides for API keys, model selection, MCP servers, tool permissions, and multi-directory workflows. Essential settings for optimizing your AI development experience.</p>
<hr>
<hr>
<h2 id="api-key-setup​" tabindex="-1"><a class="header-anchor" href="#api-key-setup​"><span>API Key Setup<a href="#api-key-setup" title="Direct link to API Key Setup">​</a></span></a></h2>
<p>Claude Code requires an Anthropic API key to function. Set it up using one of these methods:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Option 1: Environment variable (recommended)</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_API_KEY</span><span class="token operator">=</span><span class="token string">"your-api-key-here"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Option 2: Add to your shell profile</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">echo</span> <span class="token string">'export ANTHROPIC_API_KEY="your-api-key-here"'</span> <span class="token operator">>></span> ~/.bashrc</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">source</span> ~/.bashrc</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h2 id="model-selection​" tabindex="-1"><a class="header-anchor" href="#model-selection​"><span>Model Selection<a href="#model-selection" title="Direct link to Model Selection">​</a></span></a></h2>
<p>Claude Code supports multiple models. You can specify which model to use:</p>
<p><strong>Claude 4 Sonnet:</strong> Latest balanced performance and speed</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-sonnet-4-20250514"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude 4.1 Opus:</strong> Latest maximum capability with enhanced coding and debugging performance</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-opus-4-1-20250805"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude 4 Opus:</strong> Previous generation maximum capability model</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-opus-4-20250514"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude 3.5 Haiku:</strong> Fastest and most cost-effective</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_MODEL</span><span class="token operator">=</span><span class="token string">"claude-3-5-haiku-20241022"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p>Important limitations: Claude 3.5 Haiku</p>
<p>While Haiku is cost-effective, it has significant limitations for Claude Code usage:</p>
<ul>
<li><strong>Reduced reasoning capabilities</strong> - Struggles with complex multi-step planning and architectural decisions</li>
<li><strong>Limited context understanding</strong> - Less effective at analyzing large codebases and maintaining context across multiple files</li>
<li><strong>Simplified code analysis</strong> - May miss subtle bugs, dependencies, or complex patterns that modern models catch</li>
<li><strong>Basic refactoring only</strong> - Not suitable for sophisticated restructuring or feature implementations</li>
<li><strong>Limited framework knowledge</strong> - Less effective with complex frameworks or novel coding patterns</li>
</ul>
<p><strong>Recommended use cases for Haiku:</strong></p>
<ul>
<li>Simple single-file edits</li>
<li>Basic syntax corrections</li>
<li>Quick code questions</li>
<li>Learning Claude Code basics before upgrading</li>
</ul>
<p>For serious development work, Claude 4 Sonnet or Opus provide substantially better results and are worth the additional cost.</p>
<p><strong>Alternative Method:</strong> You can also specify the model directly when starting Claude Code:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">claude <span class="token parameter variable">--model</span> claude-sonnet-4-20250514</span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">--model</span> claude-opus-4-1-20250805</span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">--model</span> claude-opus-4-20250514</span>
<span class="line"></span>
<span class="line">claude <span class="token parameter variable">--model</span> claude-3-5-haiku-20241022</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h2 id="model-switching-during-session​" tabindex="-1"><a class="header-anchor" href="#model-switching-during-session​"><span>Model Switching During Session<a href="#model-switching-during-session" title="Direct link to Model Switching During Session">​</a></span></a></h2>
<p>You can switch models mid-session using the <code v-pre>/model</code> command, which provides an interactive menu:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">/model</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Available Options:</strong></p>
<ol>
<li><strong>Default (recommended)</strong> - Opus 4.1 for up to 20% of usage limits, then use Sonnet 4</li>
<li><strong>Opus</strong> - Opus 4.1 for complex tasks (reaches usage limits faster)</li>
<li><strong>Sonnet</strong> - Sonnet 4 for daily use</li>
<li><strong>Opus Plan Mode</strong> - Use Opus 4.1 in plan mode, Sonnet 4 otherwise ✔</li>
</ol>
<p>The Opus Plan Mode automatically switches between models based on context, using Opus 4.1 for research and planning phases, then Sonnet 4 for implementation and execution.</p>
<hr>
<hr>
<h2 id="mcp-configuration​" tabindex="-1"><a class="header-anchor" href="#mcp-configuration​"><span>MCP Configuration<a href="#mcp-configuration" title="Direct link to MCP Configuration">​</a></span></a></h2>
<p>Model Context Protocol (MCP) allows Claude Code to connect to external tools and services. Configure MCP servers to extend Claude's capabilities:</p>
<h4 id="mcp-server-setup​" tabindex="-1"><a class="header-anchor" href="#mcp-server-setup​"><span>MCP Server Setup<a href="#mcp-server-setup" title="Direct link to MCP Server Setup">​</a></span></a></h4>
<p>MCP configuration can be stored in multiple locations:</p>
<ul>
<li><strong>Project-specific:</strong> <code v-pre>.claude/settings.local.json</code> (in your project directory)</li>
<li><strong>User-specific local:</strong> <code v-pre>~/.claude/settings.local.json</code></li>
<li><strong>User-specific global:</strong> <code v-pre>~/.claude/settings.json</code></li>
<li><strong>Main Claude.json:</strong> <code v-pre>~/.claude.json</code></li>
<li><strong>Dedicated MCP file:</strong> <code v-pre>~/.claude/mcp_servers.json</code></li>
</ul>
<p>Example MCP configuration:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">// Example: ~/.claude.json <span class="token punctuation">(</span>recommended <span class="token keyword">for</span> reliability<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"projects"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"/path/to/your/project"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"filesystem"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"-y"</span>, <span class="token string">"@modelcontextprotocol/server-filesystem"</span>, <span class="token string">"/Users/username/Desktop"</span>, <span class="token string">"/path/to/allowed/dir"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"memory"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"-y"</span>, <span class="token string">"@modelcontextprotocol/server-memory"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"fetch"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"-y"</span>, <span class="token string">"@modelcontextprotocol/server-fetch"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">..</span>.</span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Note:</strong> If following this example ensure you update the right projects configuration.</p>
<p>For additional tools and integrations beyond MCP, explore our <RouteLink to="/claude-code-mcps/">Add-ons</RouteLink>.</p>
<hr>
<hr>
<h2 id="allowed-tools​" tabindex="-1"><a class="header-anchor" href="#allowed-tools​"><span>Allowed Tools<a href="#allowed-tools" title="Direct link to Allowed Tools">​</a></span></a></h2>
<h4 id="allowed-tools-setup​" tabindex="-1"><a class="header-anchor" href="#allowed-tools-setup​"><span>Allowed Tools Setup<a href="#allowed-tools-setup" title="Direct link to Allowed Tools Setup">​</a></span></a></h4>
<p>Allowed tools configuration can be stored in multiple locations:</p>
<ul>
<li><strong>Project-specific:</strong> <code v-pre>.claude/settings.local.json</code> (in your project directory)</li>
<li><strong>User-specific local:</strong> <code v-pre>~/.claude/settings.local.json</code></li>
<li><strong>User-specific global:</strong> <code v-pre>~/.claude/settings.json</code></li>
<li><strong>Main Claude.json:</strong> <code v-pre>~/.claude.json</code></li>
</ul>
<h4 id="example-allowed-tools-configuration-​" tabindex="-1"><a class="header-anchor" href="#example-allowed-tools-configuration-​"><span>Example Allowed Tools configuration:<a href="#example-allowed-tools-configuration" title="Direct link to Example Allowed Tools configuration:">​</a></span></a></h4>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">// Example: ~/.claude.json <span class="token punctuation">(</span>recommended <span class="token keyword">for</span> reliability<span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"projects"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"/path/to/your/project"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"filesystem"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">          <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"npx"</span>,</span>
<span class="line"></span>
<span class="line">          <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span><span class="token string">"-y"</span>, <span class="token string">"@modelcontextprotocol/server-filesystem"</span>, <span class="token string">"/Users/username/Desktop"</span>, <span class="token string">"/path/to/allowed/dir"</span><span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">        <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"allowedTools"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"Task"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Bash"</span>,                    // ⚠️ Dangerous: allows all system commands</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Bash(git log:*)"</span>,   // Safer: only allows <span class="token function">git</span> log commands</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Glob"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Grep"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"LS"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Read"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Edit"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"MultiEdit"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"Write"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"WebFetch"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"WebSearch"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">]</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span>,</span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">..</span>.</span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Note:</strong> If following this example ensure you update the right projects configuration.</p>
<h4 id="interactive-permission-management​" tabindex="-1"><a class="header-anchor" href="#interactive-permission-management​"><span>Interactive Permission Management<a href="#interactive-permission-management" title="Direct link to Interactive Permission Management">​</a></span></a></h4>
<p>For a more user-friendly approach to managing tool permissions, use the <code v-pre>/permissions</code> command within Claude Code:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Launch the interactive permissions UI</span></span>
<span class="line"></span>
<span class="line">/permissions</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>This advanced interface allows you to:</p>
<ul>
<li><strong>View current permissions</strong> - See which tools are currently allowed or denied</li>
<li><strong>Explicitly allow tools</strong> - Grant permission to specific tools or tool patterns</li>
<li><strong>Explicitly deny tools</strong> - Block access to tools you want to restrict</li>
<li><strong>Navigate visually</strong> - Use an intuitive UI instead of manually editing JSON files</li>
</ul>
<p>The <code v-pre>/permissions</code> interface provides real-time permission management with a fluid, responsive experience that makes configuration changes effortless—no need to restart Claude Code or manually edit configuration files.</p>
<p>tip</p>
<p>Multiple configuration locations exist due to legacy compatibility - you might encounter different file names and directory locations.</p>
<p><strong>Recommendation:</strong> Use <code v-pre>~/.claude.json</code> for reliability as shown in the examples above.</p>
<hr>
<hr>
<h2 id="additional-working-directories-extended-workspace​" tabindex="-1"><a class="header-anchor" href="#additional-working-directories-extended-workspace​"><span>Additional Working Directories / Extended Workspace<a href="#additional-working-directories--extended-workspace" title="Direct link to Additional Working Directories / Extended Workspace">​</a></span></a></h2>
<p>Claude Code can access multiple directories beyond your current working directory using:</p>
<ul>
<li><strong>CLI argument:</strong> <code v-pre>--add-dir</code> (added in <RouteLink to="/claude-code-changelog/#v1018">v1.0.18</RouteLink>) when starting Claude Code</li>
<li><strong>Slash command:</strong> <code v-pre>/add-dir</code> mid-session for seamless workflow expansion</li>
</ul>
<p>This allows you to work across multiple projects or reference external resources without changing directories or restarting your session.</p>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>CLI Argument (at startup):</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Add a single additional directory</span></span>
<span class="line"></span>
<span class="line">claude --add-dir /path/to/other/project</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Combine with other options</span></span>
<span class="line"></span>
<span class="line">claude --add-dir ~/shared/libraries</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Use with print mode for scripting</span></span>
<span class="line"></span>
<span class="line">claude --add-dir <span class="token punctuation">..</span>/backend <span class="token parameter variable">-p</span> <span class="token string">"Validate that API calls in the current directory match endpoints defined in ../backend"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Slash Command (mid-session):</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Add directory without restarting your session</span></span>
<span class="line"></span>
<span class="line">/add-dir /path/to/other/project</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Add multiple directories as needed</span></span>
<span class="line"></span>
<span class="line">/add-dir ~/shared/libraries</span>
<span class="line"></span>
<span class="line">/add-dir <span class="token punctuation">..</span>/backend-api</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="common-use-cases​" tabindex="-1"><a class="header-anchor" href="#common-use-cases​"><span>Common Use Cases<a href="#common-use-cases" title="Direct link to Common Use Cases">​</a></span></a></h3>
<p><strong>Multi-Repository Projects</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># At startup: Work on frontend while referencing the backend API</span></span>
<span class="line"></span>
<span class="line">claude --add-dir <span class="token punctuation">..</span>/backend-api</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Mid-session: Add backend when you need to reference API endpoints</span></span>
<span class="line"></span>
<span class="line">/add-dir <span class="token punctuation">..</span>/backend-api</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Shared Resources</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># At startup: Access shared configs or documentation</span></span>
<span class="line"></span>
<span class="line">claude --add-dir ~/company/shared-configs</span>
<span class="line"></span>
<span class="line"><span class="token comment"># Mid-session: Add shared resources when needed</span></span>
<span class="line"></span>
<span class="line">/add-dir ~/company/shared-configs</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Dynamic Workflow expansion</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Start with current project, then expand as needed</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># No need to restart when you realize you need additional context</span></span>
<span class="line"></span>
<span class="line">/add-dir <span class="token punctuation">..</span>/related-service</span>
<span class="line"></span>
<span class="line">/add-dir ~/templates</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Note:</strong> The current working directory is always included. CLAUDE.md files appear to not be read in automatically from additional directories added via <code v-pre>--add-dir</code>.</p>
<p>Better Workflow Orchestration</p>
<p>This feature significantly improves workflow orchestration by enabling Claude to:</p>
<ul>
<li><strong>Work across repositories</strong> simultaneously—maintaining context and applying consistent changes</li>
<li><strong>Reference shared code</strong> directly from libraries or configuration repositories</li>
<li><strong>Temporarily expose</strong> a codebase for Claude to analyze or modify without changing directories</li>
<li><strong>Expand workspace dynamically</strong> using <code v-pre>/add-dir</code> without interrupting your current session</li>
</ul>
<p>The <code v-pre>/add-dir</code> slash command makes this particularly seamless—you can start focused on one project and organically expand your workspace as needs emerge, without losing context or restarting. Instead of juggling multiple sessions or copying files, you can compose multiple repositories within the same workflow structure—orchestrating complex multi-repository operations in a single, context-aware session.</p>
<h5 id="configuration-mastery" tabindex="-1"><a class="header-anchor" href="#configuration-mastery"><span>Configuration Mastery</span></a></h5>
<p>Proper configuration is the foundation of effective Claude Code usage. Understanding these settings enables sophisticated workflows and unlocks the full potential of AI-assisted development.</p>
<img src="/img/discovery/009.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/claude-code-pricing/">Pricing Plans</RouteLink>|<RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Guide</RouteLink>|<RouteLink to="/claude-code-mcps/">MCPs &amp; Add-ons</RouteLink>|<RouteLink to="/faq/">FAQs</RouteLink></p>
<ul>
<li><a href="#api-key-setup">API Key Setup</a></li>
<li><a href="#model-selection">Model Selection</a></li>
<li><a href="#model-switching-during-session">Model Switching During Session</a></li>
<li><a href="#mcp-configuration">MCP Configuration</a></li>
<li><a href="#allowed-tools">Allowed Tools</a></li>
<li><a href="#additional-working-directories--extended-workspace">Additional Working Directories / Extended Workspace</a>
<ul>
<li><a href="#usage">Usage</a></li>
<li><a href="#common-use-cases">Common Use Cases</a></li>
</ul>
</li>
</ul>
</div></template>


