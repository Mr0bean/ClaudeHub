<template><div><h1 id="ultrathink-claudelog" tabindex="-1"><a class="header-anchor" href="#ultrathink-claudelog"><span>Ultrathink++ | ClaudeLog</span></a></h1>
<p>In case you have not heard you can adjust the degree to which Claude utilises test-time compute. Adding <code v-pre>ultrathink</code> within your prompt indicates to Claude that he should give it his all thinking wise.</p>
<h3 id="ultrathink-plan-mode​" tabindex="-1"><a class="header-anchor" href="#ultrathink-plan-mode​"><span>Ultrathink &amp; Plan Mode<a href="#ultrathink--plan-mode" title="Direct link to Ultrathink &amp; Plan Mode">​</a></span></a></h3>
<p>I personally get outstanding results using <code v-pre>ultrathink</code> + <code v-pre>Plan Mode</code> with <code v-pre>Claude 4 Sonnet</code>. This combination is especially useful when you don't want to reach for <code v-pre>Claude 4 Opus</code>. I have found it can often bridge the intelligence gap for complex tasks, and when that's not sufficient, I opt to <code v-pre>rev</code> the model by performing multiple critiqued rounds of <code v-pre>ultrathink</code> + <code v-pre>Plan Mode</code>.</p>
<h3 id="revving-the-engine​" tabindex="-1"><a class="header-anchor" href="#revving-the-engine​"><span>Revving the Engine<a href="#revving-the-engine" title="Direct link to Revving the Engine">​</a></span></a></h3>
<p>Revving the engine means instructing Claude to create a plan in <code v-pre>Plan Mode</code>, then systematically critiquing that plan for missing edge cases, redundant aspects, and ordering inefficiencies. This iterative process pushes the model through multiple thinking cycles to reach higher performance.</p>
<hr>
<hr>
<h3 id="the-ultimate-stack​" tabindex="-1"><a class="header-anchor" href="#the-ultimate-stack​"><span>The Ultimate Stack<a href="#the-ultimate-stack" title="Direct link to The Ultimate Stack">​</a></span></a></h3>
<p>If you are struggling to get the performance from <code v-pre>ultrathink</code> + <code v-pre>Sonnet</code> + <code v-pre>Plan Mode</code> + <code v-pre>revving</code> you can throw <code v-pre>sub-agents</code> into the mix. Requesting Claude to use <code v-pre>split role sub-agents</code> to analyse task or plan where each sub-agent has a different role which influences its suggestions towards the plan.</p>
<p>This tactic is token efficient thanks to utilising Sonnet and is scalable regarding to how many sub-agents/roles are utilised and the degree of thinking applied.</p>
<hr>
<hr>
<h3 id="why-ultrathink-before-opus​" tabindex="-1"><a class="header-anchor" href="#why-ultrathink-before-opus​"><span>Why Ultrathink Before Opus<a href="#why-ultrathink-before-opus" title="Direct link to Why Ultrathink Before Opus">​</a></span></a></h3>
<p><code v-pre>ultrathink</code> is a must utilise mechanic which ideally should be used in combinations with the other available mechanics prior to reaching for a superior model like Opus.</p>
<p>Why? Because otherwise you are learning to be unnecessarily reliant on a model which is 5X more expensive without delivering 5X more value.</p>
<h3 id="the-complete-stack​" tabindex="-1"><a class="header-anchor" href="#the-complete-stack​"><span>The Complete Stack<a href="#the-complete-stack" title="Direct link to The Complete Stack">​</a></span></a></h3>
<ul>
<li><strong>Base</strong>: <code v-pre>ultrathink</code> for enhanced thinking</li>
<li><strong>Planning</strong>: <code v-pre>Plan Mode</code> for structured approach</li>
<li><strong>Iteration</strong>: <code v-pre>revving</code> for multiple critique rounds</li>
<li><strong>Perspectives</strong>: <code v-pre>split role sub-agents</code> for diverse analysis</li>
<li><strong>Hybrid Intelligence</strong>: <code v-pre>Opus Plan Mode</code> for automatic Opus planning with Sonnet execution</li>
</ul>
<h5 id="compute-optimization" tabindex="-1"><a class="header-anchor" href="#compute-optimization"><span>Compute Optimization</span></a></h5>
<p>The above mechanics reveal the hidden potential in systematic mechanic stacking. By combining <code v-pre>ultrathink</code>, <code v-pre>Plan Mode</code>, <code v-pre>revving</code>, and <code v-pre>split role sub-agents</code>, you unlock intelligence amplification that transforms how complex problems get solved.</p>
<img src="/img/discovery/037_sonnet_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/plan-mode/">Plan Mode</RouteLink>|<RouteLink to="/mechanics/split-role-sub-agents/">Split Role Sub-Agents</RouteLink>|<RouteLink to="/faqs/what-is-ultrathink/">What is UltraThink</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#ultrathink--plan-mode">Ultrathink &amp; Plan Mode</a></li>
<li><a href="#revving-the-engine">Revving the Engine</a></li>
<li><a href="#the-ultimate-stack">The Ultimate Stack</a></li>
<li><a href="#why-ultrathink-before-opus">Why Ultrathink Before Opus</a></li>
<li><a href="#the-complete-stack">The Complete Stack</a></li>
</ul>
</div></template>


