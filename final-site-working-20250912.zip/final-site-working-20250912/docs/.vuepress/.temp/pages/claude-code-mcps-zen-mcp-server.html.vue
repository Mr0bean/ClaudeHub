<template><div><h1 id="zen-mcp-server-claudelog" tabindex="-1"><a class="header-anchor" href="#zen-mcp-server-claudelog"><span>Zen MCP Server | ClaudeLog</span></a></h1>
<p><strong>Multi-AI orchestration platform that enables Claude Code to collaborate seamlessly with Gemini Pro, OpenAI O3, Grok, and other leading AI models for enhanced development workflows.</strong></p>
<p><strong>Author</strong>: <a href="https://github.com/BeehiveInnovations" target="_blank" rel="noopener noreferrer">BeehiveInnovations</a>  |  <a href="https://github.com/BeehiveInnovations/zen-mcp-server" target="_blank" rel="noopener noreferrer">GitHub Repo</a>  |  6.5k Stars|571 Forks|Apache 2.0 License|Updated Aug 24, 2025</p>
<hr>
<h3 id="overview​" tabindex="-1"><a class="header-anchor" href="#overview​"><span>Overview<a href="#overview" title="Direct link to Overview">​</a></span></a></h3>
<p>Zen MCP Server creates a unified orchestration layer that enables Claude Code to collaborate with multiple AI models simultaneously. By intelligently routing tasks to the most suitable AI model, it dramatically enhances development workflows through specialized expertise and cross-model validation. The platform maintains context continuity across different models while providing specialized developer workflows for debugging, code review, and analysis.</p>
<hr>
<hr>
<h3 id="features​" tabindex="-1"><a class="header-anchor" href="#features​"><span>Features<a href="#features" title="Direct link to Features">​</a></span></a></h3>
<ul>
<li><strong>Multi-Model Orchestration</strong> - Seamlessly integrate Claude, Gemini 2.5 Pro, OpenAI O3, Grok, OpenRouter, and Ollama</li>
<li><strong>Intelligent Model Selection</strong> - Automatic routing to optimal models based on task requirements</li>
<li><strong>Context Preservation</strong> - Maintain conversation context across different AI models and sessions</li>
<li><strong>Specialized Dev Workflows</strong> - Built-in tools for code review, debugging, pre-commit validation, and analysis</li>
<li><strong>Cross-Model Validation</strong> - Compare outputs and approaches from different AI models for enhanced reliability</li>
<li><strong>Expert Mode Routing</strong> - Route complex problems to specialized models (O3 for logic, Gemini for architecture)</li>
</ul>
<hr>
<hr>
<h3 id="installation​" tabindex="-1"><a class="header-anchor" href="#installation​"><span>Installation<a href="#installation" title="Direct link to Installation">​</a></span></a></h3>
<p><strong>Prerequisites</strong></p>
<ul>
<li>Python 3.10+ (3.12 recommended) with UV package manager</li>
<li>API keys for desired AI services (at least one required: OpenAI, Gemini, OpenRouter, etc.)</li>
<li>Claude Code or compatible MCP client</li>
<li>For Windows: WSL2 required</li>
</ul>
<p><strong>Recommended: UVX Quick Install</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># One-line installation - no manual setup required</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">exec</span> <span class="token variable"><span class="token variable">$(</span><span class="token function">which</span> uvx <span class="token operator">||</span> <span class="token builtin class-name">echo</span> uvx<span class="token variable">)</span></span> <span class="token parameter variable">--from</span> git+https://github.com/BeehiveInnovations/zen-mcp-server.git zen-mcp-server</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Claude Code Configuration</strong> Add to your Claude Code configuration:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">  <span class="token string">"mcpServers"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">    <span class="token string">"zen"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">      <span class="token string">"command"</span><span class="token builtin class-name">:</span> <span class="token string">"sh"</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"args"</span><span class="token builtin class-name">:</span> <span class="token punctuation">[</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"-c"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"exec <span class="token variable"><span class="token variable">$(</span><span class="token function">which</span> uvx <span class="token operator">||</span> <span class="token builtin class-name">echo</span> uvx<span class="token variable">)</span></span> --from git+https://github.com/BeehiveInnovations/zen-mcp-server.git zen-mcp-server"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">]</span>,</span>
<span class="line"></span>
<span class="line">      <span class="token string">"env"</span><span class="token builtin class-name">:</span> <span class="token punctuation">{</span></span>
<span class="line"></span>
<span class="line">        <span class="token string">"PATH"</span><span class="token builtin class-name">:</span> <span class="token string">"/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin:~/.local/bin"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"OPENAI_API_KEY"</span><span class="token builtin class-name">:</span> <span class="token string">"your_api_key_here"</span>,</span>
<span class="line"></span>
<span class="line">        <span class="token string">"GEMINI_API_KEY"</span><span class="token builtin class-name">:</span> <span class="token string">"your_gemini_key_here"</span></span>
<span class="line"></span>
<span class="line">      <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">    <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line">  <span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"><span class="token punctuation">}</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>API Key Configuration</strong> Create a <code v-pre>.env</code> file in your project directory or set environment variables:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Option 1: Environment variables</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">OPENAI_API_KEY</span><span class="token operator">=</span><span class="token string">"your-openai-key"</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">GEMINI_API_KEY</span><span class="token operator">=</span><span class="token string">"your-gemini-key"</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">export</span> <span class="token assign-left variable">ANTHROPIC_API_KEY</span><span class="token operator">=</span><span class="token string">"your-claude-key"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># Option 2: .env file (recommended)</span></span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">echo</span> <span class="token string">"OPENAI_API_KEY=your-openai-key"</span> <span class="token operator">></span> .env</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">echo</span> <span class="token string">"GEMINI_API_KEY=your-gemini-key"</span> <span class="token operator">>></span> .env</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Alternative: Traditional Installation</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Only if uvx method doesn't work</span></span>
<span class="line"></span>
<span class="line"><span class="token function">git</span> clone https://github.com/BeehiveInnovations/zen-mcp-server.git</span>
<span class="line"></span>
<span class="line"><span class="token builtin class-name">cd</span> zen-mcp-server</span>
<span class="line"></span>
<span class="line">./run-server.sh  <span class="token comment"># or ./run-server.ps1 on Windows</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<h3 id="usage​" tabindex="-1"><a class="header-anchor" href="#usage​"><span>Usage<a href="#usage" title="Direct link to Usage">​</a></span></a></h3>
<p><strong>Multi-Model Development Workflows</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># Example AI orchestration commands:</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Use Gemini for architecture review and O3 for logic validation"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Compare debugging approaches from Claude and GPT-4"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Route this complex algorithm to the best mathematical reasoning model"</span></span>
<span class="line"></span>
<span class="line"><span class="token comment"># "Run pre-commit validation using multiple model perspectives"</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>The platform intelligently manages model selection and context flow, enabling developers to leverage the unique strengths of different AI models within a single conversation. Zen MCP maintains conversation continuity while providing access to specialized capabilities from each model.</p>
<p><strong>Specialized Developer Tools</strong></p>
<ul>
<li><strong>Code Review</strong>: Multi-model code review with diverse perspectives</li>
<li><strong>Debug Analysis</strong>: Route debugging tasks to models with specific strengths</li>
<li><strong>Pre-commit Validation</strong>: Comprehensive validation using optimal models</li>
<li><strong>Architecture Planning</strong>: Leverage Gemini's architectural reasoning capabilities</li>
</ul>
<hr>
<h5 id="community-insight" tabindex="-1"><a class="header-anchor" href="#community-insight"><span>Community Insight</span></a></h5>
<p>Zen MCP Server gained massive attention with a Reddit post receiving 800+ upvotes. Users report multi-model orchestration provides &quot;different perspectives that catch issues single models miss.&quot;</p>
<img src="/img/discovery/024_excite.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><em>Zen MCP Server is developed by BeehiveInnovations and is open-source. For technical support, multi-model configuration, and community discussions, please refer to the official GitHub repository.</em></p>
<ul>
<li><a href="#overview">Overview</a></li>
<li><a href="#features">Features</a></li>
<li><a href="#installation">Installation</a></li>
<li><a href="#usage">Usage</a></li>
</ul>
</div></template>


