<template><div><h1 id="sanity-check-claudelog" tabindex="-1"><a class="header-anchor" href="#sanity-check-claudelog"><span>Sanity Check | ClaudeLog</span></a></h1>
<blockquote>
<p>Original: Prior to AI agents we ran sanity checks like:</p>
</blockquote>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">console.log<span class="token punctuation">(</span><span class="token string">"sanity"</span><span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">print<span class="token punctuation">(</span><span class="token string">"sanity"</span><span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Log.d<span class="token punctuation">(</span><span class="token string">"test"</span>, <span class="token string">"sanity"</span><span class="token punctuation">)</span></span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<hr>
<p>When collaborating with AI agents we have to perform a different kind of sanity check.</p>
<p>Add your name at the top of your <code v-pre>CLAUDE.md</code>:</p>
<p><strong>CLAUDE.md</strong></p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line"><span class="token comment"># My name is {NAME}</span></span>
<span class="line"></span>
<span class="line">This <span class="token function">file</span> provides guidance to Claude Code when working with this repository.</span>
<span class="line"></span>
<span class="line"><span class="token comment">## Project Overview</span></span>
<span class="line"></span>
<span class="line">This is a React application built with TypeScript and Vite.</span>
<span class="line"></span>
<span class="line"><span class="token punctuation">..</span>.</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>Then ask Claude:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">What is my name?</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div></div></div><hr>
<p>This works as a quick sanity check. If Claude knows your name, all is good. If he does not, then something is wrong.</p>
<p>There are various situations where things could go wrong:</p>
<ul>
<li>Forgetting to set a <code v-pre>CLAUDE.md</code></li>
<li>Putting the <code v-pre>CLAUDE.md</code> in the wrong folder</li>
<li>Accidentally deleting part of the <code v-pre>CLAUDE.md</code></li>
<li>Mispelling <code v-pre>CLAUSE.md</code></li>
<li>Running out of context window (sometimes unavoidable)</li>
</ul>
<p>The simplest way to 'sanity check' your configuration is to place your name at the top of your <code v-pre>CLAUDE.md</code> and ask Claude your name.</p>
<h5 id="experiment" tabindex="-1"><a class="header-anchor" href="#experiment"><span>Experiment</span></a></h5>
<p>Random thought whilst writing this: it could be interesting to have 'sanity check points' dotted across your <code v-pre>CLAUDE.md</code> so you could check their integrity as the context window fills up.</p>
<img src="/img/discovery/016_scary_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/claude-md-supremacy/">CLAUDE.md Supremacy</RouteLink>|<RouteLink to="/configuration/">Configuration</RouteLink>|<RouteLink to="/mechanics/context-window-constraints-as-training/">Context Window Constraints</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
</div></template>


