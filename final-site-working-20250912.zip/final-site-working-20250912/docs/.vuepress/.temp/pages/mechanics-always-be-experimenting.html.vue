<template><div><h1 id="always-be-experimenting-claudelog" tabindex="-1"><a class="header-anchor" href="#always-be-experimenting-claudelog"><span>Always Be Experimenting | ClaudeLog</span></a></h1>
<p>One aspect that is often missing in this current AI wave is the <code v-pre>spirit of an engineer</code>. It fascinates me when seasoned engineers who have dedicated decades of their lives to solving complex problems put so little effort into exploring and testing the limits of AI.</p>
<p>Sure, I am aware it has been recurring instances of <code v-pre>The boy who cried wolf</code> with the AI hype cycles, but the time is now. Agents are not something to shrug at.</p>
<hr>
<hr>
<h3 id="the-engineering-paradox​" tabindex="-1"><a class="header-anchor" href="#the-engineering-paradox​"><span>The Engineering Paradox<a href="#the-engineering-paradox" title="Direct link to The Engineering Paradox">​</a></span></a></h3>
<p>Software engineers spend countless hours learning various frameworks but are reluctant to put their best foot forward with AI. It is truly strange behaviour from a community that should be naturally curious about new tools and technologies.</p>
<p>Consider the natural evolution of our industry: we've collectively invested millions of hours mastering jQuery, Bootstrap, Flash/ActionScript, Internet Explorer quirks, CoffeeScript, and Bower. These technologies served us well and taught us valuable patterns, even as the ecosystem evolved past them. We've always embraced this cycle of learning, adapting, and moving forward. Yet when faced with AI, a technology with transformative potential, there's hesitation to apply that same learning spirit and push the possibilities.</p>
<hr>
<hr>
<h3 id="early-adoption-phase​" tabindex="-1"><a class="header-anchor" href="#early-adoption-phase​"><span>Early Adoption Phase<a href="#early-adoption-phase" title="Direct link to Early Adoption Phase">​</a></span></a></h3>
<p>I am of the belief we are still in the innovator/early minority phase of the AI adoption curve. I believe this because skilled engineers are reluctant to come around to using the tools and I believe once they do come around the technology will be taken to even greater heights thanks to the open source community, MCPs and various other add-ons.</p>
<h3 id="the-a-b-e-mindset​" tabindex="-1"><a class="header-anchor" href="#the-a-b-e-mindset​"><span>The A.B.E Mindset<a href="#the-abe-mindset" title="Direct link to The A.B.E Mindset">​</a></span></a></h3>
<p>When a new technology such as LLMs or the agentic implementation of LLMs arises we should <code v-pre>always be experimenting</code>, documenting and publishing our findings for other community members to challenge, invalidate, verify and innovate on top of.</p>
<p>We are at the beginning of a new era filled with opportunity so, A.B.E!</p>
<h5 id="engineering-spirit" tabindex="-1"><a class="header-anchor" href="#engineering-spirit"><span>Engineering Spirit</span></a></h5>
<p>The AI revolution needs engineers willing to push boundaries. Every experiment you document today becomes tomorrow's breakthrough. Embrace uncertainty and turn curiosity into competitive advantage.</p>
<img src="/img/discovery/024_excite_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/context-window-constraints-as-training/">Context Window Constraints as Training</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#the-engineering-paradox">The Engineering Paradox</a></li>
<li><a href="#early-adoption-phase">Early Adoption Phase</a></li>
<li><a href="#the-abe-mindset">The A.B.E Mindset</a></li>
</ul>
</div></template>


