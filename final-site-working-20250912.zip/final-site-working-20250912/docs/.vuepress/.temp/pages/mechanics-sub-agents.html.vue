<template><div><h1 id="sub-agents-claudelog" tabindex="-1"><a class="header-anchor" href="#sub-agents-claudelog"><span>Sub-Agents | ClaudeLog</span></a></h1>
<p>Sub-agent usage in Claude Code has evolved from manual orchestration to intelligent automation. This guide covers the two approaches to sub-agent utilization: <code v-pre>manual sub-agents</code> and <code v-pre>custom agents</code>.</p>
<hr>
<h3 id="manual-sub-agents​" tabindex="-1"><a class="header-anchor" href="#manual-sub-agents​"><span>Manual Sub-agents<a href="#manual-sub-agents" title="Direct link to Manual Sub-agents">​</a></span></a></h3>
<p>The original approach using the <RouteLink to="/mechanics/task-agent-tools/">Task tool</RouteLink> for explicit parallel processing:</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">Use <span class="token number">3</span> sub-agents to analyze these files:</span>
<span class="line"></span>
<span class="line"><span class="token number">1</span>. Security analysis of auth.ts</span>
<span class="line"></span>
<span class="line"><span class="token number">2</span>. Performance review of cache system</span>
<span class="line"></span>
<span class="line"><span class="token number">3</span>. Type checking of utils.ts</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Benefits</strong>: Direct control, predictable behavior <strong>Drawbacks</strong>: Manual orchestration overhead, no <code v-pre>tool/MCP selection</code> control, shared <code v-pre>system prompt</code> inheritance, same <code v-pre>model</code> for all tasks</p>
<hr>
<hr>
<h3 id="custom-agents​" tabindex="-1"><a class="header-anchor" href="#custom-agents​"><span>Custom Agents<a href="#custom-agents" title="Direct link to Custom Agents">​</a></span></a></h3>
<p>Specialized agents with isolated contexts, custom <code v-pre>system prompts</code> and <code v-pre>tool selection</code> that activate automatically (see <RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink> for detailed configuration):</p>
<div class="language-bash line-numbers-mode" data-highlighter="prismjs" data-ext="sh"><pre v-pre><code class="language-bash"><span class="line">---</span>
<span class="line"></span>
<span class="line">name: security-reviewer</span>
<span class="line"></span>
<span class="line">description: Security analysis specialist <span class="token keyword">for</span> authentication and authorization code</span>
<span class="line"></span>
<span class="line">tools: Read, Grep, Bash</span>
<span class="line"></span>
<span class="line">model: opus</span>
<span class="line"></span>
<span class="line">---</span>
<span class="line"></span>
<span class="line">You are a security expert specializing <span class="token keyword">in</span> authentication vulnerabilities<span class="token punctuation">..</span>.</span>
<span class="line"></span>
<span class="line"></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p><strong>Benefits</strong>: Automatic activation, isolated contexts, token efficiency <strong>Drawbacks</strong>: Setup overhead, configuration complexity</p>
<hr>
<h3 id="decision-framework​" tabindex="-1"><a class="header-anchor" href="#decision-framework​"><span>Decision Framework<a href="#decision-framework" title="Direct link to Decision Framework">​</a></span></a></h3>
<p>Choose the right sub-agent approach based on your specific needs and workflow requirements:</p>
<p><strong>Use Manual Sub-agents When</strong>:</p>
<ul>
<li><strong>Simple parallel operations</strong>: File reads, searches, basic analysis</li>
<li><strong>One-off analysis</strong>: Multi-perspective reviews where you want to specify exactly which viewpoints to use</li>
<li><strong>Quick turnaround needed</strong>: No setup overhead</li>
<li><strong>You want explicit control</strong>: Direct orchestration of which sub-agents handle which tasks</li>
<li><strong>Non-destructive work</strong>: Research, analysis, comparison matrices</li>
</ul>
<p><strong>Use Custom Agents When</strong>:</p>
<ul>
<li><strong>Specialized expertise needed repeatedly</strong>: Code review, security analysis, performance optimization that you do across multiple projects</li>
<li><strong>Domain-specific work</strong>: UX review, SEO optimization, technical writing, accessibility audits</li>
<li><strong>Role-specific tool access required</strong>: Security agents that only have access to Read and Grep tools, not file modification tools</li>
<li><strong>Long-term reusability</strong>: Build once, use everywhere</li>
<li><strong>You prefer automatic delegation</strong>: Let Claude intelligently route tasks to the right specialist based on context</li>
<li><strong>Team standardization</strong>: Share the same agent configurations across your entire team</li>
<li><strong>Cross-project deployment</strong>: Refined agents that work instantly in new codebases</li>
</ul>
<p>Building Your Agent Arsenal</p>
<p>As you progress through projects, amass a collection of specialized agents. Document common patterns, update your <code v-pre>CLAUDE.md</code> with sub-agent guidelines, and create <RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink> for repeatedly needed expertise.</p>
<h5 id="orchestrated-intelligence" tabindex="-1"><a class="header-anchor" href="#orchestrated-intelligence"><span>Orchestrated Intelligence</span></a></h5>
<p>Modern sub-agent usage provides both direct control of manual delegation and the efficiency of automatic specialization. Design your agent ecosystem like a high-performance development team where each specialist excels at their domain.</p>
<img src="/img/discovery/033_energy_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink>|<RouteLink to="/mechanics/custom-agents/">Custom Agents</RouteLink>|<RouteLink to="/mechanics/agent-engineering/">Agent Engineering</RouteLink>|<RouteLink to="/mechanics/sub-agent-tactics/">Sub-agent Tactics</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#manual-sub-agents">Manual Sub-agents</a></li>
<li><a href="#custom-agents">Custom Agents</a></li>
<li><a href="#decision-framework">Decision Framework</a></li>
</ul>
</div></template>


