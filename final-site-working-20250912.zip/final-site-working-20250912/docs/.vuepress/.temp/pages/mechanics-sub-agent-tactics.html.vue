<template><div><h1 id="sub-agent-tactics-claudelog" tabindex="-1"><a class="header-anchor" href="#sub-agent-tactics-claudelog"><span>Sub-agent Tactics | ClaudeLog</span></a></h1>
<p>Many folks on the <a href="https://www.reddit.com/r/ClaudeAI/" target="_blank" rel="noopener noreferrer">Claude AI subreddit</a> have been asking:</p>
<blockquote>
<p>How do I utilise <code v-pre>sub-agents</code> to perform tasks?</p>
</blockquote>
<h3 id="understanding-task-types​" tabindex="-1"><a class="header-anchor" href="#understanding-task-types​"><span>Understanding Task Types<a href="#understanding-task-types" title="Direct link to Understanding Task Types">​</a></span></a></h3>
<p>There are different aspects you must take into account before utilising <code v-pre>sub-agents</code>. Firstly, whether the task is non-destructive or potentially destructive and the kinds of dependencies that exist within the task you are intending to action.</p>
<hr>
<hr>
<h3 id="perfect-parallelizable-tasks​" tabindex="-1"><a class="header-anchor" href="#perfect-parallelizable-tasks​"><span>Perfect Parallelizable Tasks<a href="#perfect-parallelizable-tasks" title="Direct link to Perfect Parallelizable Tasks">​</a></span></a></h3>
<p>If you have a task where you want Claude to research 8 different MCPs and write up a report of their pros/cons and how they can be applicable to the goals defined in your <code v-pre>vision.md</code>. This is a perfect task for parallelisation because each Claude is working in isolation and does not interfere with the existing codebase or each other, they can provide all their finding to the main Claude agent or write individual findings files which can be read and consolidated by the main Claude agent.</p>
<p>This task being non-destructive and easily parallelisible is the kind of thing you should immediately jump to utilise <code v-pre>sub-agents</code> for.</p>
<h3 id="developing-an-itch-for-parallelism​" tabindex="-1"><a class="header-anchor" href="#developing-an-itch-for-parallelism​"><span>Developing an Itch for Parallelism<a href="#developing-an-itch-for-parallelism" title="Direct link to Developing an Itch for Parallelism">​</a></span></a></h3>
<p>After performing multiple parallel tasks of this type you should begin to develop an <code v-pre>itch for parallelism</code>.</p>
<p>Another example is reviewing diffs prior to committing. I often utilise <code v-pre>sub-agents</code> to perform parallel, redundancy, security, factuality, time-complexity checks. After all, they run in parallel so it does not hurt to instantiate <code v-pre>sub-agents</code>. Prior to instantiating the <code v-pre>sub-agents</code>, I would enter <code v-pre>Plan Mode</code> to ensure the task is executed in a non-destructive way since the <code v-pre>sub-agents</code> could potentially attempt to make file changes.</p>
<hr>
<hr>
<h3 id="the-consolidation-strategy​" tabindex="-1"><a class="header-anchor" href="#the-consolidation-strategy​"><span>The Consolidation Strategy<a href="#the-consolidation-strategy" title="Direct link to The Consolidation Strategy">​</a></span></a></h3>
<p>My goal with this tactic is to consolidate the suggestions and then action on them from a single Claude model, often after clearing the context to allow him to start on his best foot.</p>
<p>Day by day, week by week I find myself learning to utilise <code v-pre>sub-agents</code> in more and more creative ways! Who knows what new mechanic next week will bring.</p>
<h3 id="how-to-use-sub-agents​" tabindex="-1"><a class="header-anchor" href="#how-to-use-sub-agents​"><span>How to Use Sub-agents<a href="#how-to-use-sub-agents" title="Direct link to How to Use Sub-agents">​</a></span></a></h3>
<p>To answer the original question: you can explicitly request the number of <code v-pre>sub-agents</code> by stating <code v-pre>Use 3 sub-agents to handle this task</code> or <code v-pre>Create a sub-agent for each file that needs updating</code>. Claude also automatically uses <code v-pre>sub-agents</code> for non-destructive tasks when appropriate, but being explicit gives you control over the parallelisation strategy.</p>
<h5 id="parallel-processing" tabindex="-1"><a class="header-anchor" href="#parallel-processing"><span>Parallel Processing</span></a></h5>
<p>Think like a CPU scheduler for AI agents. Queue up non-destructive tasks, spawn multiple <code v-pre>sub-agents</code>, then consolidate their findings and progressively step through their suggestions whilst overseeing Claude in interactive mode.</p>
<img src="/img/discovery/022_excite_orange.png" alt="Custom image" style="max-width: 165px; height: auto;" />
<hr>
<p><strong>See Also</strong>: <RouteLink to="/mechanics/task-agent-tools/">Task Agent Tools</RouteLink>|<RouteLink to="/mechanics/split-role-sub-agents/">Split Role Sub-Agents</RouteLink></p>
<p><strong>Author</strong>:<a href="https://www.linkedin.com/in/wilfredkasekende/" target="_blank" rel="noopener noreferrer"><img src="/img/claudes-greatest-soldier.png" alt="InventorBlack profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />InventorBlack</a>|CTO at <a href="https://commandstick.com" target="_blank" rel="noopener noreferrer">Command Stick</a>|Mod at <a href="https://reddit.com/r/ClaudeAI" target="_blank" rel="noopener noreferrer">r/ClaudeAi</a></p>
<ul>
<li><a href="#understanding-task-types">Understanding Task Types</a></li>
<li><a href="#perfect-parallelizable-tasks">Perfect Parallelizable Tasks</a></li>
<li><a href="#developing-an-itch-for-parallelism">Developing an Itch for Parallelism</a></li>
<li><a href="#the-consolidation-strategy">The Consolidation Strategy</a></li>
<li><a href="#how-to-use-sub-agents">How to Use Sub-agents</a></li>
</ul>
</div></template>


