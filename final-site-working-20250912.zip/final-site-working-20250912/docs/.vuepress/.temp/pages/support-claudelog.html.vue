<template><div><h1 id="support-claudelog-claudelog" tabindex="-1"><a class="header-anchor" href="#support-claudelog-claudelog"><span>Support ClaudeLog | ClaudeLog</span></a></h1>
<p>ClaudeLog is an independent project dedicated to providing comprehensive, community-driven resources for Claude Code users. Your support helps maintain this authoritative knowledge base, fund development of new features, and ensure continued accessibility for developers worldwide.</p>
<p><a href="https://buymeacoffee.com/claudelog" target="_blank" rel="noopener noreferrer">Support ClaudeLog here</a></p>
<hr>
<h2 id="core-contributors​" tabindex="-1"><a class="header-anchor" href="#core-contributors​"><span>Core Contributors<a href="#core-contributors" title="Direct link to Core Contributors">​</a></span></a></h2>
<p>[</p>
<img src="/img/claudes-greatest-soldier.png" alt="Wilfred Kasekende profile" style="width: 25px; height: 25px; display: inline-block; vertical-align: middle; margin: 0 3px; border-radius: 50%;" />
<p>](https://linkedin.com/in/wilfred-kasekende)</p>
<p><a href="https://linkedin.com/in/wilfred-kasekende" target="_blank" rel="noopener noreferrer">Wilfred Kasekende</a></p>
<p>Creator &amp; Maintainer</p>
<p>[</p>
<img src="/img/reddit-icon.svg" alt="r/Claude AI profile" style="max-width: 80px; height: auto;" />
<p>](https://reddit.com/r/claudeai)</p>
<p><a href="https://reddit.com/r/claudeai" target="_blank" rel="noopener noreferrer">r/Claude AI</a></p>
<p>Reddit Community</p>
<p>[</p>
<img src="/img/claude_log_star.svg" alt="Claude Sonnet profile" style="max-width: 80px; height: auto;" />
<p>](/model-comparison/)</p>
<p><RouteLink to="/model-comparison/">Claude Sonnet</RouteLink></p>
<p>AI Maintainer</p>
<hr>
<h2 id="supporters​" tabindex="-1"><a class="header-anchor" href="#supporters​"><span>Supporters<a href="#supporters" title="Direct link to Supporters">​</a></span></a></h2>
<p>[</p>
<img src="/img/supporters/paul-b.jpg" alt="Paul B profile" style="max-width: 150px; height: auto; border-radius: 8px;" />
<p>](https://github.com/pybae)</p>
<p><a href="https://github.com/pybae" target="_blank" rel="noopener noreferrer">Paul B</a></p>
<p>Software Engineer</p>
<p>[</p>
<img src="/img/supporters/nizar_selander.jpg" alt="Nizar Selander profile" style="max-width: 150px; height: auto; border-radius: 8px;" />
<p>](https://github.com/nizos)</p>
<p><a href="https://github.com/nizos" target="_blank" rel="noopener noreferrer">Nizar Selander</a></p>
<p>Software Engineer</p>
<p>factor10</p>
<p>[</p>
<img src="/img/supporters/tal_onn_sella.png" alt="Tal Onn Sella profile" style="max-width: 150px; height: auto; border-radius: 8px;" />
<p>](https://github.com/Onnson)</p>
<p><a href="https://github.com/Onnson" target="_blank" rel="noopener noreferrer">Tal Onn Sella</a></p>
<p>AI Generalist</p>
<img src="/img/supporters/blake_yoder.jpg" alt="Blake Yoder profile" style="max-width: 150px; height: auto; border-radius: 8px;" />
<p>Blake Yoder</p>
<p>Head of Engineering</p>
<p>Berry Street</p>
<ul>
<li><a href="#core-contributors">Core Contributors</a></li>
<li><a href="#supporters">Supporters</a></li>
</ul>
</div></template>


